CREATE   PROCEDURE [dbo].[PRC_MP_VER_CONF]  -- 프로시저 이름
(

    -- 출력 매개변수
    @O INT OUTPUT, -- SYS_REFCURSOR,
    
    -- 입력 매개변수
    @V_PROJECT_CD  VARCHAR(4000),
    @V_DESCR       VARCHAR(4000), 
    @V_MP_VRSN_ID  VARCHAR(4000),
    @V_MP_VRSN_SEQ VARCHAR(4000),
    @V_IF_VRSN     VARCHAR(4000),
    @V_USER_CD     VARCHAR(4000),
    @V_ENG_TYPE_CD VARCHAR(4000)
)
AS
BEGIN -- 변수 선언


/**********************************************************************************/
/* Project       : M4Plan Suites                                                  */
/* Module        : 공급계획                                                        */
/* Program Name  : PRC_MP_VER_CONF                                                */
/* Description   : 공급계획 버전 확정                                                */
/* Referenced by :                                                                */
/* Program History                                                                */
/**********************************************************************************/
/* Date             In Charge         Description                                 */
/**********************************************************************************/
/* 2021-05-14       M.S.KIM          Initial Release                              */
/**********************************************************************************/


DECLARE @V_PROC_NM                VARCHAR(50); -- 프로시저이름

 
SET NOCOUNT ON; -- 동작
    -- 프로시저 이름
    SET @V_PROC_NM = 'PRC_MP_VER_CONF';


    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_MP_VER_CONF 프로시저', 'ALL START';
    
    --01.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) START', '01.START'; 
    
    
/******************************************************************************
    VERSION UPDATE 
******************************************************************************/    
    
    ---------------------------------------- 진행 상태 종료 ----------------------------------------  
      
    -- 진행상태 종료 변경 
    UPDATE M4E_I301010  
    SET PRGS_STA_CD = 'P00'
    WHERE PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_PLAN_TYPE  = @V_ENG_TYPE_CD
    
    ;
      
      
    ---------------------------------------- 확정 ----------------------------------------  

    --확정 초기화
    UPDATE M4E_I301010  
    SET CONF_CD         = NULL 
       ,CONF_YYMMDD     = NULL
       ,CONF_USER_CD    = NULL
	   ,CONF_CC_DATE	= FORMAT(GETDATE(),'yyyyMMdd')
	   ,CONF_CC_USER_CD	= @V_USER_CD
    WHERE PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_PLAN_TYPE  = @V_ENG_TYPE_CD
	  AND CONF_CD = 'CONFIRM'
    ;

    --선택 버전 확정
    UPDATE M4E_I301010  
    SET CONF_CD         = 'CONFIRM'
       ,CONF_YYMMDD     = FORMAT(GETDATE(),'yyyyMMdd')
       ,CONF_USER_CD    = @V_USER_CD
    WHERE PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_MP_VRSN_SEQ
      AND MP_PLAN_TYPE  = @V_ENG_TYPE_CD
     ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) END', '01.END';     
    
    
    DECLARE @result INT
	
	SET @result = 0 -- 0:성공
	
	IF @@ERROR != 0 SET @result = @@ERROR
	
	IF(@result <> 0)
		--RETURN(1); -- 
		SELECT @O = 1 ;
	else
		--RETURN(2); --
		SELECT @O = 2;
        
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,SQLERRM, 'ALL END';

END
go

