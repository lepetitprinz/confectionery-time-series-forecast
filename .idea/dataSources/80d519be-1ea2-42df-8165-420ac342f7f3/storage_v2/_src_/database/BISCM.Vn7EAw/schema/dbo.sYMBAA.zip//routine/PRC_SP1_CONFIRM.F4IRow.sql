CREATE PROCEDURE [dbo].[PRC_SP1_CONFIRM] 
(
    @V_PROJECT_CD  VARCHAR(50),
    @V_SP_VRSN_ID  VARCHAR(50),
    @V_SP1_CD     VARCHAR(50)
)
AS
BEGIN

/* SQLINES DEMO *** ***********************************************************
    프로시저명 : PRC_SP1_CONFIRM
    설명 : SP1 CONFRIM
           각 해당하는 USER의 데이터만 M4S_O201002로 INSERT
           SP2로 I/F시 기존 SP2의 데이터는 삭제 후 INSERT
           M4S_O201020 SP 확정테이블 INSERT
******************************************************************************/

DECLARE @V_PROC_NM  VARCHAR(50);   -- 프로시저이름
DECLARE @SP_VRSN_ID VARCHAR(50);   -- 판매계획 버전 ID 
DECLARE @SP1_CD    VARCHAR(20);   -- SP1 담당자
DECLARE @PROJECT_CD VARCHAR(20);   -- 프로젝트 코드
DECLARE @RESULT     NUMERIC(2);    -- 
DECLARE @ERR        NVARCHAR(MAX); -- 에러메세지
 
SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRAN
        -- 프로시저 이름
        SET @V_PROC_NM = 'PRC_SP1_CONFIRM';
        -- 파라메터를 새로운 변수에 담음. (속도문제)
        SET @SP_VRSN_ID = @V_SP_VRSN_ID;
        SET @SP1_CD = @V_SP1_CD;
        SET @PROJECT_CD = @V_PROJECT_CD;

        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_SP1_CONFIRM 프로시저', 'ALL START' ;
        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1)M4S_O201002 SP2 DATA DELETE', '1-1.START';
        
        DELETE 
          FROM M4S_O201002
         WHERE 1=1
           AND PROJECT_CD = @PROJECT_CD
           AND DP_VRSN_ID = @SP_VRSN_ID
           AND SALES_MGMT_CD LIKE @SP1_CD+'%';

        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1)M4S_O201002 SP2 DATA DELETE', '1-2.END';
        
        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2)M4S_O201002 SP2 DATA INSERT', '2-1.START';
        
        -- SP1 DATA -> SP2 INSERT
        INSERT INTO M4S_O201002( PROJECT_CD
                                ,DP_VRSN_ID
                                ,SALES_MGMT_CD
                                ,ITEM_CD
                                ,USER_CD
                                ,PLAN_YYMMDD
                                ,PLAN_WEEK
                                ,PLAN_PART_WEEK
                                ,PLAN_YYMM
                                ,PLAN_YY
                                ,DP_QTY
                                ,CREATE_USER_CD
                                ,CREATE_DATE )
        SELECT PROJECT_CD
              ,DP_VRSN_ID
              ,SALES_MGMT_CD
              ,ITEM_CD
              ,USER_CD
              ,PLAN_YYMMDD
              ,PLAN_WEEK
              ,PLAN_PART_WEEK
              ,PLAN_YYMM
              ,PLAN_YY
              ,DP_QTY
              ,USER_CD
              ,GETDATE()
          FROM M4S_O201001 
         WHERE 1=1
           AND PROJECT_CD = @PROJECT_CD
           AND DP_VRSN_ID = @SP_VRSN_ID
           AND SALES_MGMT_CD LIKE @SP1_CD + '%';
           
        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2)M4S_O201002 SP2 DATA INSERT', '2-2.END';
        
        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(3)M4S_O201020 SP1 CONFIRM INSERT', '3-1.START';

        -- SP1확정테이블 MERGE
        MERGE INTO M4S_O201020 T1
        USING (SELECT T1.PROJECT_CD
                     ,T1.SALES_MGMT_VRSN_ID
                     ,T3.SALES_MGMT_TYPE_CD
                     ,T1.SALES_MGMT_CD
                     ,T1.USER_CD
                 FROM M4S_I204050 T1
                     ,M4S_O201010 T2
                     ,M4S_I204030 T3
                WHERE 1=1
                  AND T2.PROJECT_CD = @PROJECT_CD
                  AND T1.SALES_MGMT_VRSN_ID = T2.SALES_MGMT_VRSN_ID
                  AND T2.DP_VRSN_ID = @SP_VRSN_ID
                  AND T1.SALES_MGMT_CD LIKE @SP1_CD + '%'
                  AND T1.PROJECT_CD = T3.PROJECT_CD
                  AND T1.PROJECT_CD = T2.PROJECT_CD
                  AND T1.SALES_MGMT_VRSN_ID = T3.SALES_MGMT_VRSN_ID
                  AND T1.SALES_MGMT_CD = T3.SALES_MGMT_CD
                GROUP BY T1.PROJECT_CD
                        ,T1.SALES_MGMT_VRSN_ID
                        ,T3.SALES_MGMT_TYPE_CD
                        ,T1.SALES_MGMT_CD
                        ,T1.USER_CD) T2
        ON  T1.PROJECT_CD = T2.PROJECT_CD
        AND T1.SALES_MGMT_TYPE_CD = T2.SALES_MGMT_TYPE_CD
        AND T1.SALES_MGMT_CD      = T2.SALES_MGMT_CD
        AND T1.USER_CD            = T2.USER_CD
        WHEN MATCHED THEN 
        UPDATE
           SET CONF_CD = 'CONFIRM'
              ,CONF_USER_CD = T2.USER_CD
              ,CONF_YYMMDD = CONVERT(VARCHAR(8),GETDATE(),112)
        WHEN NOT MATCHED THEN
        INSERT (PROJECT_CD
               ,DP_VRSN_ID
               ,SALES_MGMT_CD
               ,SALES_MGMT_TYPE_CD
               ,USER_CD
               ,CONF_CD
               ,CONF_USER_CD
               ,CONF_YYMMDD)
        VALUES (T2.PROJECT_CD
               ,@SP_VRSN_ID
               ,T2.SALES_MGMT_CD
               ,T2.SALES_MGMT_TYPE_CD
               ,T2.USER_CD
               ,'CONFIRM'
               ,T2.USER_CD
               ,CONVERT(VARCHAR(8),GETDATE(),112));

        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(3)M4S_O201020 SP1 CONFIRM INSERT', '3-2.END';
        COMMIT TRAN;
        --SELECT '1' AS RESULT;
        Set @RESULT = (SELECT '1' AS RESULT);
        EXEC  dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_SP1_CONFIRM 프로시저', 'ALL END';

    END TRY
    BEGIN CATCH

        ROLLBACK TRAN;
        --SELECT '1' AS RESULT;
        Set @RESULT = (SELECT '0' AS RESULT);
        SET @ERR = 'Error : ' + ERROR_MESSAGE();
        EXEC  dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, @ERR, 'ERROR';

    END CATCH
    
END ;
go

