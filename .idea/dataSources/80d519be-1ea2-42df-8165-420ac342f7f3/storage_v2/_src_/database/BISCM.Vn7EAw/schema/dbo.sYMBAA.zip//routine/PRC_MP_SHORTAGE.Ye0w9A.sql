create PROCEDURE [dbo].[PRC_MP_SHORTAGE]
(
-- 출력 매개변수
@O    INT   OUTPUT, -- SYS_REFCURSOR,

-- 입력 매개변수
@P_PROJECT_CD   VARCHAR(4000),
@P_USER_CD      VARCHAR(4000),
@P_MP_VRSN_ID   VARCHAR(4000),
@P_MP_VRSN_SEQ  VARCHAR(4000),
@P_IF_VRSN_ID   VARCHAR(4000)
)
AS
BEGIN --1
	
	/**********************************************************************************/
	/* Project       : M4Plan Suites                                                  */
	/* Module        : 공급계획                                                        */
	/* Program Name  : PRC_MP_SHOTRAGE                                                */
	/* Description   : SHORTAGE TABLE 생성                                             */
	/* Referenced by :                                                                */
	/* Program History                                                                */
	/**********************************************************************************/
	/* Date             In Charge         Description                                 */
	/**********************************************************************************/
	/* 2021-03-23       M.S.KIM          Initial Release                             */
	/* 2021-07-27       Y.J.IM          MSSQL Convert                             */
	/**********************************************************************************/
	
	DECLARE @V_PROC_NM                VARCHAR(50); -- 프로시저명
	
	DECLARE @V_MP_VRSN_ID             VARCHAR(20); -- MP 버전 ID
	DECLARE @V_MP_VRSN_SEQ            VARCHAR(50); -- MP 버전 순번
	DECLARE @V_IF_VRSN_ID             VARCHAR(20); -- 인터페이스 버전 ID
	
	
	DECLARE @V_CHK_YN                 VARCHAR(50); -- 반복 여부
	DECLARE @V_SHORTAGE_QTY           DECIMAL(30);   -- 부족 수량 
	DECLARE @V_SHORTAGE_RES           VARCHAR(50); -- SHORTAGE 설비
	DECLARE @V_SHORT_SG               VARCHAR(50); -- 반제품
	DECLARE @V_SHORT_RM               VARCHAR(50); -- 원자재
	DECLARE @V_SHORT_RM_ROUTE         VARCHAR(50); -- 원자재 공정
	
	DECLARE @V_NUM			DECIMAL(30);
	DECLARE @V_NUM_1		DECIMAL(30);
	DECLARE @V_NUM_2		DECIMAL(30);
	
	
	DECLARE @V_IN_NUM		DECIMAL(30);
	
	DECLARE @S_PROJECT_CD	VARCHAR(4000);
	DECLARE @S_MP_VRSN_ID	VARCHAR(20);
	DECLARE @S_MP_VRSN_SEQ	VARCHAR(50);
	DECLARE @S_MP_KEY       VARCHAR(4000);      
	DECLARE @S_DP_KEY		VARCHAR(4000);       
	DECLARE @S_ENG_ITEM_CD  VARCHAR(4000);       
	DECLARE @S_TIME_INDEX	VARCHAR(4000);
	DECLARE @S_MP_QTY		DECIMAL(30);
	DECLARE @S_SHORTAGE_QTY DECIMAL(30);
	
	DECLARE @F_ITEM_TYPE_CD VARCHAR(200);
	DECLARE @F_OUT_ITEM_CD	VARCHAR(400);
	DECLARE @F_ROUTE_CD		VARCHAR(400);
	
	DECLARE @R_OUT_ITEM_CD	VARCHAR(400);
	DECLARE @R_ROUTE_CD		VARCHAR(400);
	
	SET NOCOUNT ON; 
	
	
	-- 프로시저명
	SET @V_PROC_NM = 'PRC_MP_SHOTRAGE';
	
	SET @V_CHK_YN = 'N';
	
	SET @V_NUM   = 0;
	SET @V_NUM_1 = 0;
	SET @V_NUM_2 = 0;
	SET @V_IN_NUM= 0;
	-- M4S_SCM_PROC_LOG: 프로시저 로그를 저장하는 프로시저 => M4S_I001030(로그 관리)에 저장 , MTX_SCM_PROC_LOG 프로시저 변형(COMMIT 없음)
	SET @V_MP_VRSN_ID  = @P_MP_VRSN_ID;
	SET @V_MP_VRSN_SEQ = @P_MP_VRSN_SEQ;
	SET @V_IF_VRSN_ID  = @P_IF_VRSN_ID;
	
	IF @V_IF_VRSN_ID != 'IF2021W07_002' BEGIN--2
		-------------------------------------------------------------------------------------------------------------------
		exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM,'START' ,'START';
		-- 문제 제품 리스트 
		-- FOR_1
		DECLARE C_SLIST CURSOR FOR 
		SELECT T1.PROJECT_CD
			, T1.MP_VRSN_ID
			, T1.MP_VRSN_SEQ
			, T1.MP_KEY             
			, T1.DP_KEY             
			, T1.ENG_ITEM_CD            
			, T1.TIME_INDEX
			, T2.MP_QTY
			, T1.REQ_MP_QTY - T2.MP_QTY AS SHORTAGE_QTY
		FROM    M4E_I301060 T1 -- MP_DEMAND
			, M4E_O302010 T2 -- MP_RESULT
		WHERE T1.PROJECT_CD        = @P_PROJECT_CD
			AND T1.MP_VRSN_ID        = @V_MP_VRSN_ID
			AND T1.MP_VRSN_SEQ       = @V_MP_VRSN_SEQ
			AND T1.PROJECT_CD        = T2.PROJECT_CD
			AND T1.MP_VRSN_ID        = T2.MP_VRSN_ID
			AND T1.MP_VRSN_SEQ       = T2.MP_VRSN_SEQ   
			AND T1.MP_KEY            = T2.MP_KEY
			AND T1.ENG_ITEM_CD       = T2.ENG_ITEM_CD
			AND T1.TIME_INDEX        = T2.TIME_INDEX
			AND T1.REQ_MP_QTY - T2.MP_QTY > 0;
		--LOOP
		
		OPEN C_SLIST;
		FETCH C_SLIST INTO @S_PROJECT_CD
				, @S_MP_VRSN_ID
				, @S_MP_VRSN_SEQ
				, @S_MP_KEY             
				, @S_DP_KEY             
				, @S_ENG_ITEM_CD            
				, @S_TIME_INDEX
				, @S_MP_QTY
				, @S_SHORTAGE_QTY;
		WHILE @@FETCH_STATUS=0
		BEGIN --3
		
			-- 1차 설비 START --
			SET @V_CHK_YN = 'N';      
			IF @V_CHK_YN = 'N' BEGIN --4
				SET @V_SHORTAGE_QTY = @S_SHORTAGE_QTY;
				
				BEGIN TRY
					SELECT @V_SHORTAGE_RES = T2.RES_CD
						,@V_CHK_YN = 'Y' --AS CHK_YN
					FROM   M4E_O302040 T1     -- IN QTY
						, M4E_O302050 T2     -- FIND RES_CD FOR USED RES_CAPA
						, M4E_I301110 T3     -- INPUT RES_CAPA BY TIME INDEX
						, (
							SELECT RES_CD
								, TIME_INDEX
								, SUM(RES_USE_CAPA_VAL) USED_CAPA_VAL
							FROM M4E_O302050
							WHERE PROJECT_CD        = @P_PROJECT_CD
								AND MP_VRSN_ID        = @V_MP_VRSN_ID
								AND MP_VRSN_SEQ       = @V_MP_VRSN_SEQ
							GROUP BY RES_CD, TIME_INDEX  
						) T4     
					WHERE T1.PROJECT_CD        = @P_PROJECT_CD
						AND T1.MP_VRSN_ID        = @V_MP_VRSN_ID
						AND T1.MP_VRSN_SEQ       = @V_MP_VRSN_SEQ
						AND T1.PROJECT_CD        = T2.PROJECT_CD
						AND T1.MP_VRSN_ID        = T2.MP_VRSN_ID
						AND T1.MP_VRSN_SEQ       = T2.MP_VRSN_SEQ
						AND T1.PROJECT_CD        = T3.PROJECT_CD
						AND T1.MP_VRSN_ID        = T3.MP_VRSN_ID
						AND T1.MP_VRSN_SEQ       = T3.MP_VRSN_SEQ       
						AND T1.IN_ITEM_CD        = @S_ENG_ITEM_CD--'M000061@H001'
						AND T1.TIME_INDEX        = @S_TIME_INDEX -- 1
						AND T1.TIME_INDEX        = T2.TIME_INDEX
						AND T1.ROUTE_CD          = T2.ROUTE_CD
						AND T1.TIME_INDEX        = T3.TIME_INDEX
						AND T2.RES_CD            = T3.RES_CD
						AND T2.RES_CD            = T4.RES_CD
						AND T2.TIME_INDEX        = T4.TIME_INDEX
						AND T3.RES_CAPA_VAL + T3.OVER_CAPA_VAL - T4.USED_CAPA_VAL <= 0;
					
					
					SET @V_NUM       = @V_NUM + 1;
					DECLARE @STR VARCHAR(400);
					DECLARE @STR2 VARCHAR(400);
					SET @STR = @V_NUM+'_'+@S_ENG_ITEM_CD+'_'+'FIRST_RES';
					SET @STR2 = @V_NUM+'_'+@S_ENG_ITEM_CD;
					exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
					COMMIT;
				END TRY 
				BEGIN CATCH
					--WHEN OTHERS THEN  
					SET @V_SHORTAGE_RES = NULL;
					SET @V_CHK_YN       = 'N';
					
					SET @V_NUM       = @V_NUM + 1;
					
					SET @STR = @V_NUM+'_'+@S_ENG_ITEM_CD+'FIRST_RES_PASS';
					SET @STR2 = @V_NUM+'_'+@S_ENG_ITEM_CD;
					exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2 ;
					
					COMMIT;
				END CATCH
			END   --1 (4)        
			-- 1차 설비 END --
			
			
			-- 2차 설비 START-- 
			IF @V_CHK_YN = 'N' BEGIN --5
				SET @STR = @V_NUM+'_'+'SECOND_RES';
				SET @STR2 = @V_NUM+'_'+'SECOND_RES';
				exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2 ;
				
				-- 2차 재료 START--
				DECLARE C_FITEM CURSOR FOR                        
				SELECT T1.OUT_ITEM_CD
					,T3.ITEM_TYPE_CD
					, T1.ROUTE_CD
				FROM M4E_O302030 T1
					INNER JOIN M4E_O302040 T2
					 ON T1.PROJECT_CD = T2.PROJECT_CD
						AND T1.MP_VRSN_ID = T2.MP_VRSN_ID
						AND T1.MP_VRSN_SEQ = T2.MP_VRSN_SEQ
						AND T1.ENG_TIME_INDEX = T2.ENG_TIME_INDEX
						AND T1.ROUTE_CD = T2.ROUTE_CD 
					INNER JOIN M4E_I301080 T3
					 ON T1.PROJECT_CD = T3.PROJECT_CD
						AND T1.MP_VRSN_ID = T3.MP_VRSN_ID
						AND T1.MP_VRSN_SEQ = T3.MP_VRSN_SEQ
						AND T1.OUT_ITEM_CD = T3.ENG_ITEM_CD                    
				WHERE T1.PROJECT_CD = @S_PROJECT_CD    -- 'ENT005'
					AND T1.MP_VRSN_ID = @S_MP_VRSN_ID      --'MP2021W07'
					AND T1.MP_VRSN_SEQ = @S_MP_VRSN_SEQ --10
					AND T2.IN_ITEM_CD =@S_ENG_ITEM_CD --'M000061@H001'
					AND T1.ENG_TIME_INDEX = @S_TIME_INDEX
				
				-- LOOP 
				OPEN C_FITEM;
				FETCH C_FITEM INTO @F_OUT_ITEM_CD
						, @F_ITEM_TYPE_CD
						, @F_ROUTE_CD;
				WHILE @@FETCH_STATUS=0
				BEGIN --6
				
					IF @F_ITEM_TYPE_CD = 'RM' BEGIN --7
					
						BEGIN TRY
						
							SET @V_SHORT_RM = NULL;
							
							SET @V_CHK_YN = 'N';
							
							SELECT @V_SHORT_RM = T2.ENG_ITEM_CD   
								,@V_CHK_YN = 'Y' --AS   CHK_YN
							FROM   M4E_O302030 T1
								INNER JOIN M4E_I301080 T2
								 ON T1.PROJECT_CD        = T2.PROJECT_CD
									AND T1.MP_VRSN_ID       = T2.MP_VRSN_ID
									AND T1.MP_VRSN_SEQ      = T2.MP_VRSN_SEQ
									AND T1.OUT_ITEM_CD      = T2.ENG_ITEM_CD
									AND T2.INF_ITEM_YN      = 'N'
								LEFT JOIN M4E_I301170 T3
								 ON T1.PROJECT_CD        = T3.PROJECT_CD
									AND T1.MP_VRSN_ID       = T3.MP_VRSN_ID
									AND T1.MP_VRSN_SEQ      = T3.MP_VRSN_SEQ
									AND T1.ENG_TIME_INDEX   = T3.TIME_INDEX
									AND T2.ENG_ITEM_CD      = T3.ENG_ITEM_CD
								LEFT JOIN M4E_O302020  T4
								 ON T1.PROJECT_CD        = T4.PROJECT_CD
									AND T1.MP_VRSN_ID       = T4.MP_VRSN_ID
									AND T1.MP_VRSN_SEQ      = T4.MP_VRSN_SEQ
									AND T1.ENG_TIME_INDEX   = T4.TIME_INDEX
									AND T2.ENG_ITEM_CD      = T4.ENG_ITEM_CD
							where T1.project_cd     = @P_PROJECT_CD
								AND T1.MP_VRSN_ID       = @V_MP_VRSN_ID
								AND T1.MP_VRSN_SEQ      = @V_MP_VRSN_SEQ
								AND T1.OUT_ITEM_CD      = @F_OUT_ITEM_CD
								AND T1.ENG_TIME_INDEX   = @S_TIME_INDEX  
								AND T1.ROUTE_CD         = @F_ROUTE_CD
								AND T4.INV_QTY  - T1.ITEM_OUT_QTY  <= 0
							;
							
							SET @V_NUM_1 = @V_NUM_1 + 1;
							
							SET @STR = @V_NUM+'_'+@V_NUM_1 +'_'+@S_ENG_ITEM_CD +'_'+@F_OUT_ITEM_CD+'_RM';
							SET @STR2  = @V_NUM+'_'+@V_NUM_1 +'_'+@F_OUT_ITEM_CD;
							exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
						
						END TRY
						BEGIN CATCH 
							--WHEN OTHERS THEN  
							SET @V_SHORTAGE_RES = NULL;
							SET @V_CHK_YN       = 'N';
							SET @V_SHORT_RM     = NULL;
							
							SET @V_NUM_1 = @V_NUM_1 + 1;
							
							SET @STR = @V_NUM+'_'+@V_NUM_1 +'_'+@S_ENG_ITEM_CD +'_'+@F_OUT_ITEM_CD+'RM_PASS';
							SET @STR2 = @V_NUM+'_'+@V_NUM_1 +'_'+@F_OUT_ITEM_CD;
							exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
							
							COMMIT;
						END CATCH
					END --2(7)
					--RM END--                
					
					IF @V_CHK_YN = 'Y' BEGIN --8
						SET @V_IN_NUM = @V_IN_NUM +1;
						BEGIN --9
							INSERT INTO M4E_O302060--넣을 테이블 
							(
								PROJECT_CD
								,MP_VRSN_ID
								,MP_VRSN_SEQ
								,DP_KEY
								,MP_KEY
								,TIME_INDEX
								,ENG_ITEM_CD
								,PROBLEM_ID
								,PROBLEM_CD
								,PROBLEM_DESC
								,PROBLEM_QTY
								,CREATE_USER_CD
								,CREATE_DATE
								--                    ,MODIFY_USER_CD
								--                    ,MODIFY_DATE                
							)
							VALUES 
							(
								@S_PROJECT_CD
								,@S_MP_VRSN_ID
								,@S_MP_VRSN_SEQ
								,@S_DP_KEY
								,@S_MP_KEY                                
								,@S_TIME_INDEX
								,@S_ENG_ITEM_CD
								,CASE WHEN @V_SHORT_RM IS NULL THEN '기타' ELSE '2.MATERIAL' END--문제 원인 코드
								,@V_SHORT_RM
								,'MATERIAL 부족'--설명 
								,@V_SHORTAGE_QTY
								,@P_USER_CD
								,GETDATE()
							)
							;
							
							
							SET @V_CHK_YN = 'N';
							DECLARE @result INT
							
							SET @result = 0 -- 0:성공
							
							IF @@ERROR != 0 SET @result = @@ERROR
							
							--SELECT @result
							
							IF(@result <> 0) BEGIN --10
								--RETURN(1); -- 
								SELECT @O = 1 ;
								ROLLBACK;
							END --3(10)
							ELSE BEGIN --11
								--RETURN(2); --
								SELECT @O = 2;
								SET @V_CHK_YN = 'N';
								COMMIT;
							END --4(11)
							
						
						END;--5(9)
					END       --6 (8)        
					
					
					IF @F_ITEM_TYPE_CD != 'RM' BEGIN --12
					
						BEGIN TRY
							--FITEM 설비 찾기 START--
							SELECT @V_SHORTAGE_RES = T2.RES_CD
							,@V_CHK_YN = 'Y' --AS   CHK_YN
							FROM   M4E_O302040 T1     -- IN QTY
							, M4E_O302050 T2     -- FIND RES_CD FOR USED RES_CAPA
							, M4E_I301110 T3     -- INPUT RES_CAPA BY TIME INDEX
							, (
							SELECT RES_CD, TIME_INDEX, SUM(RES_USE_CAPA_VAL) USED_CAPA_VAL
							FROM M4E_O302050
							WHERE PROJECT_CD        = @P_PROJECT_CD
							AND MP_VRSN_ID        = @V_MP_VRSN_ID
							AND MP_VRSN_SEQ       = @V_MP_VRSN_SEQ
							GROUP BY RES_CD, TIME_INDEX  
							) T4       
							WHERE T1.PROJECT_CD        = @P_PROJECT_CD
							AND T1.MP_VRSN_ID        = @V_MP_VRSN_ID
							AND T1.MP_VRSN_SEQ       = @V_MP_VRSN_SEQ
							AND T1.PROJECT_CD        = T2.PROJECT_CD
							AND T1.MP_VRSN_ID        = T2.MP_VRSN_ID
							AND T1.MP_VRSN_SEQ       = T2.MP_VRSN_SEQ
							AND T1.PROJECT_CD        = T3.PROJECT_CD
							AND T1.MP_VRSN_ID        = T3.MP_VRSN_ID
							AND T1.MP_VRSN_SEQ       = T3.MP_VRSN_SEQ       
							AND T1.IN_ITEM_CD        = @F_OUT_ITEM_CD--'A283-C@H001'
							AND T1.TIME_INDEX        = @S_TIME_INDEX--1
							AND T1.TIME_INDEX        = T2.TIME_INDEX
							AND T1.ROUTE_CD          = T2.ROUTE_CD
							AND T1.TIME_INDEX        = T3.TIME_INDEX
							AND T2.RES_CD            = T3.RES_CD
							AND T2.RES_CD            = T4.RES_CD
							AND T2.TIME_INDEX        = T4.TIME_INDEX
							AND T3.RES_CAPA_VAL + T3.OVER_CAPA_VAL - T4.USED_CAPA_VAL <= 0;
							
							--                        exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @V_PROC_NM + '(' + 'S_RES' + ')', 'S_RES');
							SET @V_NUM_1 = @V_NUM_1 + 1;
							
							SET @STR = @V_NUM+'_'+@V_NUM_1 +'_'+@S_ENG_ITEM_CD +'_'+@F_OUT_ITEM_CD+'FITEM_RES';
							SET @STR2 = @V_NUM+'_'+@V_NUM_1 +'_'+@F_OUT_ITEM_CD;
							exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
							
							COMMIT;
						END TRY
						BEGIN CATCH
							--WHEN OTHERS THEN  
							SET @V_SHORTAGE_RES = NULL;
							SET @V_CHK_YN       = 'N';
							
							SET @V_NUM_1 = @V_NUM_1 + 1;
							
							SET @STR =  @V_NUM+'_'+@V_NUM_1 +'_'+@S_ENG_ITEM_CD +'_'+@F_OUT_ITEM_CD+'FITEM_RES_PASS';
							SET @STR2 = @V_NUM+'_'+@V_NUM_1 +'_'+@F_OUT_ITEM_CD;
							exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
							
							COMMIT;
						END CATCH
					END-- 7 (12)
					
					--FITEM 설비 찾기 END--
					
					
					
					-- 원재료 START-- 
					IF @V_CHK_YN = 'N' BEGIN --13
					
						SET @STR = @V_NUM+'_'+@V_NUM_1 +'_'+'R';
						SET @STR2 = @V_NUM+'_'+@V_NUM_1 +'_'+'R_'+@F_OUT_ITEM_CD;
						exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
						
						DECLARE C_RLIST CURSOR FOR
							SELECT T1.OUT_ITEM_CD
								,T1.ROUTE_CD
							FROM M4E_O302030 T1
								INNER JOIN M4E_O302040 T2
								ON T1.PROJECT_CD        = T2.PROJECT_CD
									AND T1.MP_VRSN_ID       = T2.MP_VRSN_ID
									AND T1.MP_VRSN_SEQ      = T2.MP_VRSN_SEQ
									AND T1.ENG_TIME_INDEX   = T2.ENG_TIME_INDEX
									AND T1.ROUTE_CD         = T2.ROUTE_CD 
							WHERE T1.PROJECT_CD     = @P_PROJECT_CD
								AND T1.MP_VRSN_ID       = @V_MP_VRSN_ID
								AND T1.MP_VRSN_SEQ      = @V_MP_VRSN_SEQ
								AND T2.IN_ITEM_CD       = @F_OUT_ITEM_CD--V_SHORT_SG
								AND T1.ENG_TIME_INDEX   = @S_TIME_INDEX  ;
						OPEN C_RLIST;
						FETCH C_RLIST INTO @R_OUT_ITEM_CD
							, @R_ROUTE_CD;
						WHILE @@FETCH_STATUS=0
						BEGIN --14
						
							-- 원자재 찾기 START --
							BEGIN TRY
							
								SET @V_SHORT_RM = NULL;
								
								SET @V_CHK_YN = 'N';
								
								SELECT @V_SHORT_RM = T2.ENG_ITEM_CD   
									,@V_CHK_YN = 'Y' --AS   CHK_YN
								FROM   M4E_O302030 T1
									INNER JOIN M4E_I301080 T2
									ON T1.PROJECT_CD        = T2.PROJECT_CD
										AND T1.MP_VRSN_ID       = T2.MP_VRSN_ID
										AND T1.MP_VRSN_SEQ      = T2.MP_VRSN_SEQ
										AND T1.OUT_ITEM_CD      = T2.ENG_ITEM_CD
										AND T2.INF_ITEM_YN      = 'N'
									LEFT JOIN M4E_I301170 T3
									ON T1.PROJECT_CD        = T3.PROJECT_CD
										AND T1.MP_VRSN_ID       = T3.MP_VRSN_ID
										AND T1.MP_VRSN_SEQ      = T3.MP_VRSN_SEQ
										AND T1.ENG_TIME_INDEX   = T3.TIME_INDEX
										AND T2.ENG_ITEM_CD      = T3.ENG_ITEM_CD
									LEFT JOIN M4E_O302020  T4
									ON T1.PROJECT_CD        = T4.PROJECT_CD
										AND T1.MP_VRSN_ID       = T4.MP_VRSN_ID
										AND T1.MP_VRSN_SEQ      = T4.MP_VRSN_SEQ
										AND T1.ENG_TIME_INDEX   = T4.TIME_INDEX
										AND T2.ENG_ITEM_CD      = T4.ENG_ITEM_CD
								where T1.project_cd     = @P_PROJECT_CD
									AND T1.MP_VRSN_ID       = @V_MP_VRSN_ID
									AND T1.MP_VRSN_SEQ      = @V_MP_VRSN_SEQ
									AND T1.OUT_ITEM_CD      = @R_OUT_ITEM_CD
									AND T1.ENG_TIME_INDEX   = @S_TIME_INDEX  
									AND T1.ROUTE_CD         = @R_ROUTE_CD
									AND T4.INV_QTY  - T1.ITEM_OUT_QTY  <= 0
								;
								
								
								SET @V_NUM_2 = @V_NUM_2 + 1;
								
								
								SET @STR = @V_NUM+'_'+@V_NUM_1 +'_'+@V_NUM_2+'_'+@S_ENG_ITEM_CD +'_'+@F_OUT_ITEM_CD+'_'+@R_OUT_ITEM_CD+'_RM';
								SET @STR2 = @V_NUM+'_'+@V_NUM_1 +'_'+@V_NUM_2+'_'+@F_OUT_ITEM_CD;
								exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
							
							END TRY
							BEGIN CATCH
								--EXCEPTION 
								--WHEN OTHERS THEN  
								SET @V_SHORTAGE_RES = NULL;
								SET @V_CHK_YN       = 'N';
								SET @V_SHORT_RM     = NULL;
								
								SET @V_NUM_2 = @V_NUM_2 + 1;
								
								SET @STR = @V_NUM+'_'+@V_NUM_1 +'_'+@V_NUM_2+'_'+@S_ENG_ITEM_CD +'_'+@F_OUT_ITEM_CD+'_'+@R_OUT_ITEM_CD+'RM_PASS';
								SET @STR2 = @V_NUM+'_'+@V_NUM_1 +'_'+@V_NUM_2+'_'+@F_OUT_ITEM_CD;
								exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @STR, @STR2;
								
								COMMIT;
							END CATCH   
							-- 원자재 찾기 END --  
							 
							IF @V_CHK_YN = 'Y' BEGIN --15
								SET @V_IN_NUM = @V_IN_NUM +1;
								BEGIN --16
									INSERT INTO M4E_O302060--넣을 테이블 
									(
										PROJECT_CD
										,MP_VRSN_ID
										,MP_VRSN_SEQ
										,DP_KEY
										,MP_KEY
										,TIME_INDEX
										,ENG_ITEM_CD
										,PROBLEM_ID
										,PROBLEM_CD
										,PROBLEM_DESC
										,PROBLEM_QTY
										,CREATE_USER_CD
										,CREATE_DATE
										--                    ,MODIFY_USER_CD
										--                    ,MODIFY_DATE                
									)
									VALUES 
									(
										@S_PROJECT_CD
										,@S_MP_VRSN_ID
										,@S_MP_VRSN_SEQ
										,@S_DP_KEY
										,@S_MP_KEY                                        
										,@S_TIME_INDEX
										,@S_ENG_ITEM_CD
										,CASE WHEN @V_SHORT_RM IS NULL THEN '기타' ELSE '2.MATERIAL' END--문제 원인 코드
										,@V_SHORT_RM
										,'MATERIAL 부족'--설명 
										,@V_SHORTAGE_QTY
										,@P_USER_CD
										,GETDATE()
										--                    ,'MSKIM'
										--                    ,SYSDATE
									)
									;
									
									
									
									SET @V_CHK_YN = 'N';
									
									SET @result = 0 -- 0:성공
									
									IF @@ERROR != 0 SET @result = @@ERROR
									
									--SELECT @result
									
									IF(@result <> 0) BEGIN --17
										--RETURN(1); -- 
										SELECT @O = 1 ;
										ROLLBACK;
									END --8(17)
									ELSE BEGIN --18
										--RETURN(2); --
										SELECT @O = 2;
										SET @V_CHK_YN = 'N';
										COMMIT;
									END     --9 (18)             
								END;--10(16)
							END        --11(15)	                                     
						
						--FETCH C_RLIST INTO;
						END;--12(14)
						CLOSE C_RLIST;
						DEALLOCATE C_RLIST;                   
					
					
					END         --13 (13)  
					-- 원재료 END --
					
					
					--FETCH C_FITEM INTO;
				END;--14(6)
				CLOSE C_FITEM;
				DEALLOCATE C_FITEM;    
				-- 2차 재료 END--
				
			END --(5) 
			-- 2차 설비 END--
			
			--테이블 INSERT 
			IF @V_CHK_YN = 'Y' BEGIN --19
				SET @V_IN_NUM = @V_IN_NUM +1;
				BEGIN --20
					INSERT INTO M4E_O302060--넣을 테이블 
					(
						PROJECT_CD
						,MP_VRSN_ID
						,MP_VRSN_SEQ
						,DP_KEY
						,MP_KEY
						,TIME_INDEX
						,ENG_ITEM_CD
						,PROBLEM_ID
						,PROBLEM_CD
						,PROBLEM_DESC
						,PROBLEM_QTY
						,CREATE_USER_CD
						,CREATE_DATE
						--                    ,MODIFY_USER_CD
						--                    ,MODIFY_DATE                
					)
					VALUES 
					(
						@S_PROJECT_CD
						,@S_MP_VRSN_ID
						,@S_MP_VRSN_SEQ
						,@S_DP_KEY
						,@S_MP_KEY                    
						,@S_TIME_INDEX
						,@S_ENG_ITEM_CD
						,CASE WHEN @V_SHORTAGE_RES IS NULL THEN '기타' ELSE '1.CAPA' END--문제 원인 코드
						,@V_SHORTAGE_RES
						,'CAPA 부족'--설명 
						,@V_SHORTAGE_QTY
						,@P_USER_CD
						,GETDATE()
					)
					;
					--                COMMIT;
					
					COMMIT;
					
					SET @result = 0 -- 0:성공
					
					IF @@ERROR != 0 SET @result = @@ERROR
					
					--SELECT @result
					
					IF(@result <> 0) BEGIN --21
						--RETURN(1); -- 
						SELECT @O = 1 ;
						ROLLBACK;
					END --15(21)
					ELSE BEGIN --22
						--RETURN(2); --
						SELECT @O = 2; 
						COMMIT;
					END    --16(22)
					
				
				
				END;   --17 (20)
				
			END     --18 (19)           
			
		--FETCH C_SLIST INTO;
		END;--19(3)
		CLOSE C_SLIST;
		DEALLOCATE C_SLIST;
		
		-------------------------------------------------------------------------------------------------------------------
	END --(2) 
	exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @V_PROC_NM , 'ALL_END';
	
	
	SET @result = 0 -- 0:성공
	
	IF @@ERROR != 0 SET @result = @@ERROR
	
	--SELECT @result
	
	IF(@result <> 0) BEGIN --23
		--RETURN(1); -- 
		SELECT @O = 1 ;
		ROLLBACK;
	END--20(23)
	ELSE BEGIN --24
		--RETURN(2); --
		SELECT @O = 2; 
		COMMIT;
	END --21(24)
	
	exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, @V_PROC_NM , 'ALL_END_2';
	
	
	
	COMMIT;
	
	exec dbo.MTX_SCM_PROC_LOG @P_PROJECT_CD, @V_PROC_NM, SQLERRM, 'ALL END';
	
END --22(1)
go

