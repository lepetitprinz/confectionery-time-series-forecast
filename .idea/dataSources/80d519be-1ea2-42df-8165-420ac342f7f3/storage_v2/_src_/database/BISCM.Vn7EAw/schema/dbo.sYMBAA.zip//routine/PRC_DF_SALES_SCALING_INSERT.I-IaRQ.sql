create PROCEDURE [dbo].[PRC_DF_SALES_SCALING_INSERT] -- 프로시저 이름
(
    -- 출력 매개변수
    @O INT OUTPUT, -- SYS_REFCURSOR,

    @V_PROJECT_CD        VARCHAR(50)
    )
AS
BEGIN -- Declare variables

/**********************************************************************************/
/* Project       : M4Plan Suites                                                  */
/* Module        : 수요예측                                                        */
/* Program Name  : PRC_DF_SALES_SCALING_INSERT                                    */
/* Description   : 판매실적 SCALING Table 생성                                      */
/* Referenced by :                                                                */
/* Program History                                                                */
/**********************************************************************************/
/* Date             In Charge         Description                                 */
/**********************************************************************************/
/* 2021-09-03       Y.J.KIM          Initial Release                              */
/**********************************************************************************/

DECLARE @V_PROC_NM    VARCHAR(50); -- 프로시저이름
DECLARE @START_DAY    INT;         --실적 로드 시작일
DECLARE @END_DAY      INT;         --실적 로드 종료일

SET NOCOUNT ON; -- 동작
    -- 프로시저 이름
    SET @V_PROC_NM = 'PRC_DF_SALES_SCALING_INSERT';
    SET @START_DAY = (SELECT OPTION_VAL FROM M4S_I001020 WHERE OPTION_CD = 'RST_START_DAY');
    SET @END_DAY = (SELECT OPTION_VAL FROM M4S_I001020 WHERE OPTION_CD = 'RST_END_DAY');

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,
        'PRC_DF_SALES_SCALING_INSERT 프로시저', 'ALL START';

    --01.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,
        '(1) START', '01.START';

----------------------------
-- 사업 Level Data Insert
----------------------------
INSERT INTO M4S_I002172
(
  PROJECT_CD
, DATA_VRSN_CD
, DIVISION_CD
, BIZ_CD
, LINE_CD
, BRAND_CD
, YYMMDD
, SEQ
, QTY_SCALING
, CREATE_USER_CD
, CREATE_DATE
)
SELECT SALES.PROJECT_CD
     , MM.DATA_VRSN_CD
     , MM.DIVISION_CD
     , SALES.BIZ_CD
     , SALES.LINE_CD
     , SALES.BRAND_CD
     , YYMMDD
     , CONCAT(YYMMDD, '-', FORMAT(ROW_NUMBER() over (PARTITION BY YYMMDD ORDER BY YYMMDD), '000')) AS SEQ
     , (QTY - MIN_QTY) / (MAX_QTY - MIN_QTY) AS QTY_SCALING
     , 'SYSTEM' AS CREAT_USER_CD
     , GETDATE() AS CREATE_DATE
  FROM (
        SELECT PROJECT_CD
             , BIZ_CD
             , LINE_CD
             , BRAND_CD
             , YYMMDD
             , SUM(QTY) AS QTY
         FROM (
               SELECT SALES.PROJECT_CD AS PROJECT_CD
                    , ITEM_ATTR01_CD   AS BIZ_CD
                    , ITEM_ATTR02_CD   AS LINE_CD
                    , ITEM_ATTR03_CD   AS BRAND_CD
                    , YYMMDD
                    , QTY
                 FROM (
                       SELECT PROJECT_CD
                            , ITEM_CD
                            , YYMMDD
                            , RST_SALES_QTY AS QTY
                         FROM M4S_I002170
                        WHERE 1 = 1
                          AND PROJECT_CD = @V_PROJECT_CD
                          AND YYMMDD BETWEEN @START_DAY AND @END_DAY
                       ) SALES
                INNER JOIN (
                            SELECT PROJECT_CD
                                 , ITEM_CD
                                 , ITEM_ATTR01_CD
                                 , ITEM_ATTR02_CD
                                 , ITEM_ATTR03_CD
                              FROM M4S_I002040
                             WHERE 1=1
                               AND PROJECT_CD = @V_PROJECT_CD
                            ) COMM
                   ON SALES.PROJECT_CD = COMM.PROJECT_CD
                  AND SALES.ITEM_CD = COMM.ITEM_CD
              ) SALES
        GROUP BY PROJECT_CD
               , BIZ_CD
               , LINE_CD
               , BRAND_CD
              , YYMMDD
        ) SALES
 LEFT OUTER JOIN (
                  SELECT *
                    FROM M4S_I002171
                   WHERE 1=1
                     AND PROJECT_CD = @V_PROJECT_CD
                     AND DIVISION_CD = 'BIZ_CD'
                 ) MM
   ON SALES.PROJECT_CD = MM.PROJECT_CD
  AND SALES.BIZ_CD = MM.BIZ_CD
  AND SALES.LINE_CD = MM.LINE_CD
  AND SALES.BRAND_CD = MM.BRAND_CD
;

----------------------------
-- Line Level Data Insert --
----------------------------
INSERT INTO M4S_I002172
(
  PROJECT_CD
, DATA_VRSN_CD
, DIVISION_CD
, BIZ_CD
, LINE_CD
, BRAND_CD
, YYMMDD
, SEQ
, QTY_SCALING
, CREATE_USER_CD
, CREATE_DATE
)
SELECT SALES.PROJECT_CD
     , MM.DATA_VRSN_CD
     , MM.DIVISION_CD
     , SALES.BIZ_CD
     , SALES.LINE_CD
     , NULL AS BRAND_CD
     , YYMMDD
     , CONCAT(YYMMDD, '-', FORMAT(ROW_NUMBER() over (PARTITION BY YYMMDD ORDER BY YYMMDD), '000')) AS SEQ
     , (QTY - MIN_QTY) / (MAX_QTY - MIN_QTY) AS QTY_SCALING
     , 'SYSTEM' AS CREAT_USER_CD
     , GETDATE() AS CREATE_DATE
  FROM (
        SELECT PROJECT_CD
             , BIZ_CD
             , LINE_CD
             , YYMMDD
             , SUM(QTY) AS QTY
         FROM (
               SELECT SALES.PROJECT_CD AS PROJECT_CD
                    , ITEM_ATTR01_CD   AS BIZ_CD
                    , ITEM_ATTR02_CD   AS LINE_CD
                    , YYMMDD
                    , QTY
                 FROM (
                       SELECT PROJECT_CD
                            , ITEM_CD
                            , YYMMDD
                            , RST_SALES_QTY AS QTY
                         FROM M4S_I002170
                        WHERE 1 = 1
                          AND PROJECT_CD = @V_PROJECT_CD
                          AND YYMMDD BETWEEN @START_DAY AND @END_DAY
                       ) SALES
                INNER JOIN (
                            SELECT PROJECT_CD
                                 , ITEM_CD
                                 , ITEM_ATTR01_CD
                                 , ITEM_ATTR02_CD
                              FROM M4S_I002040
                             WHERE 1=1
                               AND PROJECT_CD = @V_PROJECT_CD
                            ) COMM
                   ON SALES.PROJECT_CD = COMM.PROJECT_CD
                  AND SALES.ITEM_CD = COMM.ITEM_CD
              ) SALES
        GROUP BY PROJECT_CD
               , BIZ_CD
               , LINE_CD
              , YYMMDD
        ) SALES
 LEFT OUTER JOIN (
                  SELECT *
                    FROM M4S_I002171
                   WHERE 1=1
                     AND PROJECT_CD = @V_PROJECT_CD
                     AND DIVISION_CD = 'LINE_CD'
                 ) MM
   ON SALES.PROJECT_CD = MM.PROJECT_CD
  AND SALES.BIZ_CD = MM.BIZ_CD
  AND SALES.LINE_CD = MM.LINE_CD
;

-----------------------------
-- Brand Level Data Insert --
-----------------------------
INSERT INTO M4S_I002172
(
  PROJECT_CD
, DATA_VRSN_CD
, DIVISION_CD
, BIZ_CD
, LINE_CD
, BRAND_CD
, YYMMDD
, SEQ
, QTY_SCALING
, CREATE_USER_CD
, CREATE_DATE
)
SELECT SALES.PROJECT_CD
     , MM.DATA_VRSN_CD
     , MM.DIVISION_CD
     , SALES.BIZ_CD
     , SALES.LINE_CD
     , SALES.BRAND_CD
     , YYMMDD
     , CONCAT(YYMMDD, '-', FORMAT(ROW_NUMBER() over (PARTITION BY YYMMDD ORDER BY YYMMDD), '000')) AS SEQ
     , (QTY - MIN_QTY) / (MAX_QTY - MIN_QTY) AS QTY_SCALING
     , 'SYSTEM' AS CREAT_USER_CD
     , GETDATE() AS CREATE_DATE
  FROM (
        SELECT PROJECT_CD
             , BIZ_CD
             , LINE_CD
             , BRAND_CD
             , YYMMDD
             , SUM(QTY) AS QTY
         FROM (
               SELECT SALES.PROJECT_CD AS PROJECT_CD
                    , ITEM_ATTR01_CD   AS BIZ_CD
                    , ITEM_ATTR02_CD   AS LINE_CD
                    , ITEM_ATTR03_CD   AS BRAND_CD
                    , YYMMDD
                    , QTY
                 FROM (
                       SELECT PROJECT_CD
                            , ITEM_CD
                            , YYMMDD
                            , RST_SALES_QTY AS QTY
                         FROM M4S_I002170
                        WHERE 1 = 1
                          AND PROJECT_CD = @V_PROJECT_CD
                          AND YYMMDD BETWEEN @START_DAY AND @END_DAY
                       ) SALES
                INNER JOIN (
                            SELECT PROJECT_CD
                                 , ITEM_CD
                                 , ITEM_ATTR01_CD
                                 , ITEM_ATTR02_CD
                                 , ITEM_ATTR03_CD
                              FROM M4S_I002040
                             WHERE 1=1
                               AND PROJECT_CD = @V_PROJECT_CD
                            ) COMM
                   ON SALES.PROJECT_CD = COMM.PROJECT_CD
                  AND SALES.ITEM_CD = COMM.ITEM_CD
              ) SALES
        GROUP BY PROJECT_CD
               , BIZ_CD
               , LINE_CD
               , BRAND_CD
              , YYMMDD
        ) SALES
 LEFT OUTER JOIN (
                  SELECT *
                    FROM M4S_I002171
                   WHERE 1=1
                     AND PROJECT_CD = @V_PROJECT_CD
                     AND DIVISION_CD = 'BRAND_CD'
                 ) MM
   ON SALES.PROJECT_CD = MM.PROJECT_CD
  AND SALES.BIZ_CD = MM.BIZ_CD
  AND SALES.LINE_CD = MM.LINE_CD
  AND SALES.BRAND_CD = MM.BRAND_CD
;


    --01.END--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) END', '01.END';

    DECLARE @result INT
	SET @result = 0 -- 0:성공

	IF @@ERROR != 0 SET @result = @@ERROR
	--SELECT @result

	IF(@result <> 0)
		--RETURN(1); --
		SELECT @O = 1 ;
	else
		--RETURN(2); --
		SELECT @O = 2;

    exec dbo.MTX_SCM_PROC_LOG V_PROJECT_CD, V_PROC_NM,SQLERRM, 'ALL END';

END
go

