create PROCEDURE [dbo].[PRC_MP_VERSION_CREATION_V2] -- 프로시저 이름
(

    -- 출력 매개변수
    @V_RETRUN INT OUTPUT, -- SYS_REFCURSOR,

    -- 입력 매개변수
    @V_PROJECT_CD  VARCHAR(4000),
    @V_DESCR       VARCHAR(4000), 
    @V_IF_VRSN     VARCHAR(4000),
    @V_SNRO_ID     VARCHAR(4000),
    @V_EG_RUN_CD   VARCHAR(4000),
    @V_USER_CD     VARCHAR(4000),
    @V_EG_TYPE_CD  VARCHAR(4000),
    @V_ITEM_GRP   VARCHAR(4000)
    
    

)
AS
BEGIN -- 변수 선언
DECLARE @V_MP_VRSN_ID             VARCHAR(50); -- MP 계획 버전 ID 
DECLARE @V_SEQ                    VARCHAR(2);  -- MP 버전 순번
DECLARE @V_PLAN_YYMMDD            VARCHAR(8);   -- 계획 일자
DECLARE @V_PLAN_START_DATE        VARCHAR(8);   -- 계획 시작 일자
DECLARE @V_PLAN_END_DATE          VARCHAR(8);   -- 계획 종료 일자
DECLARE @V_MaxTimeIndex           VARCHAR(8);
DECLARE @V_BUCKET_TYPE            VARCHAR(8);   -- 버켓 타입 
DECLARE @V_MODI_PLAN_YYMMDD       VARCHAR(8);
DECLARE @V_PROC_NM                VARCHAR(50); -- 프로시저이름

 
SET NOCOUNT ON; -- 동작
    -- 프로시저 이름
    SET @V_PROC_NM = 'PRC_MP_VERSION_CREATION_V2';

    -- exec dbo.MTX_SCM_PROC_LOG 프로시저 로그를 저장하는 프로시저 => M4S_I001030(로그 관리)에 저장
    -- @V_PROJECT_CD, @V_PROC_NM, @V_PROC_DESC, @V_PROC_STATE
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_MP_VERSION_CREATION_V2 프로시저', 'ALL START';
    
    --01.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) 변수', '01.START'; 
    
    -- 변수에 값 할당
    SELECT @V_MP_VRSN_ID = 'MP' + SUBSTRING(IF_VRSN_ID, 3, 7) 
		, @V_PLAN_YYMMDD = YYMMDD
        , @V_PLAN_START_DATE = PLAN_FROM_YYMMDD
        , @V_PLAN_END_DATE = PLAN_TO_YYMMDD
	FROM M4S_I305010 -- IF 버전 관리
     WHERE 1=1 
       AND PROJECT_CD = @V_PROJECT_CD
       AND IF_VRSN_ID = @V_IF_VRSN
	;
	
	--SELECT 'MP' + SUBSTRING(IF_VRSN_ID, 3, 7)  AS MP_VRSN_ID                 
 --        , YYMMDD                                              
 --        , PLAN_FROM_YYMMDD 
	--	 , @V_MP_VRSN_ID
 --        , @V_PLAN_YYMMDD
 --        , @V_PLAN_START_DATE
 --        , @V_PLAN_END_DATE                                    
 --     FROM M4S_I305010 -- IF 버전 관리
 --    WHERE 1=1 
 --      AND PROJECT_CD = @V_PROJECT_CD
 --      AND IF_VRSN_ID = @V_IF_VRSN
 --   ;
    
    -- 변수에 값 할당
	SELECT @V_SEQ = T1.SEQ
	FROM
		(
			SELECT ISNULL(MAX(CAST(MP_VRSN_SEQ AS DECIMAL)) + 1, 1) AS SEQ 
			  FROM M4E_I301010 -- 공급 계획 실행 버전 관리      
			 WHERE 1=1
			   AND PROJECT_CD = @V_PROJECT_CD
			   AND MP_VRSN_ID = @V_MP_VRSN_ID
		) T1
    ;
    
    DECLARE @STR VARCHAR(400)
    
    SET @STR = '(1) 변수  IF VERSION '+@V_IF_VRSN+',  IF VERSION '+@V_MP_VRSN_ID+',  SEQ '+CAST(@V_SEQ AS VARCHAR(4000))+', ENGINE TYPE '+@V_EG_TYPE_CD;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, @STR, '01.END';
    --01.END--
    
    
    
    --02.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2)M4E_I301010 공급 계획 실행 버전 관리 테이블 UPDATE', '02.START';
    
    -- 이전버전 진행상태 P00
    UPDATE M4E_I301010                                  
       SET PRGS_STA_CD = 'P00'   
     WHERE 1=1 
       AND PROJECT_CD = @V_PROJECT_CD
       AND MP_VRSN_ID = @V_MP_VRSN_ID
   ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2)M4E_I301010 공급 계획 실행 버전 관리 테이블 UPDATE', '02.END';
    --02.END--
    
    

/******************************************************************************
    DELETE
******************************************************************************/
    
    --03.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(3)M4E_I301020 공급 계획 실행 제약 정보 테이블 DELETE', '03.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301020  --공급 계획 실행 제약 정보                                   
     WHERE 1=1
       AND PROJECT_CD  = @V_PROJECT_CD
       AND MP_VRSN_ID  = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(3)M4E_I301020 공급 계획 실행 제약 정보 테이블 DELETE', '03.END';
    --03.END--
    
    
    
    --04.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(4)M4E_I301030 공급 계획 실행 목적 정보 테이블 DELETE', '04.START';

    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301030  --공급 계획 실행 목적 정보                                   
    WHERE 1=1
      AND PROJECT_CD  = @V_PROJECT_CD
      AND MP_VRSN_ID  = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(4)M4E_I301030 공급 계획 실행 목적 정보 테이블 DELETE', '04.END';
    --04.END--
    
    
    
    --05.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(5)M4E_I301040 공급 계획 실행 옵션 정보 테이블 DELETE', '05.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301040  --공급 계획 실행 옵션 정보                                   
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(5)M4E_I301040 공급 계획 실행 옵션 정보 테이블 DELETE', '05.END';
    --05.END--
    
    
    
    --06.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(6)M4E_I301050 공급계획 실행 CALENDAR 정보 테이블 DELETE', '06.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301050  --공급계획 실행 CALENDAR 정보                                
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(6)M4E_I301050 공급계획 실행 CALENDAR 정보 테이블 DELETE', '06.END';
    --06.END--
    
    
     
    --07.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(8)M4E_I301060 공급계획 실행 DEMAND 정보 테이블 DELETE', '08.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301060  --공급계획 실행 DEMAND 정보                                 
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(8)M4E_I301060 공급계획 실행 DEMAND 정보 테이블 DELETE', '08.END';
    --07.END--
    
    
    
    --08.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(7)M4E_I301080공급계획 실행 제품정보 테이블 DELETE', '07.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301080  -- 공급계획 실행 제품정보                                  
     WHERE 1=1  
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(7)M4E_I301080공급계획 실행 제품정보 테이블 DELETE', '07.END';
    --08.END--
    
    
    
    --09.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(9)M4E_I301090 공급계획 실행 공정정보 테이블 DELETE', '09.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301090  --공급계획 실행 공정정보                                  
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(9)M4E_I301090 공급계획 실행 공정정보 테이블 DELETE', '09.END';
    --09.END--
    
    
    
    --10.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(10)M4E_I301100 공급계획 실행 설비정보 테이블 DELETE', '10.START';
    
    -- WHERE절 만족하는 DATA DELETE 
    DELETE M4E_I301100  -- 공급계획 실행 설비정보                               
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(10)M4E_I301100 공급계획 실행 설비정보 테이블 DELETE', '10.END';
    --10.END--
    
    
    
    --11.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(11)M4E_I301110 공급계획 실행 CAPA 정보 테이블 DELETE', '11.START';
    
    -- WHERE절 만족하는 DATA DELETE 
    DELETE M4E_I301110  -- 공급계획 실행 CAPA 정보                                 
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(11)M4E_I301110 공급계획 실행 CAPA 정보 테이블 DELETE', '11.END';
    --11.END--
    
    
    
    --12.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(12)M4E_I301120 공급계획 실행 ROUTING 정보 테이블 DELETE', '12.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301120   --공급계획 실행 ROUTING 정보                               
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(12)M4E_I301120 공급계획 실행 ROUTING 정보 테이블 DELETE', '12.END';
    --12.END--
    
    
    
    --13.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(13)M4E_I301150공급계획 실행 자재/공정 매핑  테이블 DELETE', '13.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301150  --공급계획 실행 자재/공정 매핑                                   
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(13)M4E_I301150공급계획 실행 자재/공정 매핑  테이블 DELETE', '13.END';
    --13.END--
    
    
    
    --14.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(14)M4E_I301160 공급계획 실행 공정/자재 매핑   테이블 DELETE', '14.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301160  --공급계획 실행 공정/자재 매핑                                  
     WHERE 1=1
       AND PROJECT_CD    = @V_PROJECT_CD
       AND MP_VRSN_ID    = @V_MP_VRSN_ID
       AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(14)M4E_I301160 공급계획 실행 공정/자재 매핑   테이블 DELETE', '14.END';
    --14.END--
        
    
    
    --15.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(15)M4E_I301170 공급계획 실행 재고정보 테이블 DELETE', '15.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301170  --공급계획 실행 재고정보             
    WHERE 1=1 
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(15)M4E_I301170 공급계획 실행 재고정보 테이블 DELETE', '15.END';
    --15.END--
    
    

    --16.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(16)M4E_I301121 공급계획 실행 ROUTING 정보 테이블 DELETE', '16.START';
    
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301121  --공급계획 실행 ROUTING 정보
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(16)M4E_I301121 공급계획 실행 ROUTING 정보 테이블 DELETE', '16.END';
    --16.END--
    
    --17.START
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301200  -- 공급계획 실행 창고 정보
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    --17.END
    
    --18.START
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301180  --공급계획 실행 안전재고정보
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    --18.END
    

    --START
    -- WHERE절 만족하는 DATA DELETE
    DELETE M4E_I301170  --공급계획 실행 안전재고정보
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    --END

   
    
    
/******************************************************************************
    OUTPUT DATA DELETE 
******************************************************************************/    
    
    DELETE M4E_O302010  --결과 데이터 삭제. Demand Supply
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    DELETE M4E_O302020  --결과 데이터 삭제. Demand Supply
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    DELETE M4E_O302030  --결과 데이터 삭제. Demand Supply
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    DELETE M4E_O302040  --결과 데이터 삭제. Demand Supply
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    DELETE M4E_O302050  --결과 데이터 삭제. Demand Supply
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;

    DELETE M4E_O302060  --결과 데이터 삭제. Demand Supply
    WHERE 1=1
      AND PROJECT_CD    = @V_PROJECT_CD
      AND MP_VRSN_ID    = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ   = @V_SEQ
    ;
    
    
/******************************************************************************
    INSERT
******************************************************************************/
    --17.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(17)M4E_I301010 공급 계획 MP 버전 관리 테이블 INSERT', '17.START';

    INSERT INTO M4E_I301010 --공급 계획 MP 버전 관리
    (    PROJECT_CD
       , MP_VRSN_ID
       , MP_VRSN_SEQ
       , IF_VRSN_ID
       , SNRO_VRSN_ID
       , PRGS_STA_CD 
       , EG_RUN_CD
       , FROM_YYMMDD
       , TO_YYMMDD
       , CONF_CC_USER_CD -------------------------------------------------------------------------------------------------------------------------------------------------
       , CREATE_USER_CD
       , CREATE_DATE
       , DESCR
    ) 
    VALUES             
    (   @V_PROJECT_CD
      , @V_MP_VRSN_ID
      , @V_SEQ
      , @V_IF_VRSN
      , @V_SNRO_ID
      , 'P01'             
      , @V_EG_RUN_CD
      , @V_PLAN_START_DATE
      , @V_PLAN_END_DATE
      , @V_ITEM_GRP -------------------------------------------------------------------------------------------------------------------------------------------------
      , @V_USER_CD 
      , GETDATE()
      , @V_DESCR
    )    
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(17)M4E_I301010 공급 계획 MP 버전 관리 테이블 INSERT', '17.END';
    --17.END--
    
    
    
    --18.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(18)M4E_I301020 공급 계획 실행 제약 정보 테이블 INSERT', '18.START';

    INSERT INTO M4E_I301020 --공급 계획 실행 제약 정보
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , EG_CONST_CD
      , EG_CONST_NM
      , EG_CONST_SEQ
      , USE_YN
      , DESCR
      , CREATE_USER_CD
      , CREATE_DATE
    )     
    (
        SELECT T1.PROJECT_CD
             , @V_MP_VRSN_ID    AS MP_VRSN_ID
             , @V_SEQ           AS MP_VRSN_SEQ
             , T2.EG_CONST_CD
             , T2.EG_CONST_NM
             , T2.EG_CONST_SEQ
             , T2.USE_YN
             , T2.DESCR
             , @V_USER_CD       AS CREATE_USER_CD
              ,GETDATE()         AS CREATE_DATE
        FROM M4S_I305031 T1  -- 엔진 시나리오 매핑
            ,
            (
                SELECT PROJECT_CD 
                     , EG_CONST_CD
                     , EG_CONST_NM
                     , EG_CONST_SEQ
                     , USE_YN
                     , DESCR
                  FROM M4S_I305040  -- 엔진 제약 관리
                 WHERE USE_YN = 'Y'
            ) T2
        WHERE 1=1 
          AND T1.PROJECT_CD    = @V_PROJECT_CD
          AND T1.PROJECT_CD    = T2.PROJECT_CD
          AND T1.SNRO_CTGRI_CD = T2.EG_CONST_CD
          AND T1.SNRO_VRSN_ID  = @V_SNRO_ID
          AND T1.USE_YN        = 'Y'
    );

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(18)M4E_I301020 공급 계획 실행 제약 정보 테이블 INSERT', '18.END';
    --18.END--

    
    
    --19.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(19)M4E_I301030 공급 계획 실행 목적식 정보 테이블 INSERT', '19.START';
    
    INSERT INTO M4E_I301030  --공급 계획 실행 목적식 정보
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , EG_FUNC_CD
      , EG_FUNC_NM
      , EG_FUNC_SEQ
      , USE_YN
      , DESCR
      , CREATE_USER_CD
      , CREATE_DATE
    )  
    (
        SELECT @V_PROJECT_CD               AS PROJECT_CD
              ,@V_MP_VRSN_ID               AS MP_VRSN_ID
              ,@V_SEQ 
              ,T1.SNRO_CTGRI_CD           AS EG_FUNC_CD
              ,T2.EG_FUNC_NM
              ,100 - T1.SNRO_CTGRI_SEQ    AS EG_FUNC_SEQ
              ,T1.USE_YN
              ,T2.DESCR
              ,@V_USER_CD                  AS CREATE_USER_CD
              ,T1.CREATE_DATE
        FROM M4S_I305031 T1         --매핑
        INNER JOIN M4S_I305050 T2   --목적식 
            ON T1.PROJECT_CD = T2.PROJECT_CD
            AND T1.SNRO_CTGRI_CD = T2.EG_FUNC_CD   
        WHERE 1=1 
          AND T1.PROJECT_CD   = @V_PROJECT_CD
          AND T1.SNRO_VRSN_ID = @V_SNRO_ID
          AND T1.SNRO_TYPE_CD = 'OBJ'
          AND T1.USE_YN = 'Y'	
    );

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(19)M4E_I301030 공급 계획 실행 목적식 정보 테이블 INSERT', '19.END';
    --19.END--
    
    
    
    --20.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(20)M4E_I301040 공급 계획 실행 옵션 정보  테이블 INSERT', '20.START';
    
    INSERT INTO M4E_I301040 --공급 계획 실행 옵션 정보 
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , EG_OPTION_CD
      , EG_OPTION_NM
      , EG_OPTION_VAL
      , USE_YN
      , DESCR
      , CREATE_USER_CD
      , CREATE_DATE
    )   
    (
        SELECT T1.PROJECT_CD 
             , @V_MP_VRSN_ID    AS MP_VRSN_ID
             , @V_SEQ           AS MP_VRSN_SEQ
             , T2.EG_OPTION_CD
             , T2.EG_OPTION_NM
             , T2.EG_OPTION_VAL
             , T2.USE_YN
             , T2.DESCR
             , @V_USER_CD       AS CREATE_USER_CD
             , GETDATE()         AS CREATE_DATE   
        FROM M4S_I305031 T1  -- 엔진 시나리오 매핑
            ,
            (
                SELECT PROJECT_CD 
                     , EG_OPTION_CD
                     , EG_OPTION_NM
                     , EG_OPTION_VAL
                     , USE_YN
                     , DESCR
                  FROM M4S_I305060  -- 엔진 옵션 관리
                 WHERE USE_YN = 'Y'
            ) T2
        WHERE 1=1 
          AND T1.PROJECT_CD     = @V_PROJECT_CD
          AND T1.PROJECT_CD     = T2.PROJECT_CD
          AND T1.SNRO_CTGRI_CD  = T2.EG_OPTION_CD
          AND T1.SNRO_VRSN_ID   = @V_SNRO_ID
          AND T1.USE_YN         = 'Y'
    );

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(20)M4E_I301040 공급 계획 실행 옵션 정보  테이블 INSERT', '20.END';
    --20.END--
    
    
/***************************************************************************************************
 **시나리오 관리 옵션(엔진 옵션 관리)  MaxTimeIndex(계획구간) 변경시 변경 사항 반영 
****************************************************************************************************/
    --TBD--------------------------------------
    SELECT @V_MODI_PLAN_YYMMDD = MST.YMD
      FROM 
    (
        SELECT T1.YMD
          FROM (SELECT 'D' AS GB
                      ,YYMMDD AS YMD
                      ,ROW_NUMBER() OVER(ORDER BY YYMMDD) AS RNUM
                  FROM M4S_I002030
                WHERE YYMMDD > @V_PLAN_YYMMDD
                  AND YYMMDD < FORMAT(DATEADD(MONTH, +12, CONVERT(DATE, @V_PLAN_YYMMDD)), 'yyyyMMdd')
                  AND PROJECT_CD = @V_PROJECT_CD
                UNION ALL
                SELECT  'W' AS GB
                      ,END_WEEK_DAY AS YMD
                      ,ROW_NUMBER() OVER(ORDER BY END_WEEK_DAY) AS RNUM
                  FROM M4S_I002030
                WHERE YYMMDD > @V_PLAN_YYMMDD
                  AND YYMMDD < FORMAT(DATEADD(MONTH, +12, CONVERT(DATE, @V_PLAN_YYMMDD)), 'yyyyMMdd')
                  AND PROJECT_CD = @V_PROJECT_CD
                GROUP BY END_WEEK_DAY
                UNION ALL
                SELECT 'PW' AS GB
                      ,END_PART_WEEK_DAY AS YMD
                      ,ROW_NUMBER() OVER(ORDER BY END_PART_WEEK_DAY) AS RNUM
                  FROM M4S_I002030
                WHERE YYMMDD > @V_PLAN_YYMMDD
                  AND YYMMDD < FORMAT(DATEADD(MONTH, +12, CONVERT(DATE, @V_PLAN_YYMMDD)), 'yyyyMMdd')
                  AND PROJECT_CD = @V_PROJECT_CD
                GROUP BY END_PART_WEEK_DAY
                UNION ALL
                SELECT 'M' AS GB
                      ,END_MONTH_DAY AS YMD
                      ,ROW_NUMBER() OVER(ORDER BY END_MONTH_DAY) AS RNUM
                  FROM M4S_I002030
                WHERE YYMMDD > @V_PLAN_YYMMDD
                  AND YYMMDD < FORMAT(DATEADD(MONTH, +12, CONVERT(DATE, @V_PLAN_YYMMDD)), 'yyyyMMdd')
                  AND PROJECT_CD = @V_PROJECT_CD
                GROUP BY END_MONTH_DAY ) T1
              ,M4S_I305060 T2 -- 엔진 옵션 관리
              ,M4S_I001020 T3 -- SCM 환경 설정
        WHERE T1.RNUM = T2.EG_OPTION_VAL
          AND T2.USE_YN = 'Y'
          AND T2.PROJECT_CD =@V_PROJECT_CD
          AND T2.EG_OPTION_CD = 'MaxTimeIndex'
          AND T2.PROJECT_CD = T3.PROJECT_CD
          AND T3.MDL_CD = 'MP'
          AND T3.OPTION_CD = 'MP_CYCLE'
          AND T1.GB = T3.OPTION_VAL    
    )MST;
   
    
--     exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'M4E_I301010 버전관리  테이블 UPDATE', '00START';

    --버전관리 // MaxTimeIndex 
    UPDATE M4E_I301010
    SET TO_YYMMDD = @V_MODI_PLAN_YYMMDD
    WHERE PROJECT_CD = @V_PROJECT_CD
      AND MP_VRSN_ID = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ = @V_SEQ
    ;
    
    
--    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'M4E_I301010 버전관리  테이블 UPDATE', '00END';

    --MaxTimeIndex / 엔진 옵션 
    SELECT @V_MaxTimeIndex = EG_OPTION_VAL
    FROM   M4E_I301040
    WHERE  1=1
      AND PROJECT_CD  = @V_PROJECT_CD
      AND MP_VRSN_ID  = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ = @V_SEQ
      AND EG_OPTION_CD = 'MaxTimeIndex'
    ;
    
    --MaxTimeIndex / 엔진 옵션 
    SELECT @V_BUCKET_TYPE = EG_OPTION_VAL
    FROM   M4E_I301040
    WHERE  1=1
      AND PROJECT_CD  = @V_PROJECT_CD
      AND MP_VRSN_ID  = @V_MP_VRSN_ID
      AND MP_VRSN_SEQ = @V_SEQ
      AND EG_OPTION_CD = 'BUCKET_TYPE'
    ;
    
    
    --21.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(21)M4E_I301050 공급계획 실행 CALENDAR 정보  테이블 INSERT', '21.START';

/***************************************************************************************************
 ** 시나리오 관리(엔진 옵션) BUCKET_TYPE 따른 엔진 CALENDAR 생성
****************************************************************************************************/

    IF @V_BUCKET_TYPE = 'MONTH' BEGIN
    	WITH TA AS
	(
		SELECT 1 LEVEL
		UNION ALL
		SELECT LEVEL + 1 FROM TA WHERE LEVEL + 1 <= @V_MaxTimeIndex + 1
	)
	, SUB AS
	(
		SELECT T2.* 
		FROM TA T2 -- option(maxrecursion 0)
	) 
        INSERT INTO M4E_I301050
        (   PROJECT_CD
          , MP_VRSN_ID
          , MP_VRSN_SEQ
          , TIME_INDEX
          , START_YYMMDD
          , END_YYMMDD
          , CREATE_USER_CD
          , CREATE_DATE
        )    
        (
            SELECT @V_PROJECT_CD                                                            AS PROJECT_CD
                  ,@V_MP_VRSN_ID                                                            AS MP_VRSN_ID
                  ,@V_SEQ                                                                   AS MP_VRSN_SEQ
                  ,T1.TIME_INDEX             + (T2.LEVEL - 1)                                    AS TIME_INDEX 
                  ,FORMAT(DATEADD(MONTH, +(T2.LEVEL - 1), CONVERT(DATE, T1.START_YYMMDD) ), 'yyyyMMdd')                     AS START_YYMMDD 
                  ,FORMAT(DATEADD(MONTH, +(T2.LEVEL - 1), CONVERT(DATE, T1.END_YYMMDD) ), 'yyyyMMdd')                    AS END_YYMMDD
                  ,@V_USER_CD                                                               AS CREATE_USER_CD
                  ,GETDATE()                                                                 AS CREATE_DATE
            FROM 
            (
            SELECT 0                                                                       AS TIME_INDEX
                  ,FORMAT(DATEADD(MONTH, -1, CONVERT(DATE,@V_PLAN_YYMMDD)),'yyyyMMdd')              AS START_YYMMDD
                  ,FORMAT(DATEADD(DAY, -1, CONVERT(DATE, @V_PLAN_YYMMDD)),'yyyyMMdd')                            AS END_YYMMDD    
            ) T1
            , SUB T2
        );                
    END
    ELSE BEGIN
        --공급계획 실행 CALENDAR 정보
        WITH TA AS
	(
		SELECT 1 LEVEL
		UNION ALL
		SELECT LEVEL + 1 FROM TA WHERE LEVEL + 1 <= @V_MaxTimeIndex + 1
	)
	, SUB AS
	(
		SELECT T2.* 
		FROM TA T2 
	)
        INSERT INTO M4E_I301050
        (   PROJECT_CD
          , MP_VRSN_ID
          , MP_VRSN_SEQ
          , TIME_INDEX
          , START_YYMMDD
          , END_YYMMDD
          , CREATE_USER_CD
          , CREATE_DATE
        )    
        (
            SELECT @V_PROJECT_CD                                             AS PROJECT_CD
                  ,@V_MP_VRSN_ID                                             AS MP_VRSN_ID
                  ,@V_SEQ                                                    AS MP_VRSN_SEQ
                  ,T1.TIME_INDEX             + (T2.LEVEL - 1)                     AS TIME_INDEX 
                  ,FORMAT(DATEADD(DAY,   + (T2.LEVEL - 1)*7, CONVERT(DATE, T1.START_YYMMDD)), 'yyyyMMdd')      AS START_YYMMDD 
                  ,FORMAT(DATEADD(DAY,   + (T2.LEVEL - 1)*7, CONVERT(DATE, T1.END_YYMMDD)), 'yyyyMMdd')      AS END_YYMMDD
                  ,@V_USER_CD                                                AS CREATE_USER_CD
                  ,GETDATE()                                                  AS CREATE_DATE
            FROM 
            (
            SELECT 0                                                        AS TIME_INDEX
                  ,FORMAT(DATEADD(DAY, -7, CONVERT(DATE, @V_PLAN_YYMMDD)),'yyyyMMdd')              AS START_YYMMDD
                  ,FORMAT(DATEADD(DAY, -1, CONVERT(DATE,@V_PLAN_YYMMDD)),'yyyyMMdd')             AS END_YYMMDD
            ) T1
            , SUB T2
        );
    END

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(21)M4E_I301050 공급계획 실행 CALENDAR 정보  테이블 INSERT', '21.END';
    --21.END--
    
    

    --22.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(22)M4E_I301080 공급계획 실행 제품정보  테이블 INSERT', '22.START';

    -- 공급계획 실행 제품정보
    
    -- 원자재 제외 (공정 자재테이블에서 반제품, 완제품의 공장코드)
    INSERT INTO M4E_I301080
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ENG_ITEM_CD
      , ITEM_CD
      , ITEM_NM
      , PLANT_CD
      , ITEM_TYPE_CD
      , ITEM_GRP_CD
      , ITEM_CTGRI_CD
      , INF_ITEM_YN
      , SAFETY_STOCK_YN
      , CREATE_USER_CD
      , CREATE_DATE
    )   
    (
    SELECT @V_PROJECT_CD              AS PROJECT_CD
         , @V_MP_VRSN_ID              AS MP_VRSN_ID
         , @V_SEQ                     AS MP_VRSN_SEQ 
         , CASE WHEN T2.PLANT_CD IS NULL 
            THEN T1.ITEM_CD 
            ELSE T1.ITEM_CD +'@' + T2.PLANT_CD 
            END                      AS ENG_ITEM_CD
         , T1.ITEM_CD
         , T1.ITEM_NM
         , T2.PLANT_CD               AS PLANT_CD
         , T1.ITEM_TYPE_CD
         , T1.ITEM_GRP_CD
         , T1.ITEM_CTGRI_CD
         , T1.INF_ITEM_YN
         ,CASE WHEN T3.ITEM_CD IS NULL 
                THEN 'N' ELSE 'Y'
            END                      AS SAFETY_STOCK_YN         
         ,@V_USER_CD                 AS CREATE_USER_CD     
         ,GETDATE()                   AS CREATE_DATE
    FROM 
    (
        SELECT ITEM_CD 
              ,ITEM_NM
              ,ITEM_TYPE_CD
              ,ITEM_GRP_CD
              ,ITEM_CTGRI_CD
              ,INF_ITEM_YN
         FROM M4S_I002040 -- ITEM
        WHERE 1=1
          AND PROJECT_CD = @V_PROJECT_CD
          AND ITEM_TYPE_CD = 'SG'
          --AND USE_YN     = 'Y'
    ) T1
    LEFT JOIN 
    (
        SELECT DISTINCT PROJECT_CD 
              ,IF_VRSN_ID
              ,ITEM_CD
        FROM M4S_I002160 --안전재고 관리
        WHERE 1 = 1
          AND PROJECT_CD = @V_PROJECT_CD
    )T3 
           ON T1.ITEM_CD        = T3.ITEM_CD
          AND T3.IF_VRSN_ID     = @V_IF_VRSN
    INNER JOIN 
    (
        SELECT IN_ITEM_CD
              ,PLANT_CD
          FROM M4S_I305140 -- 공정 자재
         WHERE 1=1
           AND PROJECT_CD     = @V_PROJECT_CD
           AND IF_VRSN_ID     = @V_IF_VRSN
         GROUP BY IN_ITEM_CD, PLANT_CD
    )T2
            ON T1.ITEM_CD = T2.IN_ITEM_CD       
    UNION ALL
	SELECT @V_PROJECT_CD              AS PROJECT_CD
			, @V_MP_VRSN_ID              AS MP_VRSN_ID
			, @V_SEQ                     AS MP_VRSN_SEQ 
			, T1.ENG_ITEM_CD
			, T1.ITEM_CD
			, T1.ITEM_NM
			, T1.PLANT_CD
			, T1.ITEM_TYPE_CD
			, T1.ITEM_GRP_CD
			, T1.ITEM_CTGRI_CD
			, T1.INF_ITEM_YN
			, T1.SAFETY_STOCK_YN         
			,@V_USER_CD                 AS CREATE_USER_CD     
			,GETDATE()                   AS CREATE_DATE
	FROM
		(
			SELECT CASE WHEN T2.PLANT_CD IS NULL 
					THEN 'M_'+T1.ITEM_GRP_CD 
					ELSE 'M_'+T1.ITEM_GRP_CD +'@' + T2.PLANT_CD 
					END                      AS ENG_ITEM_CD
				 , 'M_'+T1.ITEM_GRP_CD AS ITEM_CD
				 , SUBSTRING(T1.ITEM_NM,1,2) AS ITEM_NM
				 , T2.PLANT_CD               AS PLANT_CD
				 , T1.ITEM_TYPE_CD
				 , T1.ITEM_GRP_CD
				 , T1.ITEM_CTGRI_CD
				 , T1.INF_ITEM_YN
				 ,CASE WHEN T3.ITEM_CD IS NULL 
						THEN 'N' ELSE 'Y'
					END                      AS SAFETY_STOCK_YN  
			FROM 
			(
				SELECT ITEM_CD 
					  ,ITEM_NM
					  ,ITEM_TYPE_CD
					  ,ITEM_GRP_CD
					  ,ITEM_CTGRI_CD
					  ,INF_ITEM_YN
				 FROM M4S_I002040 -- ITEM
				WHERE 1=1
				  AND PROJECT_CD = @V_PROJECT_CD
				  AND ITEM_TYPE_CD = 'FG'
			--      AND ITEM_GRP_CD IN INSTR(VS_ITEM_GRP,ITEM_GRP_CD)--('AB/A','KR-A')
				  AND CHARINDEX(ITEM_GRP_CD, @V_ITEM_GRP) > 0--('AB/A','KR-A')
				  --AND USE_YN     = 'Y'
			) T1
			LEFT JOIN 
			(
				SELECT DISTINCT PROJECT_CD 
					  ,IF_VRSN_ID
					  ,ITEM_CD
				FROM M4S_I002160 --안전재고 관리
				WHERE 1 = 1
				  AND PROJECT_CD = @V_PROJECT_CD
			)T3 
				   ON T1.ITEM_CD        = T3.ITEM_CD
				  AND T3.IF_VRSN_ID     = @V_IF_VRSN
			INNER JOIN 
			(
				SELECT IN_ITEM_CD
					  ,PLANT_CD
				  FROM M4S_I305140 -- 공정 자재
				 WHERE 1=1
				   AND PROJECT_CD     = @V_PROJECT_CD
				   AND IF_VRSN_ID     = @V_IF_VRSN
				 GROUP BY IN_ITEM_CD, PLANT_CD
			)T2
					ON T1.ITEM_CD = T2.IN_ITEM_CD       
			GROUP BY  CASE WHEN T2.PLANT_CD IS NULL 
					THEN 'M_'+T1.ITEM_GRP_CD 
					ELSE 'M_'+T1.ITEM_GRP_CD +'@' + T2.PLANT_CD 
					END                      
				 , 'M_'+T1.ITEM_GRP_CD 
				 , SUBSTRING(T1.ITEM_NM,1,2) 
				 , T2.PLANT_CD              
				 , T1.ITEM_TYPE_CD
				 , T1.ITEM_GRP_CD
				 , T1.ITEM_CTGRI_CD
				 , T1.INF_ITEM_YN
				 ,CASE WHEN T3.ITEM_CD IS NULL 
						THEN 'N' ELSE 'Y'
					END         
		) T1
    UNION ALL
    SELECT @V_PROJECT_CD              AS PROJECT_CD
         , @V_MP_VRSN_ID              AS MP_VRSN_ID
         , @V_SEQ                     AS MP_VRSN_SEQ 
         , CASE WHEN T2.PLANT_CD IS NULL 
            THEN T1.ITEM_CD 
            ELSE T1.ITEM_CD +'@' + T2.PLANT_CD 
            END                      AS ENG_ITEM_CD
         , T1.ITEM_CD
         , T1.ITEM_NM
         , T2.PLANT_CD               AS PLANT_CD
         , T1.ITEM_TYPE_CD
         , T1.ITEM_GRP_CD
         , T1.ITEM_CTGRI_CD
         , T1.INF_ITEM_YN
         ,CASE WHEN T3.ITEM_CD IS NULL 
                THEN 'N' ELSE 'Y'
            END                      AS SAFETY_STOCK_YN         
         ,@V_USER_CD                 AS CREATE_USER_CD     
         ,GETDATE()                   AS CREATE_DATE
    FROM 
    (
        SELECT ITEM_CD 
              ,ITEM_NM
              ,ITEM_TYPE_CD
              ,ITEM_GRP_CD
              ,ITEM_CTGRI_CD
              ,INF_ITEM_YN
         FROM M4S_I002040 -- ITEM
        WHERE 1=1
          AND PROJECT_CD = @V_PROJECT_CD
          AND ITEM_TYPE_CD = 'FG'
    --      AND ITEM_GRP_CD IN INSTR(VS_ITEM_GRP,ITEM_GRP_CD)--('AB/A','KR-A')
          AND CHARINDEX(ITEM_GRP_CD, @V_ITEM_GRP) = 0--('AB/A','KR-A')
          --AND USE_YN     = 'Y'
    ) T1
    LEFT JOIN 
    (
        SELECT DISTINCT PROJECT_CD 
              ,IF_VRSN_ID
              ,ITEM_CD
        FROM M4S_I002160 --안전재고 관리
        WHERE 1 = 1
          AND PROJECT_CD = @V_PROJECT_CD
    )T3 
           ON T1.ITEM_CD        = T3.ITEM_CD
          AND T3.IF_VRSN_ID     = @V_IF_VRSN
    INNER JOIN 
    (
        SELECT IN_ITEM_CD
              ,PLANT_CD
          FROM M4S_I305140 -- 공정 자재
         WHERE 1=1
           AND PROJECT_CD     = @V_PROJECT_CD
           AND IF_VRSN_ID     = @V_IF_VRSN
         GROUP BY IN_ITEM_CD, PLANT_CD
    )T2
            ON T1.ITEM_CD = T2.IN_ITEM_CD          
    )     
    ;
    
    -- 원자재 
    INSERT INTO M4E_I301080
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ENG_ITEM_CD
      , ITEM_CD
      , ITEM_NM
      , PLANT_CD
      , ITEM_TYPE_CD
      , ITEM_GRP_CD
      , ITEM_CTGRI_CD
      , INF_ITEM_YN
      , SAFETY_STOCK_YN
      , CREATE_USER_CD
      , CREATE_DATE
    )   
    (
        SELECT @V_PROJECT_CD              AS PROJECT_CD
             , @V_MP_VRSN_ID              AS MP_VRSN_ID
             , @V_SEQ                     AS MP_VRSN_SEQ 
             , CASE WHEN T2.PLANT_CD IS NULL 
                THEN T1.ITEM_CD 
                ELSE T1.ITEM_CD +'@' + T2.PLANT_CD 
                END                      AS ENG_ITEM_CD
             , T1.ITEM_CD
             , T1.ITEM_NM
             , T2.PLANT_CD               AS PLANT_CD
             , T1.ITEM_TYPE_CD
             , T1.ITEM_GRP_CD
             , T1.ITEM_CTGRI_CD
             , T1.INF_ITEM_YN
             ,CASE WHEN T3.ITEM_CD IS NULL 
                    THEN 'N' ELSE 'Y'
                END                      AS SAFETY_STOCK_YN      
             ,@V_USER_CD                 AS CREATE_USER_CD      
             ,GETDATE()                   AS CREATE_DATE
        FROM 
        (
            SELECT ITEM_CD 
                  ,ITEM_NM
                  ,ITEM_TYPE_CD
                  ,ITEM_GRP_CD
                  ,ITEM_CTGRI_CD
                  ,INF_ITEM_YN
             FROM M4S_I002040 -- ITEM
            WHERE 1=1
              AND PROJECT_CD   =  @V_PROJECT_CD
              AND ITEM_TYPE_CD = 'RM' 
              --AND USE_YN     = 'Y'
        ) T1
        LEFT JOIN 
        (
            SELECT DISTINCT PROJECT_CD 
                  ,IF_VRSN_ID
                  ,ITEM_CD
            FROM M4S_I002160 --안전재고 관리
            WHERE 1 = 1
              AND PROJECT_CD = @V_PROJECT_CD
        )T3 
               ON T1.ITEM_CD        = T3.ITEM_CD
              AND T3.IF_VRSN_ID     = @V_IF_VRSN
        INNER JOIN 
        (
            SELECT OUT_ITEM_CD
                  ,PLANT_CD
              FROM M4S_I305130 -- 자재 공정
             WHERE 1=1
               AND PROJECT_CD     = @V_PROJECT_CD
               AND IF_VRSN_ID     = @V_IF_VRSN
             GROUP BY OUT_ITEM_CD
                     ,PLANT_CD   
        )T2
                ON T1.ITEM_CD     = T2.OUT_ITEM_CD    
    )     
    ;    
    
    ----------------------------BOD TO 제품 정보 
    
    IF @V_EG_TYPE_CD = 'MP' BEGIN 
        --공급계획 실행 제품 
        INSERT INTO M4E_I301080
            (   PROJECT_CD
              , MP_VRSN_ID
              , MP_VRSN_SEQ
              , ENG_ITEM_CD
              , ITEM_CD
              , ITEM_NM
              , PLANT_CD
              , ITEM_TYPE_CD
              , ITEM_GRP_CD
              , ITEM_CTGRI_CD
              , INF_ITEM_YN
              , SAFETY_STOCK_YN
              , CREATE_USER_CD
              , CREATE_DATE
            )   
            (   
                SELECT @V_PROJECT_CD              AS PROJECT_CD
                     , @V_MP_VRSN_ID              AS MP_VRSN_ID
                     , @V_SEQ                     AS MP_VRSN_SEQ 
                     , T1.ITEM_CD+'@'+T1.TO_PLANT_CD AS ENG_ITEM_CD 
                     , T1.ITEM_CD
                     , T2.ITEM_NM
                     , T1.TO_PLANT_CD
                     , T2.ITEM_TYPE_CD
                     , T2.ITEM_GRP_CD
                     , T2.ITEM_CTGRI_CD
                     , 'N'--T2.INF_ITEM_YN
                     , CASE WHEN T3.ITEM_CD IS NULL 
                        THEN 'N' ELSE 'Y'
                        END                      AS SAFETY_STOCK_YN   
                     , @V_USER_CD                 AS CREATE_USER_CD      
                     ,GETDATE()                   AS CREATE_DATE   
                FROM M4S_I305120 T1-- BOD
                INNER JOIN M4S_I002040 T2
                   ON T1.PROJECT_CD = T2.PROJECT_CD
                  AND T1.ITEM_CD    = T2.ITEM_CD
                LEFT JOIN 
                (
                    SELECT DISTINCT PROJECT_CD 
                          ,IF_VRSN_ID
                          ,ITEM_CD
                    FROM M4S_I002160 --안전재고 관리
                    WHERE 1 = 1
                      AND PROJECT_CD = @V_PROJECT_CD
                )T3   
                   ON T1.PROJECT_CD = T3.PROJECT_CD
                  AND T1.ITEM_CD = T3.ITEM_CD  
                WHERE 1=1
                  AND T1.PROJECT_CD = @V_PROJECT_CD
                  AND T1.IF_VRSN_ID = @V_IF_VRSN
                GROUP BY T1.ITEM_CD+'@'+T1.TO_PLANT_CD
                     , T1.ITEM_CD
                     , T2.ITEM_NM
                     , T1.TO_PLANT_CD
                     , T2.ITEM_TYPE_CD
                     , T2.ITEM_GRP_CD
                     , T2.ITEM_CTGRI_CD
                     , T2.INF_ITEM_YN
                     , CASE WHEN T3.ITEM_CD IS NULL 
                        THEN 'N' ELSE 'Y'
                        END 
            )
            ;       


    ----------------------------BOD TO 제품 정보 
    
    
    ----------------------------BOD FROM 제품 정보

/***************************************************************************************************
 ** BOD TO와 중복되는 BOD FROM의 ITEM_TYPE을 SG로 변경 (InventoryBalanceConstraint)
****************************************************************************************************/

        MERGE INTO M4E_I301080 T1 --공급계획 실행 제품 
        USING (
                SELECT @V_PROJECT_CD              AS PROJECT_CD
                     , @V_MP_VRSN_ID              AS MP_VRSN_ID
                     , @V_SEQ                     AS MP_VRSN_SEQ 
                     , T1.ITEM_CD+'@'+T1.FROM_PLANT_CD AS ENG_ITEM_CD 
                     , T1.ITEM_CD
                     , T2.ITEM_NM
                     , T1.FROM_PLANT_CD
                     , T2.ITEM_TYPE_CD
                     , T2.ITEM_GRP_CD
                     , T2.ITEM_CTGRI_CD
                     , T2.INF_ITEM_YN
                     , CASE WHEN T3.ITEM_CD IS NULL 
                        THEN 'N' ELSE 'Y'
                        END                      AS SAFETY_STOCK_YN      
                     , @V_USER_CD                 AS CREATE_USER_CD      
                     , GETDATE()                   AS CREATE_DATE                           
                FROM M4S_I305120 T1-- BOD
                INNER JOIN M4S_I002040 T2
                   ON T1.PROJECT_CD = T2.PROJECT_CD
                  AND T1.ITEM_CD    = T2.ITEM_CD
                LEFT JOIN 
                (
                    SELECT DISTINCT PROJECT_CD 
                          ,IF_VRSN_ID
                          ,ITEM_CD
                    FROM M4S_I002160 --안전재고 관리
                    WHERE 1 = 1
                      AND PROJECT_CD = @V_PROJECT_CD--V_PROJECT_CD
                )T3   
                   ON T1.PROJECT_CD = T3.PROJECT_CD
                  AND T1.ITEM_CD = T3.ITEM_CD  
                WHERE 1=1
                  AND T1.PROJECT_CD = @V_PROJECT_CD
                  AND T1.IF_VRSN_ID = @V_IF_VRSN
                GROUP BY T1.ITEM_CD+'@'+T1.FROM_PLANT_CD 
                     , T1.ITEM_CD
                     , T2.ITEM_NM
                     , T1.FROM_PLANT_CD
                     , T2.ITEM_TYPE_CD
                     , T2.ITEM_GRP_CD
                     , T2.ITEM_CTGRI_CD
                     , T2.INF_ITEM_YN
                     , CASE WHEN T3.ITEM_CD IS NULL 
                        THEN 'N' ELSE 'Y'
                        END                                   
        ) T2
        ON (T1.PROJECT_CD = T2.PROJECT_CD 
            AND T1.MP_VRSN_ID = T2.MP_VRSN_ID
            AND T1.MP_VRSN_SEQ = T2.MP_VRSN_SEQ 
            AND T1.ENG_ITEM_CD = T2.ENG_ITEM_CD)
        WHEN MATCHED THEN 
            UPDATE SET 
                T1.ITEM_TYPE_CD       =   'SG'
        WHEN NOT MATCHED THEN
            INSERT 
                (   PROJECT_CD
                  , MP_VRSN_ID
                  , MP_VRSN_SEQ
                  , ENG_ITEM_CD
                  , ITEM_CD
                  , ITEM_NM
                  , PLANT_CD
                  , ITEM_TYPE_CD
                  , ITEM_GRP_CD
                  , ITEM_CTGRI_CD
                  , INF_ITEM_YN
                  , SAFETY_STOCK_YN
                  , CREATE_USER_CD
                  , CREATE_DATE
                )   
            VALUES
                (   T2.PROJECT_CD
                  , T2.MP_VRSN_ID
                  , T2.MP_VRSN_SEQ
                  , T2.ENG_ITEM_CD
                  , T2.ITEM_CD
                  , T2.ITEM_NM
                  , T2.FROM_PLANT_CD
                  , T2.ITEM_TYPE_CD
                  , T2.ITEM_GRP_CD
                  , T2.ITEM_CTGRI_CD
                  , T2.INF_ITEM_YN
                  , T2.SAFETY_STOCK_YN
                  , T2.CREATE_USER_CD
                  , T2.CREATE_DATE
                );       

    END      
    ----------------------------BOD FROM 제품 정보 


    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(22)M4E_I301080 공급계획 실행 제품정보  테이블 INSERT', '22.END';
    --22.END--

    
    
    --23.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(23)M4E_I301060 공급계획 실행 DEMAND 정보 테이블 INSERT', '23.START';
	--SET @STR = '(23)M4E_I301060 공급계획 실행 DEMAND 정보 테이블 INSERT' + @V_IF_VRSN + '___' + @V_PROJECT_CD + '___' + @V_MP_VRSN_ID + '___' + @V_SEQ + '___' + @V_USER_CD + '___' ;

    --공급계획 실행 DEMAND 정보
    INSERT INTO M4E_I301060
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , MP_KEY
      , DP_KEY
      , SOLD_CUST_GRP_CD
      , SHIP_CUST_GRP_CD
      , ENG_ITEM_CD
      , TIME_INDEX
      , REQ_MP_QTY
      , PRORT_VAL
      , UNIT_PRICE
      , COST_PRICE
      , PLANT_CD
      , ITEM_CD
      , AHEAD_LIMIT_VAL
      , LATE_LIMIT_VAL
      , SHIP_AHEAD_LIMIT_VAL
      , SHIP_LATE_LIMIT_VAL
      , CREATE_USER_CD
      , CREATE_DATE
    )    
    ( 
		SELECT DISTINCT T1.PROJECT_CD
				,T1.MP_VRSN_ID
				,T1.MP_VRSN_SEQ
				,T1.MP_KEY
				,T1.DP_KEY
				,T1.SOLD_CUST_GRP_CD
				,T1.SHIP_CUST_GRP_CD
				,T1.ENG_ITEM_CD
				,T1.TIME_INDEX
				,T1.REQ_MP_QTY 
				,T1.PRORT_VAL
				,T1.DP_PRICE 
				,T1.COST_PRICE
	--              ,T3.PLANT_CD
				,T1.PLANT_CD
				,T1.ITEM_CD
				,T1.AHEAD_LIMIT_VAL
				,T1.LATE_LIMIT_VAL
				,T1.SHIP_AHEAD_LIMIT_VAL
				,T1.SHIP_LATE_LIMIT_VAL
				,T1.CREATE_USER_CD
				,T1.CREATE_DATE
		FROM
			(
			  SELECT @V_PROJECT_CD              AS PROJECT_CD
					  ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					  ,@V_SEQ                     AS MP_VRSN_SEQ
					  ,T1.MP_KEY
					  ,T1.DP_KEY
					  ,T1.SOLD_CUST_GRP_CD
					  ,T1.SHIP_CUST_GRP_CD
		--              ,T3.ENG_ITEM_CD           AS ENG_ITEM_CD
					  ,T1.ITEM_CD +'@'+ T1.PLANT_CD AS ENG_ITEM_CD
					  ,T2.TIME_INDEX                  AS TIME_INDEX
					  ,T1.REQ_MP_QTY
					  ,T1.PRORT_VAL
					  ,DP_PRICE
					  ,COST_PRICE
		--              ,T3.PLANT_CD
					  ,T1.PLANT_CD
					  ,T1.ITEM_CD
					  ,T1.AHEAD_LIMIT_VAL
					  ,T1.LATE_LIMIT_VAL
					  ,T1.SHIP_AHEAD_LIMIT_VAL
					  ,T1.SHIP_LATE_LIMIT_VAL
					  ,@V_USER_CD                 AS CREATE_USER_CD
					  ,GETDATE()                   AS CREATE_DATE
				FROM M4S_I305020 T1             -- DEMAND
				LEFT JOIN M4E_I301050 T2        -- CALENDAR
					   ON T1.PROJECT_CD      =  T2.PROJECT_CD
					  AND T1.REQ_MP_YYMMDD   BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
		--        LEFT JOIN M4E_I301080 T3       -- 제품
		--               ON T1.PROJECT_CD      =  T3.PROJECT_CD
		--              AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
		--              AND T1.ITEM_CD         = T3.ITEM_CD
		--              AND T3.MP_VRSN_SEQ     = @V_SEQ
				LEFT JOIN M4E_I301080 T4
				ON T1.PROJECT_CD = T4.PROJECT_CD
				  AND T1.ITEM_CD = T4.ITEM_CD
				WHERE 1=1
				  AND T1.PROJECT_CD = @V_PROJECT_CD
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND T4.ENG_ITEM_CD	IS NOT NULL
				  AND T2.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T2.MP_VRSN_SEQ     =  @V_SEQ
				  AND T4.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T4.MP_VRSN_SEQ     =  @V_SEQ
			UNION ALL
			SELECT T1.PROJECT_CD
					,T1.MP_VRSN_ID
					,T1.MP_VRSN_SEQ
					,MAX(T1.MP_KEY)             AS MP_KEY
					,MAX(T1.DP_KEY)             AS DP_KEY
					,T1.SOLD_CUST_GRP_CD
					,T1.SHIP_CUST_GRP_CD
					,T1.ENG_ITEM_CD
					,T1.TIME_INDEX
					,SUM(T1.REQ_MP_QTY) AS REQ_MP_QTY 
					,T1.PRORT_VAL
					,MAX(DP_PRICE) AS DP_PRICE 
					,MAX(COST_PRICE) AS  COST_PRICE
		--              ,T3.PLANT_CD
					,T1.PLANT_CD
					,T1.ITEM_GRP_CD
					,T1.AHEAD_LIMIT_VAL
					,T1.LATE_LIMIT_VAL
					,T1.SHIP_AHEAD_LIMIT_VAL
					,T1.SHIP_LATE_LIMIT_VAL
					,T1.CREATE_USER_CD
					,T1.CREATE_DATE
			FROM
					(
						SELECT @V_PROJECT_CD              AS PROJECT_CD
							  ,@V_MP_VRSN_ID              AS MP_VRSN_ID
							  ,@V_SEQ                     AS MP_VRSN_SEQ
							  , T1.MP_KEY             AS MP_KEY
							  ,T1.DP_KEY             AS DP_KEY
							  ,T1.SOLD_CUST_GRP_CD
							  ,T1.SHIP_CUST_GRP_CD
							  ,'M_'+T5.ITEM_GRP_CD +'@'+ T1.PLANT_CD  AS ENG_ITEM_CD
							  ,T2.TIME_INDEX                  AS TIME_INDEX
							  ,T1.REQ_MP_QTY AS REQ_MP_QTY 
							  ,T1.PRORT_VAL
							  ,DP_PRICE AS DP_PRICE 
							  ,COST_PRICE AS  COST_PRICE
							  ,T1.PLANT_CD
							  ,'M_'+T5.ITEM_GRP_CD AS ITEM_GRP_CD
							  ,T1.AHEAD_LIMIT_VAL
							  ,T1.LATE_LIMIT_VAL
							  ,T1.SHIP_AHEAD_LIMIT_VAL
							  ,T1.SHIP_LATE_LIMIT_VAL
							  ,@V_USER_CD                 AS CREATE_USER_CD
							  ,GETDATE()                   AS CREATE_DATE
						FROM M4S_I305020 T1             -- DEMAND
						LEFT JOIN M4E_I301050 T2        -- CALENDAR
							   ON T1.PROJECT_CD      =  T2.PROJECT_CD
							  AND T1.REQ_MP_YYMMDD   BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
							  AND T2.MP_VRSN_ID      =  @V_MP_VRSN_ID
							  AND T2.MP_VRSN_SEQ     =  @V_SEQ
				--        INNER JOIN M4E_I301080 T3       -- 제품
				--               ON T1.PROJECT_CD      =  T3.PROJECT_CD
				--              AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
				--              AND T1.ITEM_CD         = T3.ITEM_CD
				--              AND T3.MP_VRSN_SEQ     = @V_SEQ
						INNER JOIN M4S_I002040 T5
						ON T1.PROJECT_CD = T5.PROJECT_CD
						AND T1.ITEM_CD = T5.ITEM_CD	
						LEFT JOIN M4E_I301080 T4
						ON T1.PROJECT_CD = T4.PROJECT_CD
						  AND T4.MP_VRSN_ID      =  @V_MP_VRSN_ID
						  AND T4.MP_VRSN_SEQ     =  @V_SEQ
						  AND T1.ITEM_CD = T4.ITEM_CD
						WHERE 1=1
						  AND T1.PROJECT_CD = @V_PROJECT_CD
						  AND T1.IF_VRSN_ID = @V_IF_VRSN
						  AND T4.ENG_ITEM_CD	IS NULL 
						) T1   
					GROUP BY T1.PROJECT_CD
							,T1.MP_VRSN_ID
							,T1.MP_VRSN_SEQ
							,T1.ENG_ITEM_CD 
							,T1.SOLD_CUST_GRP_CD
							,T1.SHIP_CUST_GRP_CD
							,T1.ENG_ITEM_CD 
							,T1.TIME_INDEX  
							,T1.PRORT_VAL
							,T1.PLANT_CD
							,T1.ITEM_GRP_CD
							,T1.AHEAD_LIMIT_VAL
							,T1.LATE_LIMIT_VAL
							,T1.SHIP_AHEAD_LIMIT_VAL
							,T1.SHIP_LATE_LIMIT_VAL
							,T1.CREATE_USER_CD
							,T1.CREATE_DATE
			) T1
    )   
    ;

	SELECT DISTINCT T1.PROJECT_CD
				,T1.MP_VRSN_ID
				,T1.MP_VRSN_SEQ
				,T1.MP_KEY
				,T1.DP_KEY
				,T1.SOLD_CUST_GRP_CD
				,T1.SHIP_CUST_GRP_CD
				,T1.ENG_ITEM_CD
				,T1.TIME_INDEX
				,T1.REQ_MP_QTY 
				,T1.PRORT_VAL
				,T1.DP_PRICE 
				,T1.COST_PRICE
	--              ,T3.PLANT_CD
				,T1.PLANT_CD
				,T1.ITEM_CD
				,T1.AHEAD_LIMIT_VAL
				,T1.LATE_LIMIT_VAL
				,T1.SHIP_AHEAD_LIMIT_VAL
				,T1.SHIP_LATE_LIMIT_VAL
				,T1.CREATE_USER_CD
				,T1.CREATE_DATE
		FROM
			(
			  SELECT @V_PROJECT_CD              AS PROJECT_CD
					  ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					  ,@V_SEQ                     AS MP_VRSN_SEQ
					  ,T1.MP_KEY
					  ,T1.DP_KEY
					  ,T1.SOLD_CUST_GRP_CD
					  ,T1.SHIP_CUST_GRP_CD
		--              ,T3.ENG_ITEM_CD           AS ENG_ITEM_CD
					  ,T1.ITEM_CD +'@'+ T1.PLANT_CD AS ENG_ITEM_CD
					  ,T2.TIME_INDEX                  AS TIME_INDEX
					  ,T1.REQ_MP_QTY
					  ,T1.PRORT_VAL
					  ,DP_PRICE
					  ,COST_PRICE
		--              ,T3.PLANT_CD
					  ,T1.PLANT_CD
					  ,T1.ITEM_CD
					  ,T1.AHEAD_LIMIT_VAL
					  ,T1.LATE_LIMIT_VAL
					  ,T1.SHIP_AHEAD_LIMIT_VAL
					  ,T1.SHIP_LATE_LIMIT_VAL
					  ,@V_USER_CD                 AS CREATE_USER_CD
					  ,GETDATE()                   AS CREATE_DATE
				FROM M4S_I305020 T1             -- DEMAND
				LEFT JOIN M4E_I301050 T2        -- CALENDAR
					   ON T1.PROJECT_CD      =  T2.PROJECT_CD
					  AND T1.REQ_MP_YYMMDD   BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
		--        LEFT JOIN M4E_I301080 T3       -- 제품
		--               ON T1.PROJECT_CD      =  T3.PROJECT_CD
		--              AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
		--              AND T1.ITEM_CD         = T3.ITEM_CD
		--              AND T3.MP_VRSN_SEQ     = @V_SEQ
				LEFT JOIN M4E_I301080 T4
				ON T1.PROJECT_CD = T4.PROJECT_CD
				  AND T1.ITEM_CD = T4.ITEM_CD
				WHERE 1=1
				  AND T1.PROJECT_CD = @V_PROJECT_CD
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND T4.ENG_ITEM_CD	IS NOT NULL
				  AND T2.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T2.MP_VRSN_SEQ     =  @V_SEQ
				  AND T4.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T4.MP_VRSN_SEQ     =  @V_SEQ
			UNION ALL
			SELECT T1.PROJECT_CD
					,T1.MP_VRSN_ID
					,T1.MP_VRSN_SEQ
					,MAX(T1.MP_KEY)             AS MP_KEY
					,MAX(T1.DP_KEY)             AS DP_KEY
					,T1.SOLD_CUST_GRP_CD
					,T1.SHIP_CUST_GRP_CD
					,T1.ENG_ITEM_CD
					,T1.TIME_INDEX
					,SUM(T1.REQ_MP_QTY) AS REQ_MP_QTY 
					,T1.PRORT_VAL
					,MAX(DP_PRICE) AS DP_PRICE 
					,MAX(COST_PRICE) AS  COST_PRICE
		--              ,T3.PLANT_CD
					,T1.PLANT_CD
					,T1.ITEM_GRP_CD
					,T1.AHEAD_LIMIT_VAL
					,T1.LATE_LIMIT_VAL
					,T1.SHIP_AHEAD_LIMIT_VAL
					,T1.SHIP_LATE_LIMIT_VAL
					,T1.CREATE_USER_CD
					,T1.CREATE_DATE
			FROM
					(
						SELECT @V_PROJECT_CD              AS PROJECT_CD
							  ,@V_MP_VRSN_ID              AS MP_VRSN_ID
							  ,@V_SEQ                     AS MP_VRSN_SEQ
							  , T1.MP_KEY             AS MP_KEY
							  ,T1.DP_KEY             AS DP_KEY
							  ,T1.SOLD_CUST_GRP_CD
							  ,T1.SHIP_CUST_GRP_CD
							  ,'M_'+T5.ITEM_GRP_CD +'@'+ T1.PLANT_CD  AS ENG_ITEM_CD
							  ,T2.TIME_INDEX                  AS TIME_INDEX
							  ,T1.REQ_MP_QTY AS REQ_MP_QTY 
							  ,T1.PRORT_VAL
							  ,DP_PRICE AS DP_PRICE 
							  ,COST_PRICE AS  COST_PRICE
							  ,T1.PLANT_CD
							  ,'M_'+T5.ITEM_GRP_CD AS ITEM_GRP_CD
							  ,T1.AHEAD_LIMIT_VAL
							  ,T1.LATE_LIMIT_VAL
							  ,T1.SHIP_AHEAD_LIMIT_VAL
							  ,T1.SHIP_LATE_LIMIT_VAL
							  ,@V_USER_CD                 AS CREATE_USER_CD
							  ,GETDATE()                   AS CREATE_DATE
						FROM M4S_I305020 T1             -- DEMAND
						LEFT JOIN M4E_I301050 T2        -- CALENDAR
							   ON T1.PROJECT_CD      =  T2.PROJECT_CD
							  AND T1.REQ_MP_YYMMDD   BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
							  AND T2.MP_VRSN_ID      =  @V_MP_VRSN_ID
							  AND T2.MP_VRSN_SEQ     =  @V_SEQ
				--        INNER JOIN M4E_I301080 T3       -- 제품
				--               ON T1.PROJECT_CD      =  T3.PROJECT_CD
				--              AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
				--              AND T1.ITEM_CD         = T3.ITEM_CD
				--              AND T3.MP_VRSN_SEQ     = @V_SEQ
						INNER JOIN M4S_I002040 T5
						ON T1.PROJECT_CD = T5.PROJECT_CD
						AND T1.ITEM_CD = T5.ITEM_CD	
						LEFT JOIN M4E_I301080 T4
						ON T1.PROJECT_CD = T4.PROJECT_CD
						  AND T4.MP_VRSN_ID      =  @V_MP_VRSN_ID
						  AND T4.MP_VRSN_SEQ     =  @V_SEQ
						  AND T1.ITEM_CD = T4.ITEM_CD
						WHERE 1=1
						  AND T1.PROJECT_CD = @V_PROJECT_CD
						  AND T1.IF_VRSN_ID = @V_IF_VRSN
						  AND T4.ENG_ITEM_CD	IS NULL 
						) T1   
					GROUP BY T1.PROJECT_CD
							,T1.MP_VRSN_ID
							,T1.MP_VRSN_SEQ
							,T1.ENG_ITEM_CD 
							,T1.SOLD_CUST_GRP_CD
							,T1.SHIP_CUST_GRP_CD
							,T1.ENG_ITEM_CD 
							,T1.TIME_INDEX  
							,T1.PRORT_VAL
							,T1.PLANT_CD
							,T1.ITEM_GRP_CD
							,T1.AHEAD_LIMIT_VAL
							,T1.LATE_LIMIT_VAL
							,T1.SHIP_AHEAD_LIMIT_VAL
							,T1.SHIP_LATE_LIMIT_VAL
							,T1.CREATE_USER_CD
							,T1.CREATE_DATE
			) T1
				;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(23)M4E_I301060 공급계획 실행 DEMAND 정보 테이블 INSERT', '23.END';
    --23.END--    
    
    
    
    --24.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(24)M4E_I301090 공급계획 실행 공정정보 테이블 INSERT', '24.START';

    -- 공급계획 실행 공정정보
    INSERT INTO M4E_I301090
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ROUTE_CD
      , ROUTE_NM
      , ROUTE_TYPE_CD
      , ROUTE_GRP_CD
      , ROUTE_SEQ
      , MIN_LOT_VAL
      , MAX_LOT_VAL
      , MULTI_LOT_VAL
      , LT_VAL
      , SHIP_LT_VAL
      , FIX_TIME_INDEX
      , PROD_START_TIME_INDEX
      , PROD_STOP_TIME_INDEX
      , PRE_SHIP_YN
      , DESCR
      , CREATE_USER_CD
      , CREATE_DATE
    )   
    (
		SELECT DISTINCT T1.PROJECT_CD
              ,T1.MP_VRSN_ID
              ,T1.MP_VRSN_SEQT_CD 
              ,T1.ROUTE_CD
              ,T1.ROUTE_NM 
              ,ROUTE_TYPE_CD
              ,T1.ROUTE_GRP_CD 
              ,T1.ROUTE_SEQ 
              ,T1.MIN_LOT_VAL         
              ,T1.MAX_LOT_VAL
              ,T1.MULTI_LOT_VAL
              ,T1.LT_VAL
              ,T1.SHIP_LT_VAL
              ,T1.FIX_TIME_INDEX
              ,T1.PROD_START_TIME_INDEX
              ,T1.PROD_STOP_TIME_INDEX
              ,T1.PRE_SHIP_YN
              ,T1.DESCR
              ,T1.CREATE_USER_CD
              ,T1.CREATE_DATE
        FROM
		(
           SELECT @V_PROJECT_CD              AS PROJECT_CD
              ,@V_MP_VRSN_ID              AS MP_VRSN_ID
              ,@V_SEQ                     AS MP_VRSN_SEQT_CD 
              ,T1.ROUTE_CD+'@'+T1.ITEM_CD+'@'+T1.PLANT_CD  AS ROUTE_CD
              ,T1.ROUTE_NM AS ROUTE_NM 
              ,ROUTE_TYPE_CD
              ,'F'                       AS ROUTE_GRP_CD 
              ,1                         AS ROUTE_SEQ 
              ,T1.MIN_LOT_VAL         
              ,T1.MAX_LOT_VAL
              ,T1.MULTI_LOT_VAL
              ,T1.LT_VAL
              ,T1.SHIP_LT_VAL
              ,ISNULL(T5.TIME_INDEX,0)           AS FIX_TIME_INDEX
              ,ISNULL(T2.TIME_INDEX,1)           AS PROD_START_TIME_INDEX
              ,ISNULL(T3.TIME_INDEX,@V_MaxTimeIndex)  AS PROD_STOP_TIME_INDEX
              ,T1.PRE_SHIP_YN
              ,T1.DESCR
              ,@V_USER_CD  AS CREATE_USER_CD
              ,GETDATE()	AS CREATE_DATE
        FROM M4S_I305070 T1
        LEFT JOIN M4E_I301050 T2 -- 공급계획 실행 CALENDAR 정보
               ON T1.PROJECT_CD  = T2.PROJECT_CD
              AND T2.MP_VRSN_ID  = @V_MP_VRSN_ID
              AND T2.MP_VRSN_SEQ = @V_SEQ
              AND T1.PROD_START_YYMMDD >= T2.START_YYMMDD
              AND T1.PROD_START_YYMMDD <= T2.END_YYMMDD
        LEFT JOIN M4E_I301050 T3 -- 공급계획 실행 CALENDAR 정보
               ON T1.PROJECT_CD  = T3.PROJECT_CD
              AND T3.MP_VRSN_ID  = @V_MP_VRSN_ID
              AND T3.MP_VRSN_SEQ = @V_SEQ
              AND T1.PROD_STOP_YYMMDD >= T3.START_YYMMDD
              AND T1.PROD_STOP_YYMMDD <= T3.END_YYMMDD
        LEFT JOIN M4E_I301050 T5 -- 공급계획 실행 CALENDAR 정보
               ON T1.PROJECT_CD  = T5.PROJECT_CD
              AND T1.FIXED_DATE  BETWEEN T5.START_YYMMDD AND T5.END_YYMMDD
              AND T5.MP_VRSN_ID  = @V_MP_VRSN_ID
              AND T5.MP_VRSN_SEQ = @V_SEQ
        LEFT JOIN M4E_I301080 T6 
        ON T1.PROJECT_CD = T6.PROJECT_CD
          AND T6.MP_VRSN_ID      =  @V_MP_VRSN_ID
          AND T6.MP_VRSN_SEQ     =  @V_SEQ
          AND T1.ITEM_CD         =   T6.ITEM_CD
        INNER JOIN M4S_I002040 T7
        ON T1.PROJECT_CD = T7.PROJECT_CD
        AND T1.ITEM_CD = T7.ITEM_CD          
        WHERE 1=1 
          AND T1.PROJECT_CD = @V_PROJECT_CD
          AND T1.USE_YN = 'Y'
          AND T1.IF_VRSN_ID = @V_IF_VRSN
          AND ROUTE_TYPE_CD = 'BOM'
          AND T6.ITEM_CD IS NOT NULL
UNION ALL   
		SELECT @V_PROJECT_CD              AS PROJECT_CD
				,@V_MP_VRSN_ID              AS MP_VRSN_ID
				,@V_SEQ                     AS MP_VRSN_SEQT_CD 
				,T1.ROUTE_CD
				,T1.ROUTE_NM
				,ROUTE_TYPE_CD
				,'F'                       AS ROUTE_GRP_CD 
				,1                         AS ROUTE_SEQ 
				,T1.MIN_LOT_VAL         
				,T1.MAX_LOT_VAL
				,T1.MULTI_LOT_VAL
				,T1.LT_VAL
				,T1.SHIP_LT_VAL
				,T1.FIX_TIME_INDEX
				,T1.PROD_START_TIME_INDEX
				,T1.PROD_STOP_TIME_INDEX
				,T1.PRE_SHIP_YN
				,T1.DESCR
				, @V_USER_CD	AS CREATE_USER_CD
				,GETDATE()		AS CREATE_DATE
		FROM
			(
				SELECT T1.ROUTE_CD+'@'+'M_'+T7.ITEM_GRP_CD+'@'+T1.PLANT_CD  AS ROUTE_CD
					  ,NCHAR(T1.ROUTE_CD+' '+'M_'+T7.ITEM_GRP_CD) AS ROUTE_NM
					  ,T1.ROUTE_TYPE_CD
					  ,T1.MIN_LOT_VAL         
					  ,T1.MAX_LOT_VAL
					  ,T1.MULTI_LOT_VAL
					  ,T1.LT_VAL
					  ,T1.SHIP_LT_VAL
					  ,ISNULL(T5.TIME_INDEX,0)           AS FIX_TIME_INDEX
					  ,ISNULL(T2.TIME_INDEX,1)           AS PROD_START_TIME_INDEX
					  ,ISNULL(T3.TIME_INDEX, @V_MaxTimeIndex)  AS PROD_STOP_TIME_INDEX
					  ,T1.PRE_SHIP_YN
					  ,T1.DESCR
				FROM M4S_I305070 T1
				LEFT JOIN M4E_I301050 T2 -- 공급계획 실행 CALENDAR 정보
					   ON T1.PROJECT_CD  = T2.PROJECT_CD
					  AND T2.MP_VRSN_ID  = @V_MP_VRSN_ID
					  AND T2.MP_VRSN_SEQ = @V_SEQ
					  AND T1.PROD_START_YYMMDD >= T2.START_YYMMDD
					  AND T1.PROD_START_YYMMDD <= T2.END_YYMMDD
				LEFT JOIN M4E_I301050 T3 -- 공급계획 실행 CALENDAR 정보
					   ON T1.PROJECT_CD  = T3.PROJECT_CD
					  AND T3.MP_VRSN_ID  = @V_MP_VRSN_ID
					  AND T3.MP_VRSN_SEQ = @V_SEQ
					  AND T1.PROD_STOP_YYMMDD >= T3.START_YYMMDD
					  AND T1.PROD_STOP_YYMMDD <= T3.END_YYMMDD
				LEFT JOIN M4E_I301050 T5 -- 공급계획 실행 CALENDAR 정보
					   ON T1.PROJECT_CD  = T5.PROJECT_CD
					  AND T1.FIXED_DATE  BETWEEN T5.START_YYMMDD AND T5.END_YYMMDD
					  AND T5.MP_VRSN_ID  = @V_MP_VRSN_ID
					  AND T5.MP_VRSN_SEQ = @V_SEQ
				LEFT JOIN M4E_I301080 T6 
				ON T1.PROJECT_CD = T6.PROJECT_CD
				  AND T6.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T6.MP_VRSN_SEQ     =  @V_SEQ
				  AND T1.ITEM_CD         =   T6.ITEM_CD
				INNER JOIN M4S_I002040 T7
				ON T1.PROJECT_CD = T7.PROJECT_CD
				AND T1.ITEM_CD = T7.ITEM_CD          
				WHERE 1=1 
				  AND T1.PROJECT_CD = @V_PROJECT_CD
				  AND T1.USE_YN = 'Y'
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND ROUTE_TYPE_CD = 'BOM'
				  AND T6.ITEM_CD IS NULL
			  GROUP BY T1.ROUTE_CD+'@'+'M_'+T7.ITEM_GRP_CD+'@'+T1.PLANT_CD 
					  ,T1.ROUTE_CD+' '+'M_'+T7.ITEM_GRP_CD 
					  ,T1.ROUTE_TYPE_CD               
					  ,T1.MIN_LOT_VAL         
					  ,T1.MAX_LOT_VAL
					  ,T1.MULTI_LOT_VAL
					  ,T1.LT_VAL
					  ,T1.SHIP_LT_VAL
					  ,ISNULL(T5.TIME_INDEX,0)           
					  ,ISNULL(T2.TIME_INDEX,1)        
					  ,ISNULL(T3.TIME_INDEX, @V_MaxTimeIndex)  
					  ,T1.PRE_SHIP_YN
					  ,T1.DESCR
			) T1
		)T1
    )
    ;
    
    ---------------------------------------------------------------------------------------------------------------
    -- 공급계획 실행 공정정보 -- BOD 
    -- BOD 관련 공정 정보는 공정 관리에서 생성 X, BOD 테이블에서 공정 생성  
    ---------------------------------------------------------------------------------------------------------------
    
    INSERT INTO M4E_I301090
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ROUTE_CD
      , ROUTE_NM
      , ROUTE_TYPE_CD
      , ROUTE_GRP_CD
      , ROUTE_SEQ
      , MIN_LOT_VAL
      , MAX_LOT_VAL
      , MULTI_LOT_VAL
      , LT_VAL
      , SHIP_LT_VAL
      , FIX_TIME_INDEX
      , PROD_START_TIME_INDEX
      , PROD_STOP_TIME_INDEX
      , PRE_SHIP_YN
      , DESCR
      , CREATE_USER_CD
      , CREATE_DATE
    )  
    SELECT A.PROJECT_CD
          ,@V_MP_VRSN_ID AS VRSN_ID
          ,@V_SEQ AS VRSN_SEQ
          ,A.TRNSP_TYPE_CD +'@'+ A.ITEM_CD + '@' + A.FROM_PLANT_CD + '@' + A.TO_PLANT_CD AS ROUTE_CD
          ,A.TRNSP_TYPE_CD +'@'+ A.ITEM_CD + '@' + A.FROM_PLANT_CD + '@' + A.TO_PLANT_CD AS ROUTE_NM
          ,'BOD' AS ROUTE_TYPE
          ,'BOD' AS ROUTE_GRP
          ,1     AS ROUTE_SEQ
          ,ISNULL(A.MIN_LOT_VAL,1) AS MIN_LOT
          ,ISNULL(A.MAX_LOT_VAL,1) AS MAX_LOT
          ,ISNULL(A.MULTI_LOT_VAL,1) AS MULTI_LOT
          ,A.LT_VAL
          ,A.SHIP_LT_VAL
          ,ISNULL(B.TIME_INDEX,0) AS FIX_TIME_INDEX
          ,ISNULL(C.TIME_INDEX,1) AS PROD_START_TIME_INDEX
          ,ISNULL(D.TIME_INDEX,@V_MaxTimeIndex) AS PROD_START_TIME_INDEX
          ,A.PRE_SHIP_YN
          ,NULL AS DESCR
          ,@V_USER_CD
          ,GETDATE()
      FROM M4S_I305120 A
      LEFT JOIN
            (
                SELECT PROJECT_CD
                      ,TIME_INDEX
                      ,START_YYMMDD
                      ,END_YYMMDD
                  FROM M4E_I301050
                 WHERE PROJECT_CD   = @V_PROJECT_CD
                   AND MP_VRSN_ID   = @V_MP_VRSN_ID
                   AND MP_VRSN_SEQ  = @V_SEQ
            )B
        ON A.PROJECT_CD  = B.PROJECT_CD
       AND A.FIXED_DATE  BETWEEN B.START_YYMMDD AND B.END_YYMMDD
       LEFT JOIN
            (
                SELECT PROJECT_CD
                      ,TIME_INDEX
                      ,START_YYMMDD
                      ,END_YYMMDD
                  FROM M4E_I301050
                 WHERE PROJECT_CD   = @V_PROJECT_CD
                   AND MP_VRSN_ID   = @V_MP_VRSN_ID
                   AND MP_VRSN_SEQ  = @V_SEQ
            )C
        ON A.PROJECT_CD  = C.PROJECT_CD
       AND A.START_YYMMDD  BETWEEN C.START_YYMMDD AND C.END_YYMMDD      
       LEFT JOIN
            (
                SELECT PROJECT_CD
                      ,TIME_INDEX
                      ,START_YYMMDD
                      ,END_YYMMDD
                  FROM M4E_I301050
                 WHERE PROJECT_CD   = @V_PROJECT_CD
                   AND MP_VRSN_ID   = @V_MP_VRSN_ID
                   AND MP_VRSN_SEQ  = @V_SEQ
            )D
        ON A.PROJECT_CD  = D.PROJECT_CD
       AND A.END_YYMMDD  BETWEEN D.START_YYMMDD AND D.END_YYMMDD
     WHERE 1=1
       AND A.PROJECT_CD = @V_PROJECT_CD
       AND A.IF_VRSN_ID = @V_IF_VRSN
    ;
    
    ----------------------------------------------------------------------------------------------------------------
    
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(24)M4E_I301090 공급계획 실행 공정정보 테이블 INSERT', '24.END';
    --24.END--
    
    
    
    --25.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(25)M4E_I301100 공급계획 실행 설비정보 테이블 INSERT', '25.START';
    
    -- 공급계획 실행 설비정보
    INSERT INTO M4E_I301100
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , RES_CD
      , RES_NM
      , RES_SEQ
      , RES_TYPE_CD
      , RES_GRP_CD
      , RES_CAPA_VAL
      , CAPA_UNIT_CD
      , START_TIME_INDEX
      , END_TIME_INDEX
      , DESCR
      , INF_CAPA_YN
      , CREATE_USER_CD
      , CREATE_DATE
    )    
    (
        SELECT  @V_PROJECT_CD              AS PROJECT_CD
               ,@V_MP_VRSN_ID              AS MP_VRSN_ID
               ,@V_SEQ                     AS MP_VRSN_SEQ
               ,T1.RES_CD+'@'+T1.PLANT_CD
               ,T1.RES_NM
               ,T1.RES_SEQ
               ,T1.RES_TYPE_CD
               ,T1.RES_GRP_CD
               ,T1.RES_CAPA_VAL
               ,T1.CAPA_UNIT_CD
               ,T2.TIME_INDEX AS START_TIME_INDEX
               ,T3.TIME_INDEX AS END_TIME_INDEX
               ,DESCR
               ,T1.INF_CAPA_YN
               ,@V_USER_CD                 AS CREATE_USER_CD
               ,GETDATE()                   AS CREATE_DATE
        FROM M4S_I305090 T1   
        LEFT JOIN M4E_I301050 T2 -- 공급계획 실행 CALENDAR 정보
               ON T1.PROJECT_CD  = T2.PROJECT_CD
              AND T2.MP_VRSN_ID  = @V_MP_VRSN_ID 
              AND T2.MP_VRSN_SEQ = @V_SEQ
                AND T1.START_YYMMDD >= T2.START_YYMMDD
                AND T1.START_YYMMDD <= T2.END_YYMMDD
        LEFT JOIN M4E_I301050 T3 -- 공급계획 실행 CALENDAR 정보
               ON T1.PROJECT_CD  = T3.PROJECT_CD
              AND T3.MP_VRSN_ID  = @V_MP_VRSN_ID
              AND T3.MP_VRSN_SEQ = @V_SEQ 
                AND T1.END_YYMMDD >= T3.START_YYMMDD
                AND T1.END_YYMMDD <= T3.END_YYMMDD
        WHERE T1.PROJECT_CD = @V_PROJECT_CD
          AND T1.IF_VRSN_ID = @V_IF_VRSN     
          AND T1.USE_YN = 'Y'
    )
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(25)M4E_I301100 공급계획 실행 설비정보 테이블 INSERT', '25.END';
    --25.END--
    
    
    
    --26.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(26)M4E_I301110 공급계획 실행 CAPA 정보 테이블 INSERT', '26.START';
    
     -- 공급계획 실행 CAPA 정보
     INSERT INTO M4E_I301110
     (  PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , RES_CD
      , TIME_INDEX
      , RES_CAPA_VAL
      , OVER_CAPA_VAL
      , CAPA_UNIT_CD
      , CREATE_USER_CD
      , CREATE_DATE
    )   
    (
        SELECT  @V_PROJECT_CD              AS PROJECT_CD
               ,@V_MP_VRSN_ID              AS MP_VRSN_ID
               ,@V_SEQ                     AS MP_VRSN_SEQ
               ,MT.RES_CD+'@'+MT.PLANT_CD AS RES_CD 
               ,ST.TIME_INDEX
               ,MT.RES_CAPA_VAL
               ,MT.OVER_CAPA_VAL
               ,MT.CAPA_UNIT_CD
               ,@V_USER_CD                 AS CREATE_USER_CD
               ,GETDATE()                   AS CREATE_DATE
      FROM (
            SELECT T1.PLANT_CD
                  ,T1.RES_CD
                  ,T2.TIME_INDEX AS START_INDEX
                  ,T3.TIME_INDEX AS END_INDEX
                  ,T1.RES_CAPA_VAL
                  ,T1.OVER_CAPA_VAL
                  ,T1.CAPA_UNIT_CD 
              FROM M4S_I305170 T1
                  ,M4E_I301050 T2
                  ,M4E_I301050 T3
             WHERE T1.PROJECT_CD    = T2.PROJECT_CD
               AND T1.PROJECT_CD    = T3.PROJECT_CD             
               AND T1.START_YYMMDD  BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
               AND T1.END_YYMMDD    BETWEEN T3.START_YYMMDD AND T3.END_YYMMDD
               AND T1.PROJECT_CD    = @V_PROJECT_CD
               AND T1.IF_VRSN_ID    = @V_IF_VRSN
               AND T2.MP_VRSN_ID    = @V_MP_VRSN_ID
               AND T2.MP_VRSN_SEQ   = @V_SEQ
               AND T3.MP_VRSN_ID    = @V_MP_VRSN_ID
               AND T3.MP_VRSN_SEQ   = @V_SEQ
        )MT,
        (
            SELECT*
              FROM M4E_I301050
             WHERE PROJECT_CD    = @V_PROJECT_CD
               AND MP_VRSN_ID    = @V_MP_VRSN_ID
               AND MP_VRSN_SEQ   = @V_SEQ
        )ST
     WHERE MT.START_INDEX  <= ST.TIME_INDEX
       AND MT.END_INDEX    >= ST.TIME_INDEX     
    )  
    ;   
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(26)M4E_I301110 공급계획 실행 CAPA 정보 테이블 INSERT', '26.END';
    --26.END--
    
    
        
    --27.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(27)M4E_I301120 공급계획 실행 ROUTING 정보 테이블 INSERT', '27.START';    
    
    --공급계획 실행 ROUTING 정보
    INSERT INTO M4E_I301120
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ROUTE_CD
      , RES_CD
      , CAPA_USE_RATE
      , RES_EFCY_RATE
      , MIN_LOT_VAL
      , MAX_LOT_VAL
      , MULTI_LOT_VAL
      , FIX_TIME_INDEX
      , RES_PRORT_VAL
      , CREATE_USER_CD
      , CREATE_DATE
    )    
    (
		SELECT DISTINCT T1.PROJECT_CD
               ,T1.MP_VRSN_ID
               ,T1.MP_VRSN_SEQ
               ,T1.ROUTE_CD
               ,T1.RES_CD
               ,T1.CAPA_USE_RATE
               ,T1.RES_EFCY_RATE
               ,T1.MIN_LOT_VAL
               ,T1.MAX_LOT_VAL
               ,T1.MULTI_LOT_VAL
               ,T1.FIX_TIME_INDEX
               ,T1.RES_PRORT_VAL
               ,T1.CREATE_USER_CD
               ,T1.CREATE_DATE
        FROM
			(
			 SELECT  @V_PROJECT_CD              AS PROJECT_CD
					   ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					   ,@V_SEQ                     AS MP_VRSN_SEQ
					   ,T1.ROUTE_CD+'@'+T1.ITEM_CD+'@'+T1.PLANT_CD AS ROUTE_CD
					   ,T1.RES_CD+'@'+T1.PLANT_CD AS RES_CD
					   ,T1.CAPA_USE_RATE
					   ,1 AS RES_EFCY_RATE
					   ,T1.MIN_LOT_VAL
					   ,T1.MAX_LOT_VAL
					   ,T1.MULTI_LOT_VAL
					   ,null AS FIX_TIME_INDEX
					   ,T1.RES_PRORT_VAL
					   ,@V_USER_CD                 AS CREATE_USER_CD
					   ,GETDATE()                   AS CREATE_DATE
				FROM M4S_I305110 T1  
				INNER JOIN M4S_I002040 T2
				ON T1.PROJECT_CD = T2.PROJECT_CD
				AND T1.ITEM_CD = T2.ITEM_CD
				LEFT JOIN M4E_I301080 T3
				ON T1.PROJECT_CD = T3.PROJECT_CD
				  AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T3.MP_VRSN_SEQ     =  @V_SEQ
				  AND T1.ITEM_CD = T3.ITEM_CD
				WHERE 1=1 
				  AND T1.PROJECT_CD = @V_PROJECT_CD
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND T1.USE_YN     = 'Y'
				  AND T3.PROJECT_CD	IS NOT NULL
		UNION ALL
			SELECT  @V_PROJECT_CD              AS PROJECT_CD
					   ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					   ,@V_SEQ                     AS MP_VRSN_SEQ
					   ,T1.ROUTE_CD+'@M_'+T2.ITEM_GRP_CD+'@'+T1.PLANT_CD AS ROUTE_CD
					   ,T1.RES_CD+'@'+T1.PLANT_CD AS RES_CD
					   ,T1.CAPA_USE_RATE
					   ,1 AS RES_EFCY_RATE
					   ,T1.MIN_LOT_VAL
					   ,T1.MAX_LOT_VAL
					   ,T1.MULTI_LOT_VAL
					   ,null AS FIX_TIME_INDEX
					   ,T1.RES_PRORT_VAL
					   ,@V_USER_CD                 AS CREATE_USER_CD
					   ,GETDATE()                   AS CREATE_DATE
				FROM M4S_I305110 T1  
				INNER JOIN M4S_I002040 T2
				ON T1.PROJECT_CD = T2.PROJECT_CD
				AND T1.ITEM_CD = T2.ITEM_CD
				LEFT JOIN M4E_I301080 T3
				ON T1.PROJECT_CD = T3.PROJECT_CD
				  AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T3.MP_VRSN_SEQ     =  @V_SEQ
				  AND T1.ITEM_CD = T3.ITEM_CD
				WHERE 1=1 
				  AND T1.PROJECT_CD = @V_PROJECT_CD
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND T1.USE_YN     = 'Y'
				  AND T3.PROJECT_CD	IS NULL  
			) T1
    )
    ; 
     
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(27)M4E_I301120 공급계획 실행 ROUTING 정보 테이블 INSERT', '27.END'; 
    --27.END--
    
    --28.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(28)M4E_I301150 공급계획 실행 자재/공정 매핑  테이블 INSERT', '28.START';   

    --공급계획 실행 자재/공정 매핑 
    INSERT INTO M4E_I301150
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , OUT_ITEM_CD
      , ROUTE_CD
      , ITEM_OUT_QTY
      , PRORT_VAL
      , PLANT_CD
      , ITEM_CD
      , CREATE_USER_CD
      , CREATE_DATE
    )   
    (
		SELECT DISTINCT T1.PROJECT_CD
				,T1.MP_VRSN_ID
				,T1.MP_VRSN_SEQ
				,T1.OUT_ITEM_CD 
				,T1.ROUTE_CD 
				,T1.ITEM_OUT_QTY
				,T1.PRORT_VAL
				,T1.PLANT_CD
				,T1.ITEM_CD
				,T1.CREATE_USER_CD
				,T1.CREATE_DATE
		FROM
			(
				SELECT  @V_PROJECT_CD              AS PROJECT_CD
					   ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					   ,@V_SEQ                     AS MP_VRSN_SEQ
					   ,CASE WHEN T2.ENG_ITEM_CD IS NULL THEN T1.OUT_ITEM_CD ELSE T2.ENG_ITEM_CD END AS OUT_ITEM_CD 
					   ,T1.ROUTE_CD+'@'+T1.ITEM_CD+'@'+T1.PLANT_CD AS ROUTE_CD 
					   ,ISNULL(T1.ITEM_OUT_QTY,0)       AS ITEM_OUT_QTY
					   ,1 AS PRORT_VAL
					   ,T1.PLANT_CD
					   ,T1.ITEM_CD
					   ,@V_USER_CD                 AS CREATE_USER_CD
					   ,GETDATE()                   AS CREATE_DATE
				FROM M4S_I305130 T1
				LEFT JOIN M4E_I301080 T2
					ON T1.OUT_ITEM_CD = T2.ITEM_CD     
				   AND T1.PROJECT_CD = T2.PROJECT_CD
				   AND T2.MP_VRSN_ID = @V_MP_VRSN_ID
				   AND T2.MP_VRSN_SEQ = @V_SEQ    
				   AND T1.PLANT_CD = T2.PLANT_CD  
				LEFT JOIN M4E_I301080 T3 
				ON T1.PROJECT_CD = T3.PROJECT_CD
				  AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T3.MP_VRSN_SEQ     =  @V_SEQ
				  AND T1.ITEM_CD         =   T3.ITEM_CD           
				WHERE 1=1 
				  AND T1.PROJECT_CD = @V_PROJECT_CD
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND T1.USE_YN    = 'Y'
				  AND T3.PROJECT_CD	 IS NOT NULL
				UNION ALL
				SELECT  @V_PROJECT_CD              AS PROJECT_CD
					   ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					   ,@V_SEQ                     AS MP_VRSN_SEQ
					   ,T1.OUT_ITEM_CD 
					   ,T1.ROUTE_CD 
					   ,T1.ITEM_OUT_QTY
					   ,1 AS PRORT_VAL
					   ,T1.PLANT_CD
					   ,T1.ITEM_CD  
					   ,@V_USER_CD                 AS CREATE_USER_CD
					   ,GETDATE()                   AS CREATE_DATE
				FROM 
        			(
						SELECT  CASE WHEN T2.ENG_ITEM_CD IS NULL THEN T1.OUT_ITEM_CD ELSE T2.ENG_ITEM_CD END AS OUT_ITEM_CD 
							   ,T1.ROUTE_CD+'@M_'+T2.ENG_ITEM_CD AS ROUTE_CD 
							   ,ISNULL(T1.ITEM_OUT_QTY,0)       AS ITEM_OUT_QTY
							   ,T1.PLANT_CD
							   ,'M_'+T2.ITEM_CD AS ITEM_CD--T2.ENG_ITEM_CD  
						FROM M4S_I305130 T1
						LEFT JOIN M4E_I301080 T2
							ON T1.OUT_ITEM_CD = T2.ITEM_CD     
						   AND T1.PROJECT_CD = T2.PROJECT_CD
						   AND T2.MP_VRSN_ID = @V_MP_VRSN_ID
						   AND T2.MP_VRSN_SEQ = @V_SEQ    
						   AND T1.PLANT_CD = T2.PLANT_CD  
						LEFT JOIN M4E_I301080 T3 
						ON T1.PROJECT_CD = T3.PROJECT_CD
						  AND T3.MP_VRSN_ID      =  @V_MP_VRSN_ID
						  AND T3.MP_VRSN_SEQ     =  @V_SEQ
						  AND T1.ITEM_CD         =   T3.ITEM_CD           
						WHERE 1=1 
						  AND T1.PROJECT_CD = @V_PROJECT_CD
						  AND T1.IF_VRSN_ID = @V_IF_VRSN
						  AND T1.USE_YN    = 'Y'
						  AND T3.PROJECT_CD	 IS NULL
						GROUP BY CASE WHEN T2.ENG_ITEM_CD IS NULL THEN T1.OUT_ITEM_CD ELSE T2.ENG_ITEM_CD END
							   ,T1.ROUTE_CD+'@M_'+T2.ENG_ITEM_CD  
							   ,ISNULL(T1.ITEM_OUT_QTY,0)      
							   ,T1.PLANT_CD
							   ,'M_'+T2.ITEM_CD 
				) T1  
			) T1
    )
    ;  
    
    IF @V_EG_TYPE_CD = 'MP' BEGIN
        --공급계획 실행 자재/공정 매핑
        INSERT INTO M4E_I301150
        (
               PROJECT_CD
              ,MP_VRSN_ID
              ,MP_VRSN_SEQ
              ,OUT_ITEM_CD
              ,ROUTE_CD  
              ,ITEM_OUT_QTY
              ,PRORT_VAL
              ,PLANT_CD
              ,ITEM_CD
              ,CREATE_USER_CD
              ,CREATE_DATE    
        )
        (
            SELECT @V_PROJECT_CD                                         AS PROJECT_CD
                  ,@V_MP_VRSN_ID                                         AS MP_VRSN_ID
                  ,@V_SEQ 
                  ,T1.ITEM_CD +'@'+ T1.FROM_PLANT_CD                  AS OUT_ITEM_CD
                  ,T1.TRNSP_TYPE_CD +'@'+ T1.ITEM_CD + '@' + T1.FROM_PLANT_CD + '@' + T1.TO_PLANT_CD  AS  ROUTE_CD  
                  ,1                                                    AS ITEM_OUT_QTY
                  ,1                                                    AS PRORT_VAL
                  ,T1.FROM_PLANT_CD                                     AS PLANT_CD
                  ,T1.ITEM_CD
                  ,@V_USER_CD                                            AS CREATE_USER_CD
                  ,GETDATE()                                              AS CREATE_DATE
              FROM M4S_I305120 T1	--BOD 관리
    --          INNER JOIN M4E_I301080 T2 --공급계획 실행 제품 정보 
    --            ON T1.ITEM_CD       = T2.ITEM_CD     
    --           AND T1.PROJECT_CD    = T2.PROJECT_CD
    --           AND T2.MP_VRSN_ID    = @V_MP_VRSN_ID
    --           AND T2.MP_VRSN_SEQ   = @V_SEQ 
            WHERE 1=1 
              AND T1.PROJECT_CD = @V_PROJECT_CD
              AND T1.IF_VRSN_ID = @V_IF_VRSN
              AND T1.USE_YN = 'Y'
        )  
        ;
    END
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(28)M4E_I301150 공급계획 실행 자재/공정 매핑  테이블 INSERT', '28.END';
    --28.END--
    
    --29.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(29)M4E_I301160 공급계획 실행 공정/자재 매핑   테이블 INSERT', '29.START';
    
     --공급계획 실행 공정/자재 매핑 
    INSERT INTO M4E_I301160
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ROUTE_CD
      , IN_ITEM_CD
      , ITEM_IN_QTY
      , PRORT_VAL
      , PLANT_CD
      , ITEM_CD
      , CREATE_USER_CD
      , CREATE_DATE
    )  
    (
   SELECT  @V_PROJECT_CD              AS PROJECT_CD
               ,@V_MP_VRSN_ID              AS MP_VRSN_ID
               ,@V_SEQ                     AS MP_VRSN_SEQ
               ,T1.ROUTE_CD+'@'+T1.IN_ITEM_CD+'@'+T1.PLANT_CD AS ROUTE_CD 
               ,T2.ENG_ITEM_CD
               ,T1.ITEM_IN_QTY
               ,ISNULL(T1.PRORT_VAL,1) AS PRORT_VAL
               ,T1.PLANT_CD
               ,T1.IN_ITEM_CD AS ITEM_CD
               ,@V_USER_CD                 AS CREATE_USER_CD
               ,GETDATE()                   AS CREATE_DATE
        FROM M4S_I305140 T1
        LEFT JOIN M4E_I301080 T2
            ON T1.PLANT_CD = T2.PLANT_CD
           AND T1.IN_ITEM_CD = T2.ITEM_CD     
           AND T1.PROJECT_CD = T2.PROJECT_CD
           AND T2.MP_VRSN_ID = @V_MP_VRSN_ID
           AND T2.MP_VRSN_SEQ = @V_SEQ           
        WHERE 1=1 
          AND T1.PROJECT_CD = @V_PROJECT_CD
          AND T1.IF_VRSN_ID = @V_IF_VRSN
          AND T1.USE_YN    = 'Y'
          AND T2.PROJECT_CD	 IS NOT NULL
UNION ALL      
	SELECT  @V_PROJECT_CD              AS PROJECT_CD
               ,@V_MP_VRSN_ID              AS MP_VRSN_ID
               ,@V_SEQ                     AS MP_VRSN_SEQ
               ,T1.ROUTE_CD 
               ,T1.ENG_ITEM_CD
               ,T1.ITEM_IN_QTY
               ,T1.PRORT_VAL
               ,T1.PLANT_CD
               ,T1.ITEM_CD
               ,@V_USER_CD                 AS CREATE_USER_CD
               ,GETDATE()                   AS CREATE_DATE
        FROM 	    
        	(
		 	SELECT  T1.ROUTE_CD+'@M_'+T3.ITEM_GRP_CD+'@'+T1.PLANT_CD AS ROUTE_CD 
		               ,'M_'+T3.ITEM_GRP_CD+'@'+T1.PLANT_CD AS ENG_ITEM_CD
		               ,T1.ITEM_IN_QTY
		               ,ISNULL(T1.PRORT_VAL,1) AS PRORT_VAL
		               ,T1.PLANT_CD
		               ,'M_'+T3.ITEM_GRP_CD AS ITEM_CD
		        FROM M4S_I305140 T1
		        LEFT JOIN M4E_I301080 T2
		            ON T1.PLANT_CD = T2.PLANT_CD
		           AND T1.IN_ITEM_CD = T2.ITEM_CD     
		           AND T1.PROJECT_CD = T2.PROJECT_CD
		           AND T2.MP_VRSN_ID = @V_MP_VRSN_ID
		           AND T2.MP_VRSN_SEQ = @V_SEQ 
		        INNER JOIN M4S_I002040 T3
		        ON T1.PROJECT_CD = T3.PROJECT_CD
		        AND T1.IN_ITEM_CD = T3.ITEM_CD            
		        WHERE 1=1 
		          AND T1.PROJECT_CD = @V_PROJECT_CD
		          AND T1.IF_VRSN_ID = @V_IF_VRSN
		          AND T1.USE_YN    = 'Y'
		          AND T2.PROJECT_CD	 IS  NULL       
		        GROUP BY T1.ROUTE_CD+'@M_'+T3.ITEM_GRP_CD+'@'+T1.PLANT_CD  
		               ,'M_'+T3.ITEM_GRP_CD+'@'+T1.PLANT_CD 
		               ,T1.ITEM_IN_QTY
		               ,ISNULL(T1.PRORT_VAL,1) 
		               ,T1.PLANT_CD
		               ,'M_'+T3.ITEM_GRP_CD                        
    		) T1
    )
    ;
    
    IF @V_EG_TYPE_CD = 'MP' BEGIN 
         --공급계획 실행 공정/자재 매핑     
          INSERT INTO M4E_I301160
        (   PROJECT_CD
          , MP_VRSN_ID
          , MP_VRSN_SEQ
          , ROUTE_CD
          , IN_ITEM_CD
          , ITEM_IN_QTY
          , PRORT_VAL
          , PLANT_CD
          , ITEM_CD
          , CREATE_USER_CD
          , CREATE_DATE
        )  
        (
            SELECT @V_PROJECT_CD                                                  AS PROJECT_CD
                  ,@V_MP_VRSN_ID                                                  AS MP_VRSN_ID
                  ,@V_SEQ                                                         AS MP_VRSN_SEQ
                  ,T1.TRNSP_TYPE_CD +'@'+ T1.ITEM_CD + '@' + T1.FROM_PLANT_CD + '@' + T1.TO_PLANT_CD  AS ROUTE_CD  
                  ,T1.ITEM_CD +'@'+ T1.TO_PLANT_CD                             AS OUT_ITEM_CD
                  ,1                                                             AS IN_ITEM_QTY
                  ,1                                                             AS PRORT_VAL
                  ,T1.FROM_PLANT_CD                                              AS PLANT_CD
                  ,T1.ITEM_CD
                  ,@V_USER_CD                                                     AS CREATE_USER_CD
                  ,GETDATE()                                                       AS CREATE_DATE
              FROM M4S_I305120 T1	--BOD 관리
    --          INNER JOIN M4E_I301080 T2
    --            ON T1.ITEM_CD = T2.ITEM_CD     
    --           AND T1.PROJECT_CD = T2.PROJECT_CD
    --           AND T2.MP_VRSN_ID = @V_MP_VRSN_ID
    --           AND T2.MP_VRSN_SEQ = @V_SEQ 
            WHERE 1=1 
              AND T1.PROJECT_CD = @V_PROJECT_CD
              AND T1.IF_VRSN_ID = @V_IF_VRSN
              AND T1.USE_YN = 'Y'
        )
        ;  
    END
       
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(29)M4E_I301160 공급계획 실행 공정/자재 매핑   테이블 INSERT', '29.END';
    --29.END--
    
    
    
    --30.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(30)M4E_I301170공급계획 실행 재고정보   테이블 INSERT', '30.START';
    
    --공급계획 실행 재고정보
    INSERT INTO M4E_I301170
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ENG_ITEM_CD
      , TIME_INDEX
      , INV_TYPE_CD
      , ITEM_TYPE_CD
      , PLANT_CD
      , STRG_CD
      , GR_YYMMDD
      , INV_QTY
      , CREATE_USER_CD
      , CREATE_DATE
    )    
    (
        SELECT  @V_PROJECT_CD              AS PROJECT_CD
               ,@V_MP_VRSN_ID              AS MP_VRSN_ID
               ,@V_SEQ                     AS MP_VRSN_SEQ
              ,T3.ENG_ITEM_CD             AS ENG_ITEM_CD
              ,T2.TIME_INDEX              AS TIME_INDEX
              ,null                       AS INV_TYPE_CD
              ,null                       AS ITEM_TYPE_CD
              ,T1.PLANT_CD              
              ,T1.STRG_CD
              ,T1.YYMMDD       
              ,T1.INV_QTY
              ,@V_USER_CD                 AS CREATE_USER_CD
              ,GETDATE()                   AS CREATE_DATE
        FROM M4S_I002150 T1
        INNER JOIN M4E_I301050 T2 -- CALENDAR
               ON T1.PROJECT_CD      =  T2.PROJECT_CD
              AND T2.MP_VRSN_ID      =  @V_MP_VRSN_ID
              AND T1.YYMMDD   >=  T2.START_YYMMDD
              AND T1.YYMMDD   <=  T2.END_YYMMDD
              AND T2.MP_VRSN_SEQ     = @V_SEQ
        INNER JOIN M4E_I301080 T3       -- ITEM
               ON T1.PROJECT_CD      =  T3.PROJECT_CD
              AND T3.MP_VRSN_ID      = @V_MP_VRSN_ID
              AND T1.ITEM_CD         = T3.ITEM_CD
              AND T3.MP_VRSN_SEQ     = @V_SEQ
              AND T1.PLANT_CD = T3.PLANT_CD
        WHERE 1=1
          AND T1.PROJECT_CD = @V_PROJECT_CD
          AND T1.IF_VRSN_ID = @V_IF_VRSN
    )
    ;
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(30)M4E_I301170공급계획 실행 재고정보   테이블 INSERT', '30.END';
    --30.END--
    
    
    
    --31.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(31)M4E_I301121 공급계획 실행 ROUTING 정보 테이블 INSERT', '31.START';
    
    --공급계획 실행  시간별 ROUTING 정보
    INSERT INTO M4E_I301121
    (   PROJECT_CD
      , MP_VRSN_ID
      , MP_VRSN_SEQ
      , ROUTE_CD
      , RES_CD
      , TIME_INDEX
      , CAPA_USE_RATE
      , RES_EFCY_RATE
      , MIN_LOT_VAL
      , MAX_LOT_VAL
      , MULTI_LOT_VAL
      , FIX_TIME_INDEX
      , RES_PRORT_VAL
      , CREATE_USER_CD
      , CREATE_DATE
    )   
    (
		SELECT DISTINCT T1.PROJECT_CD
				,T1.MP_VRSN_ID
				,T1.MP_VRSN_SEQ
				,T1.ROUTE_CD
				,T1.RES_CD
				,T1.TIME_INDEX
				,T1.CAPA_USE_RATE 
				,T1.RES_EFCY_RATE
				,T1.MIN_LOT_VAL
				,T1.MAX_LOT_VAL
				,T1.MULTI_LOT_VAL
				,T1.FIX_TIME_INDEX
				,T1.RES_PRORT_VAL
				,T1.CREATE_USER_CD
				,T1.CREATE_DATE
		FROM
			(
				SELECT  @V_PROJECT_CD              AS PROJECT_CD
					   ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					   ,@V_SEQ                     AS MP_VRSN_SEQ
					   ,T1.ROUTE_CD +'@'+T1.ITEM_CD + '@' + T1.PLANT_CD AS ROUTE_CD
					   ,T1.RES_CD +'@'+ T1.PLANT_CD AS RES_CD
					   ,T2.TIME_INDEX
					   ,CASE WHEN T3.CAPA_USE_RATE IS NULL THEN T1.CAPA_USE_RATE ELSE T3.CAPA_USE_RATE END  AS CAPA_USE_RATE
					   ,1 AS RES_EFCY_RATE
					   ,T1.MIN_LOT_VAL
					   ,T1.MAX_LOT_VAL
					   ,T1.MULTI_LOT_VAL
					   ,NULL AS FIX_TIME_INDEX
					   ,T1.RES_PRORT_VAL
					   ,@V_USER_CD                 AS CREATE_USER_CD
					   ,GETDATE()                   AS CREATE_DATE
				FROM M4E_I301050 T2
				LEFT JOIN M4S_I305110 T1 
					   ON T1.PROJECT_CD = T2.PROJECT_CD
					  AND T1.IF_VRSN_ID	= @V_IF_VRSN         
				LEFT JOIN 
					(
						SELECT T1.ROUTE_CD
						  ,T1.PLANT_CD
						  ,T1.ITEM_CD
						  ,T2.TIME_INDEX AS START_INDEX
						  ,T3.TIME_INDEX AS END_INDEX
						  ,T1.RES_CD
						  ,T1.CAPA_USE_RATE
						  ,T1.MIN_LOT_VAL
						  ,T1.MAX_LOT_VAL
						  ,T1.MULTI_LOT_VAL
						  ,T1.FIXED_DATE
						  ,T1.RES_PRORT_VAL
						  FROM M4S_I305111 T1
							  ,M4E_I301050 T2
							  ,M4E_I301050 T3
						 WHERE T1.PROJECT_CD    = T2.PROJECT_CD
						   AND T1.PROJECT_CD    = T3.PROJECT_CD                 
						   AND T1.START_YYMMDD  BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
						   AND T1.END_YYMMDD    BETWEEN T3.START_YYMMDD AND T3.END_YYMMDD
						   AND T1.PROJECT_CD    = @V_PROJECT_CD
						   AND T1.IF_VRSN_ID    = @V_IF_VRSN
						   AND T2.MP_VRSN_ID    = @V_MP_VRSN_ID
						   AND T2.MP_VRSN_SEQ   = @V_SEQ
						   AND T3.MP_VRSN_ID    = @V_MP_VRSN_ID
						   AND T3.MP_VRSN_SEQ   = @V_SEQ
					) T3
					   ON T1.RES_CD = T3.RES_CD
					  AND T1.ROUTE_CD = T3.ROUTE_CD
					  AND T2.TIME_INDEX >= T3.START_INDEX
					  AND T2.TIME_INDEX <= T3.END_INDEX 
					  AND T3.ITEM_CD = T1.ITEM_CD 
					  AND T1.PLANT_CD = T3.PLANT_CD
				LEFT JOIN M4E_I301080 T4
				ON T1.PROJECT_CD = T4.PROJECT_CD
				  AND T4.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T4.MP_VRSN_SEQ     =  @V_SEQ
				  AND T1.ITEM_CD = T4.ITEM_CD               
				WHERE 1=1
				  AND T2.PROJECT_CD = @V_PROJECT_CD
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND T2.MP_VRSN_ID    = @V_MP_VRSN_ID
				  AND T2.MP_VRSN_SEQ   = @V_SEQ
				  AND T4.PROJECT_CD	IS NOT NULL
		UNION ALL
				SELECT  @V_PROJECT_CD              AS PROJECT_CD
					   ,@V_MP_VRSN_ID              AS MP_VRSN_ID
					   ,@V_SEQ                     AS MP_VRSN_SEQ
					   ,T1.ROUTE_CD +'@M_'+T5.ITEM_GRP_CD + '@' + T1.PLANT_CD AS ROUTE_CD
					   ,T1.RES_CD +'@'+ T1.PLANT_CD AS RES_CD
					   ,T2.TIME_INDEX
					   ,CASE WHEN T3.CAPA_USE_RATE IS NULL THEN T1.CAPA_USE_RATE ELSE T3.CAPA_USE_RATE END  
					   ,1 AS RES_EFCY_RATE
					   ,T1.MIN_LOT_VAL
					   ,T1.MAX_LOT_VAL
					   ,T1.MULTI_LOT_VAL
					   ,NULL AS FIX_TIME_INDEX
					   ,T1.RES_PRORT_VAL
					   ,@V_USER_CD                 AS CREATE_USER_CD
					   ,GETDATE()                   AS CREATE_DATE
				FROM M4E_I301050 T2
				LEFT JOIN M4S_I305110 T1 
					   ON T1.PROJECT_CD = T2.PROJECT_CD
					  AND T1.IF_VRSN_ID	= @V_IF_VRSN         
				LEFT JOIN 
					(
						SELECT T1.ROUTE_CD
						  ,T1.PLANT_CD
						  ,T1.ITEM_CD
						  ,T2.TIME_INDEX AS START_INDEX
						  ,T3.TIME_INDEX AS END_INDEX
						  ,T1.RES_CD
						  ,T1.CAPA_USE_RATE
						  ,T1.MIN_LOT_VAL
						  ,T1.MAX_LOT_VAL
						  ,T1.MULTI_LOT_VAL
						  ,T1.FIXED_DATE
						  ,T1.RES_PRORT_VAL
						  FROM M4S_I305111 T1
							  ,M4E_I301050 T2
							  ,M4E_I301050 T3
						 WHERE T1.PROJECT_CD    = T2.PROJECT_CD
						   AND T1.PROJECT_CD    = T3.PROJECT_CD                 
						   AND T1.START_YYMMDD  BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
						   AND T1.END_YYMMDD    BETWEEN T3.START_YYMMDD AND T3.END_YYMMDD
						   AND T1.PROJECT_CD    = @V_PROJECT_CD
						   AND T1.IF_VRSN_ID    = @V_IF_VRSN
						   AND T2.MP_VRSN_ID    = @V_MP_VRSN_ID
						   AND T2.MP_VRSN_SEQ   = @V_SEQ
						   AND T3.MP_VRSN_ID    = @V_MP_VRSN_ID
						   AND T3.MP_VRSN_SEQ   = @V_SEQ
					) T3
					   ON T1.RES_CD = T3.RES_CD
					  AND T1.ROUTE_CD = T3.ROUTE_CD
					  AND T2.TIME_INDEX >= T3.START_INDEX
					  AND T2.TIME_INDEX <= T3.END_INDEX 
					  AND T3.ITEM_CD = T1.ITEM_CD 
					  AND T1.PLANT_CD = T3.PLANT_CD
				LEFT JOIN M4E_I301080 T4
				ON T1.PROJECT_CD = T4.PROJECT_CD
				  AND T4.MP_VRSN_ID      =  @V_MP_VRSN_ID
				  AND T4.MP_VRSN_SEQ     =  @V_SEQ
				  AND T1.ITEM_CD = T4.ITEM_CD     
				INNER JOIN M4S_I002040 T5
				ON T1.PROJECT_CD = T5.PROJECT_CD
				AND T1.ITEM_CD = T5.ITEM_CD                    
				WHERE 1=1
				  AND T2.PROJECT_CD = @V_PROJECT_CD
				  AND T1.IF_VRSN_ID = @V_IF_VRSN
				  AND T2.MP_VRSN_ID    = @V_MP_VRSN_ID
				  AND T2.MP_VRSN_SEQ   = @V_SEQ
				  AND T4.PROJECT_CD	IS NULL  
			) T1
    )    
    ;    
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(31)M4E_I301121 공급계획 실행 ROUTING 정보 테이블 INSERT', '31.END';
    --31.END--
    
    
    
    --32.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(32)M4E_I301180 공급계획 실행 안전재고정보 테이블 INSERT', '32.START';

    --공급계획 실행 안전재고정보
    INSERT INTO M4E_I301180 
        (   PROJECT_CD
          , MP_VRSN_ID
          , MP_VRSN_SEQ
          , ENG_ITEM_CD
          , TIME_INDEX
          , SAFETY_INV_QTY
          , SAFETY_TYPE_CD
          , CREATE_USER_CD
          , CREATE_DATE
    )
    (
        SELECT  @V_PROJECT_CD             AS PROJECT_CD
               ,@V_MP_VRSN_ID             AS MP_VRSN_ID 
               ,@V_SEQ                    AS MP_VRSN_SEQ    --V_SEQ 
               ,T1.ENG_ITEM_CD
               ,T2.TIME_INDEX
               ,T2.SAFETY_INV_QTY
               ,'DAYS_OF_COVERAGE'       AS SAFETY_TYPE_CD
               ,@V_USER_CD                AS CREATE_USER_CD --V_USER_CD 
               ,GETDATE()                  AS CREATE_DATE
        FROM M4E_I301080 T1
            ,
            (
                SELECT T1.ITEM_CD
                      ,T2.TIME_INDEX
                      ,T1.SAFETY_INV_QTY
                  FROM M4S_I002160 T1-- 안전 재고 관리
                      ,M4E_I301050 T2--공급계획 실행 CALENDAR 정보
                 WHERE 1=1
                   AND T1.PROJECT_CD   = @V_PROJECT_CD
                   AND T1.IF_VRSN_ID   = @V_IF_VRSN
                   AND T1.PROJECT_CD   = T2.PROJECT_CD
                   AND T2.MP_VRSN_ID   = @V_MP_VRSN_ID
                   AND T2.MP_VRSN_SEQ  = @V_SEQ
                   AND T1.FROM_YYMMDD >= T2.START_YYMMDD
                   AND T1.FROM_YYMMDD <= T2.END_YYMMDD
                   AND T1.TO_YYMMDD   >= T2.START_YYMMDD
                   AND T1.TO_YYMMDD   <= T2.END_YYMMDD
            ) T2
         --M4S_I002160 T2-- 안전 재고 관리 
        WHERE 1=1 
          AND T1.PROJECT_CD  = @V_PROJECT_CD
          AND T1.MP_VRSN_ID  = @V_MP_VRSN_ID
          AND T1.MP_VRSN_SEQ = @V_SEQ
          AND T1.ITEM_CD = T2.ITEM_CD
    )
    ;

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(32)M4E_I301180 공급계획 실행 안전재고정보 테이블 INSERT', '32.END';
    --32.END--

    
    
    --33.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(33)M4E_I301200 공급계획 실행 창고 정보 테이블 INSERT', '33.START';

    -- 공급계획 실행 창고 정보
    INSERT INTO M4E_I301200  
    (    PROJECT_CD
       , MP_VRSN_ID
       , MP_VRSN_SEQ
       , PLANT_CD
       , STRG_CD
       , STRG_NM
       , STRG_CAPA_VAL
       , CAPA_UNIT_CD
       , CREATE_USER_CD
       , CREATE_DATE
    ) 
    (
        SELECT  @V_PROJECT_CD              AS PROJECT_CD
               ,@V_MP_VRSN_ID              AS MP_VRSN_ID
               ,@V_SEQ                     AS MP_VRSN_SEQ
               ,PLANT_CD
               ,STRG_CD
               ,STRG_NM
               ,STRG_CAPA_VAL
               ,CAPA_UNIT_CD
               ,@V_USER_CD                 AS CREATE_USER_CD
               ,GETDATE()                   AS CREATE_DATE
        FROM M4S_I305150 --창고 관리
        WHERE 1=1 
          AND PROJECT_CD = @V_PROJECT_CD
          AND IF_VRSN_ID = @V_IF_VRSN
    )
    ;

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(33)M4E_I301200 공급계획 실행 창고 정보 테이블 INSERT', '33.END';
    --33.END--
    
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(34)M4E_I301080 ITEM TYPE UPDATE', '34.START';
    /******************************
    * ITEM을 생성하는 ROUTE가 없을 경우 해당 제품은 RM으로 설정 
    * 2021.02.22.PSW
    ******************************/
    MERGE INTO M4E_I301080 TG
        USING 
        (
            SELECT A.PROJECT_CD
                  ,A.MP_VRSN_ID
                  ,A.MP_VRSN_SEQ
                  ,A.OUT_ITEM_CD
              FROM M4E_I301150 A    --ITEM MAP
                  LEFT OUTER JOIN M4E_I301160 B    --ROUTE MAP
                  ON A.PROJECT_CD = B.PROJECT_CD
               AND A.MP_VRSN_ID = B.MP_VRSN_ID
               AND A.MP_VRSN_SEQ= B.MP_VRSN_SEQ
               AND A.OUT_ITEM_CD= B.IN_ITEM_CD
             WHERE 1=1
               AND A.PROJECT_CD = @V_PROJECT_CD
               AND A.MP_VRSN_ID = @V_MP_VRSN_ID
               AND A.MP_VRSN_SEQ= @V_SEQ
               AND B.PROJECT_CD IS NULL
             GROUP BY A.PROJECT_CD
                     ,A.MP_VRSN_ID
                     ,A.MP_VRSN_SEQ
                     ,A.OUT_ITEM_CD
        )SR ON
        (
             TG.PROJECT_CD   = SR.PROJECT_CD
         AND TG.MP_VRSN_ID   = SR.MP_VRSN_ID
         AND TG.MP_VRSN_SEQ  = SR.MP_VRSN_SEQ
         AND TG.ENG_ITEM_CD  = SR.OUT_ITEM_CD
        )
     WHEN MATCHED THEN
            UPDATE SET TG.ITEM_TYPE_CD  = 'RM'
    ; 
    
    -- 원자재 아닌것 유한자재 
    
    UPDATE M4E_I301080
    SET   INF_ITEM_YN = 'N'
    WHERE PROJECT_CD        = @V_PROJECT_CD
          AND MP_VRSN_ID    = @V_MP_VRSN_ID
          AND MP_VRSN_SEQ   = @V_SEQ
          AND ITEM_TYPE_CD != 'RM'
    ;
    
        
    
    
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(34)M4E_I301080 ITEM TYPE UPDATE', '34.END';
    
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(35)M4E_I301070 확정 오더 관리 INSERT', '35.START';
    
    -- 공급계획 실행 확정 오더 
	WITH MST AS 
    ( 
            SELECT  @V_PROJECT_CD                     AS PROJECT_CD
                    ,@V_MP_VRSN_ID                    AS MP_VRSN_ID
                    ,@V_SEQ                           AS MP_SEQ
    --              ,ROWNUM AS PO_NO                AS PO_NO 
                    ,T1.ITEM_CD +'@'+T1.PLANT_CD    AS ENG_ITEM_CD
                    ,T1.RES_CD +'@'+T1.PLANT_CD     AS RES_CD
                    ,T2.TIME_INDEX                    AS TIME_INDEX_1
                    ,T2.TIME_INDEX                    AS TIME_INDEX_2
                    ,T1.BOM_TYPE_CD                   AS BOM_TYPE_CD
                    ,T1.REQ_PROD_QTY                  AS RES_PROD_QTY
                    ,T1.PO_FIX_TYPE_CD                AS PO_FIX_TYPE_CD
                    ,T1.PLANT_CD                      AS PLANT_CD
                    ,T1.ITEM_CD                       AS ITEM_CD
                    ,@V_USER_CD                       AS USER_CD
                    ,GETDATE()                          AS CREATE_DATE
            FROM M4S_I305180 T1 -- 확정 오더 관리
            LEFT JOIN M4E_I301050 T2 -- MP_CAL
            ON T1.PROJECT_CD    = T2.PROJECT_CD
            AND T2.MP_VRSN_ID   = @V_MP_VRSN_ID
            AND T2.MP_VRSN_SEQ  = @V_SEQ
            LEFT JOIN M4E_I301080 T3 -- MP_ITEM
            ON T1.PROJECT_CD = T3.PROJECT_CD
                AND T3.MP_VRSN_ID      = @V_MP_VRSN_ID
                AND T3.MP_VRSN_SEQ     = @V_SEQ
                AND T1.ITEM_CD         = T3.ITEM_CD
            WHERE T1.PROJECT_CD = @V_PROJECT_CD
            AND T1.IF_VRSN_ID   = @V_IF_VRSN
            AND T1.START_YYMMDD BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
            AND T2.END_YYMMDD BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
            AND T3.ENG_ITEM_CD IS NOT NULL
            UNION ALL
        SELECT @V_PROJECT_CD                                AS PROJECT_CD
                    ,@V_MP_VRSN_ID                                AS MP_VRSN_ID
                    ,@V_SEQ                                       AS MP_SEQ
    --              ,MAX(ROWNUM) AS PO_NO                       
                    ,T1.ENG_ITEM_CD
                    ,T1.RES_CD
                    ,T1.TIME_INDEX_1
                    ,T1.TIME_INDEX_2
                    ,T1.BOM_TYPE_CD
                    ,T1.RES_PROD_QTY
                    ,T1.PO_FIX_TYPE_CD
                    ,T1.PLANT_CD
                    ,T1.ITEM_CD
                    ,@V_USER_CD                                    AS USER_CD
                    ,GETDATE()                                      AS CREATE_DATE
            FROM
                (
		            SELECT 'M_'+T4.ITEM_GRP_CD +'@'+ T1.PLANT_CD     AS ENG_ITEM_CD
		                    ,T1.RES_CD +'@'+T1.PLANT_CD                 AS RES_CD
		                    ,T2.TIME_INDEX                                AS TIME_INDEX_1
		                    ,T2.TIME_INDEX                                AS TIME_INDEX_2
		                    ,T1.BOM_TYPE_CD                               AS BOM_TYPE_CD
		                    ,SUM(T1.REQ_PROD_QTY)                         AS RES_PROD_QTY
		                    ,T1.PO_FIX_TYPE_CD                            AS PO_FIX_TYPE_CD
		                    ,T1.PLANT_CD                                  AS PLANT_CD
		                    ,'M_'+T4.ITEM_GRP_CD                         AS ITEM_CD
		            FROM M4S_I305180 T1 -- 확정 오더 관리
		            LEFT JOIN M4E_I301050 T2 -- MP_CAL
		            ON T1.PROJECT_CD    = T2.PROJECT_CD
		            AND T2.MP_VRSN_ID   = @V_MP_VRSN_ID
		            AND T2.MP_VRSN_SEQ  = @V_SEQ
		            LEFT JOIN M4E_I301080 T3 -- MP_ITEM
		            ON T1.PROJECT_CD = T3.PROJECT_CD
		                AND T3.MP_VRSN_ID      = @V_MP_VRSN_ID
		                AND T3.MP_VRSN_SEQ     = @V_SEQ
		                AND T1.ITEM_CD         = T3.ITEM_CD
		            INNER JOIN M4S_I002040 T4
		            ON T1.PROJECT_CD    = T4.PROJECT_CD
		            AND T1.ITEM_CD      = T4.ITEM_CD	          
		            WHERE T1.PROJECT_CD = @V_PROJECT_CD
		            AND T1.IF_VRSN_ID   = @V_IF_VRSN
		            AND T1.START_YYMMDD BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
		            AND T2.END_YYMMDD BETWEEN T2.START_YYMMDD AND T2.END_YYMMDD
		            AND T3.ENG_ITEM_CD IS NULL   
		            GROUP BY 'M_'+T4.ITEM_GRP_CD +'@'+ T1.PLANT_CD  
		                    ,T1.RES_CD +'@'+T1.PLANT_CD
		                    ,T2.TIME_INDEX
		                    ,T2.TIME_INDEX
		                    ,T1.BOM_TYPE_CD
		                    ,T1.PO_FIX_TYPE_CD
		                    ,T1.PLANT_CD
		                    ,'M_'+T4.ITEM_GRP_CD  
		)  T1 
    )
    INSERT INTO M4E_I301070  
    (    PROJECT_CD
        ,MP_VRSN_ID
        ,MP_VRSN_SEQ
        ,PO_NO
        ,ENG_ITEM_CD
        ,RES_CD
        ,START_TIME_INDEX
        ,END_TIME_INDEX
        --,BOM_TYPE_CD
        ,REQ_PROD_QTY
        ,PO_FIX_TYPE_CD
        ,PLANT_CD
        ,ITEM_CD
        ,CREATE_USER_CD
        ,CREATE_DATE
    ) 
    SELECT  PROJECT_CD 
            ,MP_VRSN_ID
            ,MP_SEQ
            ,ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS PO_NO 
            ,ENG_ITEM_CD
            ,RES_CD
            ,TIME_INDEX_1
            ,TIME_INDEX_2
            --,BOM_TYPE_CD
            ,RES_PROD_QTY
            ,PO_FIX_TYPE_CD
            ,PLANT_CD
            ,ITEM_CD
            ,USER_CD
            ,CREATE_DATE
    FROM MST
    ;
    
    
    
    
    
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(35)M4E_I301070 확정 오더 관리 INSERT', '35.END';
  
    

    	DECLARE @result INT
	
	SET @result = 0 -- 0:성공
	
	IF @@ERROR != 0 SET @result = @@ERROR
	
	IF(@result <> 0)
		--RETURN(1);  
		SELECT @V_RETRUN = 1 ;
	else
		RETURN(2); 
		SELECT @V_RETRUN = 2;
        
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,SQLERRM, 'ALL END';

END
go

