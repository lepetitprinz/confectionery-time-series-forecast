create PROCEDURE [dbo].[PRC_MP_CONF_INSERT] -- 프로시저 이름
(

    -- 출력 매개변수
    @O INT OUTPUT, -- SYS_REFCURSOR,

    -- 입력 매개변수
    @V_PROJECT_CD        VARCHAR(4000),
    @VS_MP_VRSN_A_2      VARCHAR(4000),
    @VS_MP_VRSN_A_DET_2  FLOAT,
    @V_USER_CD           VARCHAR(4000)



)
AS
BEGIN -- 변수 선언

/**********************************************************************************/
/* Project       : M4Plan Suites                                                  */
/* Module        : 공급계획                                                         */
/* Program Name  : PRC_MP_CONF_INSERT                                             */
/* Description   : 확정오더 TABLE 생성                                              */
/* Referenced by :                                                                */
/* Program History                                                                */
/**********************************************************************************/
/* Date             In Charge         Description                                 */
/**********************************************************************************/
/* 2021-03-23       M.S.KIM          Initial Release                              */
/**********************************************************************************/


DECLARE @V_PROC_NM                VARCHAR(50); -- 프로시저이름

 
SET NOCOUNT ON; -- 동작
    -- 프로시저 이름
    SET @V_PROC_NM = 'PRC_MP_CONF_INSERT';


    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_MP_CONF_INSERT 프로시저', 'ALL START';
    
    --01.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) START', '01.START'; 
    
    
/******************************************************************************
    CONF DATA DELETE 
******************************************************************************/    
    
    INSERT INTO  M4S_I305180
    (
             PROJECT_CD
            ,IF_VRSN_ID
            ,PO_NO
            ,PLANT_CD
            ,ITEM_CD
            ,RES_CD
            ,START_YYMMDD
            ,END_YYMMDD
            ,REQ_PROD_QTY
            ,CREATE_USER_CD
            ,CREATE_DATE
    )
    (
    SELECT T1.PROJECT_CD
         ,T4.IF_VRSN_ID
         ,ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS PO_NO
         ,T2.PLANT_CD
         ,T2.ITEM_CD
         ,T5.RES_CD
         ,T3.START_YYMMDD
         ,T3.END_YYMMDD
         ,T1.ITEM_IN_QTY
         ,@V_USER_CD
         ,GETDATE()
    FROM M4E_O302040 T1 -- 공정 자재
    INNER JOIN M4E_I301080 T2 -- 제품 관리
    ON  T1.PROJECT_CD   = T2.PROJECT_CD 
    AND T1.MP_VRSN_ID   = T2.MP_VRSN_ID
    AND T1.MP_VRSN_SEQ  = T2.MP_VRSN_SEQ
    AND T1.IN_ITEM_CD   = T2.ENG_ITEM_CD
    AND T2.ITEM_TYPE_CD = 'FG'
    INNER JOIN M4E_I301050 T3 --CAL 
    ON  T1.PROJECT_CD   = T3.PROJECT_CD
    AND T1.MP_VRSN_ID   = T3.MP_VRSN_ID
    AND T1.MP_VRSN_SEQ  = T3.MP_VRSN_SEQ
    AND T1.TIME_INDEX   = T3.TIME_INDEX
    INNER JOIN M4E_I301010 T4 -- 버전 관리
    ON  T1.PROJECT_CD   = T4.PROJECT_CD
    AND T1.MP_VRSN_ID   = T4.MP_VRSN_ID
    AND T1.MP_VRSN_SEQ  = T4.MP_VRSN_SEQ
    LEFT JOIN M4S_I305110 T5 -- 라우팅
    ON T1.PROJECT_CD    = T5.PROJECT_CD
    AND T4.IF_VRSN_ID   = T5.IF_VRSN_ID
    AND T2.ITEM_CD      = T5.ITEM_CD
    INNER JOIN M4S_I002040 T6 -- 제품 관리
    ON T1.PROJECT_CD    = T6.PROJECT_CD
    AND T2.ITEM_CD      = T6.ITEM_CD
    LEFT JOIN M4S_I305090 T7 -- 설비 관리
    ON T1.PROJECT_CD    = T7.PROJECT_CD
    AND T4.IF_VRSN_ID   = T7.IF_VRSN_ID
    AND T5.RES_CD       = T7.RES_CD
    LEFT JOIN M4S_I305070 T8 -- 공정 관리
    ON T1.PROJECT_CD    = T8.PROJECT_CD
    AND T4.IF_VRSN_ID   = T8.IF_VRSN_ID
    AND T5.ROUTE_CD     = T8.ROUTE_CD
    AND T2.ITEM_CD      = T8.ITEM_CD
    WHERE T1.PROJECT_CD    = @V_PROJECT_CD
    AND T1.MP_VRSN_ID      = @VS_MP_VRSN_A_2
    AND T1.MP_VRSN_SEQ     = @VS_MP_VRSN_A_DET_2
    AND T1.TIME_INDEX > 0
    )
    ;
    
    --01.END--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) END', '01.END';    
    
    
    DECLARE @result INT
	
	SET @result = 0 -- 0:성공
	
	IF @@ERROR != 0 SET @result = @@ERROR
	 
	--SELECT @result
	
	IF(@result <> 0)
		--RETURN(1); -- 
		SELECT @O = 1 ;
	else
		--RETURN(2); --
		SELECT @O = 2;
        
    exec dbo.MTX_SCM_PROC_LOG V_PROJECT_CD, V_PROC_NM,SQLERRM, 'ALL END';

END
go

