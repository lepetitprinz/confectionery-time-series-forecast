/*****************************************************************************
* DESCRIPTION :	피어슨 상관계수(Pearson correlation coefficient) 참조
	            ORACLE CORR 함수를 MSSQL버전으로 만듬.(아래 인자 매핑정보)

				SUM(X) X =>	@X_VAL 
				SUM(Y) Y => @Y_VAL	
				SUM(X*X) X2 => @X2_VAL
				SUM(Y*Y) Y2 => @Y2_VAL
				SUM(X*Y) XY => @XY_VAL
				COUNT(*) N => @T_CNT

* CREATE DATE : 2021-08-06
*****************************************************************************/
CREATE FUNCTION [dbo].[FN_CORR](@X_VAL FLOAT, @Y_VAL FLOAT,	@X2_VAL FLOAT, @Y2_VAL FLOAT, @XY_VAL FLOAT, @T_CNT INT) 
RETURNS FLOAT 
AS 
BEGIN 
	DECLARE @V_RETURN FLOAT; 
	DECLARE @SUM_X FLOAT;
	DECLARE @SUM_Y FLOAT;
	DECLARE @SUM_XX FLOAT;
	DECLARE @SUM_YY FLOAT;
	DECLARE @SUM_XY FLOAT;
	DECLARE @COUNT INT;

	SET @SUM_X = @X_VAL;
	SET @SUM_Y = @Y_VAL;
	SET @SUM_XX = @X2_VAL;
	SET @SUM_YY = @Y2_VAL;
	SET @SUM_XY = @XY_VAL;
	SET @COUNT = @T_CNT;

	SET @V_RETURN = ( @COUNT*@SUM_XY - @SUM_X*@SUM_Y ) / SQRT( (@COUNT*@SUM_XX-@SUM_X*@SUM_X) * (@COUNT*@SUM_YY-@SUM_Y*@SUM_Y) )

	RETURN @V_RETURN; 
END
go

