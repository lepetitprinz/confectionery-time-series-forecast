create PROCEDURE [dbo].[PRC_DF_MIN_MAX_INSERT] -- 프로시저 이름
(
    -- 출력 매개변수
    @O INT OUTPUT, -- SYS_REFCURSOR,

    @V_PROJECT_CD        VARCHAR(50)
    )
AS
BEGIN -- Declare variables

/**********************************************************************************/
/* Project       : M4Plan Suites                                                  */
/* Module        : 수요예측                                                        */
/* Program Name  : PRC_DF_MIN_MAX_INSERT                                          */
/* Description   : 판매실적 최소 최대값 Table 생성                                   */
/* Referenced by :                                                                */
/* Program History                                                                */
/**********************************************************************************/
/* Date             In Charge         Description                                 */
/**********************************************************************************/
/* 2021-09-03       Y.J.KIM          Initial Release                              */
/**********************************************************************************/

DECLARE @V_PROC_NM    VARCHAR(50); -- 프로시저이름
DECLARE @START_DAY    INT;         --실적 로드 시작일
DECLARE @END_DAY      INT;         --실적 로드 종료일

SET NOCOUNT ON; -- 동작
    -- 프로시저 이름
    SET @V_PROC_NM = 'PRC_DF_MIN_MAX_INSERT';
    SET @START_DAY = (SELECT OPTION_VAL FROM M4S_I001020 WHERE OPTION_CD = 'RST_START_DAY');
    SET @END_DAY = (SELECT OPTION_VAL FROM M4S_I001020 WHERE OPTION_CD = 'RST_END_DAY');

    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,
        'PRC_DF_MIN_MAX_INSERT 프로시저', 'ALL START';

    --01.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,
        '(1) START', '01.START';

----------------------------
-- 사업 Level Data Insert
----------------------------
INSERT INTO M4S_I002171
(
   PROJECT_CD
 , DATA_VRSN_CD
 , DIVISION_CD
 , BIZ_CD
 , LINE_CD
 , BRAND_CD
 , MIN_QTY
 , MAX_QTY
 , CREATE_USER_CD
 , CREATE_DATE
)
SELECT PROJECT_CD
     , CONCAT(@START_DAY, '-', @END_DAY) AS DATA_VRSN_CD
     , 'BIZ_CD' AS DIVISION_CD
     , BIZ_CD
     , NULL AS LINE_CD
     , NULL AS BRAND_CD
     , MIN(QTY) AS MIN_QTY
     , MAX(QTY) AS MAX_QTY
     , 'SYSTEM' AS CREATE_USER_CD
     , GETDATE() AS CREATE_DATE
  FROM (
        SELECT PROJECT_CD
             , BIZ_CD
             , SUM(QTY) AS QTY
          FROM (
                SELECT SALES.PROJECT_CD AS PROJECT_CD
                     , ITEM_ATTR01_CD   AS BIZ_CD
                     , YYMMDD
                     , QTY
                  FROM (
                        SELECT PROJECT_CD
                             , ITEM_CD
                             , YYMMDD
                             , RST_SALES_QTY AS QTY
                          FROM M4S_I002170
                         WHERE 1 = 1
                           AND PROJECT_CD = @V_PROJECT_CD
                           AND YYMMDD BETWEEN @START_DAY AND @END_DAY
                        ) SALES
                 INNER JOIN (
                             SELECT PROJECT_CD
                                  , ITEM_CD
                                  , ITEM_ATTR01_CD
                               FROM M4S_I002040
                              WHERE 1=1
                                AND PROJECT_CD = @V_PROJECT_CD
                            ) COMM
                    ON SALES.PROJECT_CD = COMM.PROJECT_CD
                   AND SALES.ITEM_CD = COMM.ITEM_CD
               ) SALES
         GROUP BY PROJECT_CD
                , BIZ_CD
                , YYMMDD
        ) SALES
 GROUP BY PROJECT_CD
        , BIZ_CD
;
----------------------------
-- Line Level Data Insert --
----------------------------
INSERT INTO M4S_I002171
(
   PROJECT_CD
 , DATA_VRSN_CD
 , DIVISION_CD
 , BIZ_CD
 , LINE_CD
 , BRAND_CD
 , MIN_QTY
 , MAX_QTY
 , CREATE_USER_CD
 , CREATE_DATE
)
SELECT PROJECT_CD
     , CONCAT(@START_DAY, '-', @END_DAY) AS DATA_VRSN_CD
     , 'LINE_CD' AS DIVISION_CD
     , BIZ_CD
     , LINE_CD
     , NULL AS BRAND_CD
     , MIN(QTY) AS MIN_QTY
     , MAX(QTY) AS MAX_QTY
     , 'SYSTEM' AS CREATE_USER_CD
     , GETDATE() AS CREATE_DATE
  FROM (
        SELECT PROJECT_CD
             , BIZ_CD
             , LINE_CD
             , SUM(QTY) AS QTY
          FROM (
                SELECT SALES.PROJECT_CD AS PROJECT_CD
                     , ITEM_ATTR01_CD   AS BIZ_CD
                     , ITEM_ATTR02_CD   AS LINE_CD
                     , YYMMDD
                     , QTY
                  FROM (
                        SELECT PROJECT_CD
                             , ITEM_CD
                             , YYMMDD
                             , RST_SALES_QTY    AS QTY
                          FROM M4S_I002170
                         WHERE 1 = 1
                           AND PROJECT_CD = @V_PROJECT_CD
                           AND YYMMDD BETWEEN @START_DAY AND @END_DAY
                        ) SALES
                 INNER JOIN (
                             SELECT PROJECT_CD
                                  , ITEM_CD
                                  , ITEM_ATTR01_CD
                                  , ITEM_ATTR02_CD
                               FROM M4S_I002040
                              WHERE 1=1
                                AND PROJECT_CD = @V_PROJECT_CD
                            ) COMM
                    ON SALES.PROJECT_CD = COMM.PROJECT_CD
                   AND SALES.ITEM_CD = COMM.ITEM_CD
               ) SALES
         GROUP BY PROJECT_CD
                , BIZ_CD
                , LINE_CD
                , YYMMDD
        ) SALES
 GROUP BY PROJECT_CD
        , BIZ_CD
        , LINE_CD
;

-----------------------------
-- Brand Level Data Insert --
-----------------------------
INSERT INTO M4S_I002171
(
   PROJECT_CD
 , DATA_VRSN_CD
 , DIVISION_CD
 , BIZ_CD
 , LINE_CD
 , BRAND_CD
 , MIN_QTY
 , MAX_QTY
 , CREATE_USER_CD
 , CREATE_DATE
)
SELECT PROJECT_CD
     , CONCAT(@START_DAY, '-', @END_DAY) AS DATA_VRSN_CD
     , 'BRAND_CD' AS DIVISION_CD
     , BIZ_CD
     , LINE_CD
     , BRAND_CD
     , MIN(QTY) AS MIN_QTY
     , MAX(QTY) AS MAX_QTY
     , 'SYSTEM' AS CREATE_USER_CD
     , GETDATE() AS CREATE_DATE
  FROM (
        SELECT PROJECT_CD
             , BIZ_CD
             , LINE_CD
             , BRAND_CD
             , SUM(QTY) AS QTY
          FROM (
                SELECT SALES.PROJECT_CD AS PROJECT_CD
                     , ITEM_ATTR01_CD   AS BIZ_CD
                     , ITEM_ATTR02_CD   AS LINE_CD
                     , ITEM_ATTR03_CD   AS BRAND_CD
                     , YYMMDD
                     , QTY
                  FROM (
                        SELECT PROJECT_CD
                             , ITEM_CD
                             , YYMMDD
                             , RST_SALES_QTY    AS QTY
                          FROM M4S_I002170
                         WHERE 1 = 1
                           AND PROJECT_CD = @V_PROJECT_CD
                           AND YYMMDD BETWEEN @START_DAY AND @END_DAY
                        ) SALES
                 INNER JOIN (
                             SELECT PROJECT_CD
                                  , ITEM_CD
                                  , ITEM_ATTR01_CD
                                  , ITEM_ATTR02_CD
                                  , ITEM_ATTR03_CD
                               FROM M4S_I002040
                              WHERE 1=1
                                AND PROJECT_CD = @V_PROJECT_CD
                            ) COMM
                    ON SALES.PROJECT_CD = COMM.PROJECT_CD
                   AND SALES.ITEM_CD = COMM.ITEM_CD
               ) SALES
         GROUP BY PROJECT_CD
                , BIZ_CD
                , LINE_CD
                , BRAND_CD
                , YYMMDD
        ) SALES
 GROUP BY PROJECT_CD
        , BIZ_CD
        , LINE_CD
        , BRAND_CD
;
    --01.END--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) END', '01.END';

    DECLARE @result INT
	SET @result = 0 -- 0:성공

	IF @@ERROR != 0 SET @result = @@ERROR
	--SELECT @result

	IF(@result <> 0)
		--RETURN(1); --
		SELECT @O = 1 ;
	else
		--RETURN(2); --
		SELECT @O = 2;

    exec dbo.MTX_SCM_PROC_LOG V_PROJECT_CD, V_PROC_NM,SQLERRM, 'ALL END';

END
go

