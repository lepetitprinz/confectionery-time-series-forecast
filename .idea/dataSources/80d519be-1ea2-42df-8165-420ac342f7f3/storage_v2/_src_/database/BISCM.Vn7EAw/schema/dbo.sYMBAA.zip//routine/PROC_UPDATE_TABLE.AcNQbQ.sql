create  PROCEDURE [dbo].[PROC_UPDATE_TABLE] 
(
    @O INT OUTPUT, -- SYS_REFCURSOR,
    @V_TABLE_ID VARCHAR(4000)
) AS
 BEGIN
/**********************************************************************************/
/* Project       : M4Plan Suites                                                  */
/* Module        : -                                                              */
/* Program Name  : PROC_UPDATE_TABLE                                              */
/* Description   : M4Plan Suites 테이블 컬럼 속성 수정 프로시저                       */
/* Referenced by :                                                                */
/* Program History                                                                */
/**********************************************************************************/
/* Date             In Charge         Description                                 */
/**********************************************************************************/
/* 2021-04-15       M.S.Seok          Initial Release                             */
/**********************************************************************************/
    DECLARE @vs_sql NVARCHAR(1000);
    DECLARE @V_OLD_COL VARCHAR(200);
    DECLARE @V_FIND FLOAT;
    DECLARE @V_COL_ID VARCHAR(2000);
    DECLARE @V_COL_NM VARCHAR(4000);
    DECLARE @V_COL_TYPE_ALL VARCHAR(4000);
    DECLARE @V_TABLE_NM VARCHAR(4000);
    DECLARE @V_SEQ VARCHAR(4000);
    
    DECLARE OLD_TB CURSOR LOCAL
    FOR
    SELECT COL_ID
    FROM M4S_I000011
    WHERE TABLE_ID = @V_TABLE_ID
        AND ISSUE_STATE = '00';
        
    DECLARE NEW_TB CURSOR LOCAL
    FOR
    SELECT T2.COL_ID
    FROM
    (
        SELECT TABLE_NAME,COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_CATALOG = 'BISCM'
    ) T1
    RIGHT OUTER JOIN M4S_I000011 T2
        ON T1.TABLE_NAME = T2.TABLE_ID
            AND T1.COLUMN_NAME = T2.COL_ID
    WHERE T2.TABLE_ID = @V_TABLE_ID
        AND T2.ISSUE_STATE = '01'
        AND T1.COLUMN_NAME IS NULL;
        
    DECLARE NEW_COL CURSOR LOCAL
    FOR
    SELECT T2.COL_ID, T2.COL_NM
    FROM M4S_I000011 T1, M4S_I000012 T2
    WHERE T1.TABLE_ID = @V_TABLE_ID
        AND T1.COL_ID = T2.COL_ID
        AND T1.ISSUE_STATE='01';
        
    DECLARE NEW_SEQ CURSOR LOCAL
    FOR
    SELECT COL_ID, SEQ
    FROM M4S_I000013
    WHERE TABLE_ID = @V_TABLE_ID
        AND ISSUE_STATE='01'
    ORDER BY SEQ;
    
 
SET NOCOUNT ON;

--    --백업 테이블 생성(권한 문제)
--    SELECT COUNT(*)
--    INTO V_FIND
--    FROM ALL_ALL_TABLES
--    WHERE OWNER = 'BISCM'
--    AND TABLE_NAME LIKE V_TABLE_ID || '_'||TO_CHAR(SYSDATE,'YYYYMMDD')||'%'
--    ;

--    IF V_FIND = 0 THEN
--        vs_sql := 'CREATE TABLE ' || V_TABLE_ID || '_' || TO_CHAR(SYSDATE,'YYYYMMDD') || ' AS SELECT * FROM ' || V_TABLE_ID;
--    ELSE
--        V_FIND := V_FIND+1;
--        vs_sql := 'CREATE TABLE ' || V_TABLE_ID || '_' || TO_CHAR(SYSDATE,'YYYYMMDD') || '_' || V_FIND || ' AS SELECT * FROM ' || V_TABLE_ID;
--    END IF;
--    EXECUTE IMMEDIATE vs_sql;
--    DBMS_OUTPUT.PUT_LINE(vs_sql);
--    commit;

    --컬럼 삭제
    OPEN OLD_TB;
    WHILE 1=1 BEGIN
        SET @V_FIND = 0;
        FETCH OLD_TB INTO @V_COL_ID;
        IF @@FETCH_STATUS <> 0 BREAK ;
        
        -- SQLINES LICENSE FOR EVALUATION USE ONLY
        SELECT @V_FIND = COUNT(*)
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_CATALOG = 'BISCM'
            AND TABLE_NAME = @V_TABLE_ID
            AND COLUMN_NAME = @V_COL_ID
        ;
        
        SET @vs_sql = 'ALTER TABLE '+ @V_TABLE_ID + ' DROP COLUMN ' + @V_COL_ID;
        PRINT @vs_sql;
        IF @V_FIND > 0 BEGIN 
           EXECUTE sp_executesql @vs_sql;
        END 
        
        DELETE FROM M4S_I000011
        WHERE ISSUE_STATE = '00'
        AND TABLE_ID = @V_TABLE_ID
        AND COL_ID = @V_COL_ID
        ;
    END;
    CLOSE OLD_TB;
    DEALLOCATE OLD_TB;
       
    --컬럼 추가
    OPEN NEW_TB;
    WHILE 1=1 BEGIN
        SET @V_FIND = 0;
        FETCH NEW_TB INTO @V_COL_ID;
        IF @@FETCH_STATUS <> 0 BREAK ;
        
        -- SQLINES LICENSE FOR EVALUATION USE ONLY
        SELECT @V_FIND = COUNT(*)
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_CATALOG = 'BISCM'
            AND TABLE_NAME = @V_TABLE_ID
            AND COLUMN_NAME = @V_COL_ID
        ;
        
        -- SQLINES LICENSE FOR EVALUATION USE ONLY
        SELECT @V_COL_TYPE_ALL = T2.COL_TYPE_ALL
        FROM M4S_I000011 T1, M4S_I000012 T2
        WHERE T1.TABLE_ID = @V_TABLE_ID
            AND T1.COL_ID = T2.COL_ID
            AND T1.COL_ID = @V_COL_ID
            AND T1.ISSUE_STATE = '01'
        ;
        
        SET @vs_sql = 'ALTER TABLE '+ @V_TABLE_ID + ' ADD ' + @V_COL_ID +' '+ @V_COL_TYPE_ALL ;
        PRINT @vs_sql;
        IF @V_FIND = 0 BEGIN 
           EXECUTE sp_executesql @vs_sql;
        END 
    END;
    CLOSE NEW_TB;
    DEALLOCATE NEW_TB;
    
    --테이블 COMMENT 변경
    SELECT @V_TABLE_NM = TABLE_NM
    FROM M4S_I000010
    WHERE DB_DIVISION = 'BISCM'
        AND TABLE_ID = @V_TABLE_ID
    ;
	/* 
    SET @vs_sql = 'COMMENT ON TABLE BISCM.'+ @V_TABLE_ID + ' IS '+ '''' + @V_TABLE_NM + '''';
    PRINT @vs_sql;
    EXECUTE sp_executesql @vs_sql;
    
    
    --컬럼 COMMENT 변경
    OPEN NEW_COL;
    WHILE 1=1 BEGIN
        FETCH NEW_COL INTO @V_COL_ID,@V_COL_NM;
        IF @@FETCH_STATUS <> 0 BREAK ;
        SET @vs_sql = 'COMMENT ON COLUMN BISCM.'+ @V_TABLE_ID + '.' + @V_COL_ID +' IS ' + '''' + @V_COL_NM + '''';
        EXECUTE sp_executesql @vs_sql;        
        PRINT @vs_sql;
    END;
    CLOSE NEW_COL;
    DEALLOCATE NEW_COL;
    
--    --컬럼 순서 변경(오라클 버전 12g부터 가능함. 현재 11g 이므로, 기능 구현하려면 table drop&create 해야 함.
--    OPEN NEW_SEQ;
--    LOOP
--        FETCH NEW_SEQ INTO V_COL_ID, V_SEQ;
--        EXIT WHEN NEW_SEQ%NOTFOUND;
--        vs_sql := 'UPDATE BISCM.M4S_I000011' || ' SET SEQ' || ' = ' || V_SEQ || ' WHERE TABLE_ID = ' || '''' || V_TABLE_ID || '''' ||' AND COL_ID = ' || '''' || V_COL_ID || '''';
--        DBMS_OUTPUT.PUT_LINE(vs_sql);
--        EXECUTE IMMEDIATE vs_sql;
--        
--        vs_sql := 'ALTER TABLE '|| V_TABLE_ID || ' MODIFY ' || V_COL_ID || ' INVISIBLE';
--        DBMS_OUTPUT.PUT_LINE(vs_sql);
--        EXECUTE IMMEDIATE vs_sql;  
--        vs_sql := 'ALTER TABLE '|| V_TABLE_ID || ' MODIFY ' || V_COL_ID || ' VISIBLE';
--        DBMS_OUTPUT.PUT_LINE(vs_sql);
--        EXECUTE IMMEDIATE vs_sql;  
--    END LOOP;
--    CLOSE NEW_SEQ;
--    commit;
	*/
    -- 컬럼 SEQ INSERT
    OPEN NEW_SEQ;
    WHILE 1=1 BEGIN
        FETCH NEW_SEQ INTO @V_COL_ID, @V_SEQ;
        IF @@FETCH_STATUS <> 0 BREAK ;
        SET @vs_sql = 'UPDATE M4S_I000011' + ' SET SEQ' + ' = ' + @V_SEQ + ' WHERE TABLE_ID = ' + '''' + @V_TABLE_ID + '''' +' AND COL_ID = ' + '''' + @V_COL_ID + '''';
        PRINT @vs_sql;
        EXECUTE sp_executesql @vs_sql;
    END;
    CLOSE NEW_SEQ;
    DEALLOCATE NEW_SEQ;
    
    DECLARE @result INT
	
	SET @result = 0 -- 0:성공

	IF @@ERROR != 0 SET @result = @@ERROR
	 
	--SELECT @result

	IF(@result <> 0)
		--RETURN(1); -- 
		SELECT @O = 1 ;
	else
		--RETURN(2); --
		SELECT @O = 2;
END
go

