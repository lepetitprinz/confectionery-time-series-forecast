CREATE PROCEDURE [dbo].[PRC_SP_PLANT_NETTING] 
(
    @V_PROJECT_CD  VARCHAR(50),
    @V_SP_VRSN_ID  VARCHAR(50)
)
AS
BEGIN

/* SQLINES DEMO *** ***********************************************************
    프로시저명 : PRC_SP_PLANT_NETTING
    설명 : SP2까지 최종 확정된 판매계획을 판매실적 기반으로 물류센터별로 Netting
******************************************************************************/

DECLARE @V_PROC_NM  VARCHAR(50);   -- 프로시저이름
DECLARE @SP_VRSN_ID VARCHAR(50);   -- 판매계획 버전 ID 
DECLARE @SP1_CD    VARCHAR(20);   -- SP1 담당자
DECLARE @PROJECT_CD VARCHAR(20);   -- 프로젝트 코드
DECLARE @RESULT     NUMERIC(2);    -- 
DECLARE @ERR        NVARCHAR(MAX); -- 에러메세지

-- SP1/SKU/센터별 비율
DECLARE @RST_RATE TABLE
(
    ITEM_CD  VARCHAR(20),
    SP1_CD   VARCHAR(20),
    PLANT_CD VARCHAR(20),
    RATE     NUMERIC(6,3)
)
-- 판매계획 
DECLARE @SP_QTY TABLE
(
    PLAN_YYMMDD   VARCHAR(8),
    SALES_MGMT_CD VARCHAR(20),
    LINK_MGMT_CD  VARCHAR(10),
    ITEM_CD       VARCHAR(20),
    DP_QTY        NUMERIC(6,3)
)

SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRAN
        -- 프로시저 이름
        SET @V_PROC_NM = 'PRC_SP_PLANT_NETTING';
        -- 파라메터를 새로운 변수에 담음. (속도문제)
        SET @SP_VRSN_ID = @V_SP_VRSN_ID;
        SET @PROJECT_CD = @V_PROJECT_CD;

        EXEC dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_SP_PLANT_NETTING 프로시저', 'ALL START' ;
        
        -- 비율 구하기
        INSERT INTO @RST_RATE(ITEM_CD,SP1_CD,PLANT_CD,RATE)
        SELECT T1.ITEM_CD
              ,T1.CUST_GRP_CD
              ,T1.FROM_DC_CD
              ,ROUND(CASE WHEN T2.QTY = 0 THEN 0 ELSE T1.QTY/T2.QTY END,2) AS RATE
          FROM (SELECT T2.CUST_GRP_CD
                      ,T1.ITEM_CD
                      ,T1.FROM_DC_CD
                      ,SUM(T1.RST_SALES_QTY) AS QTY
                  FROM M4S_I002170 T1
                      ,M4S_I002060 T2
                 WHERE 1=1
                   AND YYMM BETWEEN '202101' AND '202102'  -- 날짜는 변경예정
                   AND T1.SOLD_CUST_GRP_CD = T2.CUST_CD
                   AND T2.CUST_GRP_CD IS NOT NULL
                 GROUP BY T2.CUST_GRP_CD,T1.ITEM_CD,T1.FROM_DC_CD
                  ) T1
              ,(SELECT T2.CUST_GRP_CD
                      ,T1.ITEM_CD
                      ,SUM(T1.RST_SALES_QTY) AS QTY
                  FROM M4S_I002170 T1
                      ,M4S_I002060 T2
                 WHERE 1=1
                   AND YYMM BETWEEN '202101' AND '202102'  -- 날짜는 변경예정
                   AND T1.SOLD_CUST_GRP_CD = T2.CUST_CD
                   AND T2.CUST_GRP_CD IS NOT NULL
                  GROUP BY T2.CUST_GRP_CD,T1.ITEM_CD ) T2
         WHERE T1.ITEM_CD = T2.ITEM_CD
           AND T1.CUST_GRP_CD =T2.CUST_GRP_CD

        -- 최종 판매계획 
        INSERT INTO @SP_QTY(SALES_MGMT_CD,LINK_MGMT_CD,ITEM_CD,PLAN_YYMMDD,DP_QTY)
        SELECT T1.SALES_MGMT_CD
              ,T2.LINK_SALES_MGMT_CD
              ,T1.ITEM_CD
              ,T1.PLAN_YYMMDD
              ,T1.DP_QTY
          FROM M4S_O201002 T1
              ,M4S_I204030 T2
              ,M4S_O201010 T3
        WHERE 1=1
          AND T1.SALES_MGMT_CD = T2.SALES_MGMT_CD
          AND T2.SALES_MGMT_VRSN_ID = T3.SALES_MGMT_VRSN_ID
          AND T1.DP_VRSN_ID = T3.DP_VRSN_ID
          --AND T3.PRGS_STA_CD = 'P01';
          AND T1.DP_VRSN_ID = 'SP_2021W38.01';

        SELECT T1.PLAN_YYMMDD
              ,T1.ITEM_CD
              ,T1.LINK_MGMT_CD
              ,T2.PLANT_CD
              ,ROUND(T1.DP_QTY * T2.RATE,0) AS QTY
          FROM @SP_QTY T1
               INNER JOIN @RST_RATE T2
               ON  T1.ITEM_CD = T2.ITEM_CD
               AND T1.LINK_MGMT_CD = T2.SP1_CD

        COMMIT TRAN;
        --SELECT '1' AS RESULT;
        Set @RESULT = (SELECT '1' AS RESULT);
        EXEC  dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_SP_PLANT_NETTING 프로시저', 'ALL END';

    END TRY
    BEGIN CATCH

        ROLLBACK TRAN;
        --SELECT '1' AS RESULT;
        Set @RESULT = (SELECT '0' AS RESULT);
        SET @ERR = 'Error : ' + ERROR_MESSAGE();
        EXEC  dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, @ERR, 'ERROR';

    END CATCH
    
END ;
go

