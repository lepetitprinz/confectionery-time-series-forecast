CREATE PROCEDURE [dbo].[PRC_DP_VERSION_CREATION] 
(
    @V_PROJECT_CD  VARCHAR(4000),
    @V_DESCR     VARCHAR(4000), 
    @V_CORPO_CD  VARCHAR(4000), 
    @V_SALES_MGMT_VRSN_ID VARCHAR(4000),
    @V_USER_CD       VARCHAR(4000),
    @V_YYMMDD    VARCHAR(4000)
)
AS
BEGIN

/* SQLINES DEMO *** ***********************************************************
    프로시저명 : PRC_DP_VERSION_CREATION
    설명 : 판매계획 버전 생성시 실행되는 프로시저입니다.

    버전생성시 진행상태 -> P01 진행중 ( 이외 버전 P00종료처리 ) 
******************************************************************************/

DECLARE @V_PROC_NM VARCHAR(50); -- 프로시저이름

DECLARE @V_DP_VRSN_ID  VARCHAR(50); -- SQLINES DEMO *** 판매계획 버전 ID 
DECLARE @V_TMP_VRSN_ID VARCHAR(50); -- SQLINES DEMO *** 판매계획 임시 버전 ID
DECLARE @V_SEQ         VARCHAR(2);

DECLARE @V_DP_COPY_VRSN_ID VARCHAR(50);
DECLARE @V_DEMAND_FCST_CD VARCHAR(50); -- SQLINES DEMO  수요예측  모델코드

DECLARE @V_BUCKET VARCHAR(10); -- SQLINES DEMO *** BUCKET 단위 (예: D, PW, W, M)

DECLARE @V_PLAN_START_DATE VARCHAR(8);
DECLARE @V_PLAN_END_DATE VARCHAR(8);
 

DECLARE @V_DIVISION VARCHAR(50); -- SQLINES DEMO 수요예측 모델코드
DECLARE @RESULT numeric(2);

DECLARE @FROM_YYMMDD AS VARCHAR(8);
DECLARE @TO_YYMMDD AS VARCHAR(8);
DECLARE @HORIZON_CD AS VARCHAR(10);
DECLARE @HORIZON_VAL AS INT; 
DECLARE @ERR  AS  NVARCHAR(MAX); -- 에러메세지
 
SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRAN
        -- 프로시저 이름
        SET @V_PROC_NM = 'PRC_DP_VERSION_CREATION';
        exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_DP_VERSION_CREATION 프로시저', 'ALL START' ;
        exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1)M4S_O201010 판매계획 버전관리 테이블 INSERT', '01.START';
        
        -- 현재 진행중인 버전 (최종버전) 
        SELECT @V_DP_COPY_VRSN_ID = DP_VRSN_ID
          FROM M4S_O201010
         WHERE PRGS_STA_CD = 'P01';

        -- 판매계획 기간 및 주기
        SELECT @HORIZON_CD = ATTR01_VAL
              ,@HORIZON_VAL= ATTR01_NUM_VAL
          FROM M4S_I002011
         WHERE COMM_CD = 'SP_HORIZON_CD'
           AND COMM_DTL_CD = 'HORIZON_CD';

        SELECT @V_BUCKET = ATTR01_VAL
          FROM M4S_I002011
         WHERE COMM_CD = 'SP_HORIZON_CD'
           AND COMM_DTL_CD = 'BUCKET_CD'; 

        -- 시작일자
        SELECT @FROM_YYMMDD = START_WEEK_DAY
          FROM M4S_I002030
         WHERE 1=1
           AND YYMMDD = CONVERT(VARCHAR(8),DATEADD(WEEK,1,@V_YYMMDD),112)
         GROUP BY START_WEEK_DAY;
    
        -- 종료일자
        SELECT @TO_YYMMDD = T2.END_WEEK_DAY
          FROM (SELECT END_MONTH_DAY AS YYMMDD
                  FROM M4S_I002030
                 WHERE 1=1
                   AND YYMM = (CASE WHEN SUBSTRING(@V_YYMMDD,1,6) = CONVERT(VARCHAR(6),DATEADD(WEEK,2,@V_YYMMDD),112)
                                    THEN (CASE WHEN @HORIZON_CD = 'W' THEN CONVERT(VARCHAR(6),DATEADD(WEEK,@HORIZON_VAL-1,@V_YYMMDD),112)
                                               WHEN @HORIZON_CD = 'M' THEN CONVERT(VARCHAR(6),DATEADD(MONTH,@HORIZON_VAL-1,@V_YYMMDD),112)
                                               ELSE CONVERT(VARCHAR(6),DATEADD(WEEK,@HORIZON_VAL-1,@V_YYMMDD),112)
                                               END)
                                    ELSE (CASE WHEN @HORIZON_CD = 'W' THEN CONVERT(VARCHAR(6),DATEADD(WEEK,@HORIZON_VAL,@V_YYMMDD),112)
                                               WHEN @HORIZON_CD = 'M' THEN CONVERT(VARCHAR(6),DATEADD(MONTH,@HORIZON_VAL,@V_YYMMDD),112)
                                               ELSE CONVERT(VARCHAR(6),DATEADD(WEEK,@HORIZON_VAL,@V_YYMMDD),112)
                                               END)
                                    END )
                 GROUP BY END_MONTH_DAY
                   ) T1
              ,M4S_I002030 T2
         WHERE 1=1
           AND T1.YYMMDD = T2.YYMMDD
         GROUP BY T2.END_WEEK_DAY;
   
       -- 임시버전코드 생성
        SELECT @V_TMP_VRSN_ID     = concat('SP_', ( case when @V_BUCKET = 'M' then T1.YYMM else concat( T1.YY, T1.WEEK) end ) , '.' )
              ,@V_PLAN_START_DATE = @FROM_YYMMDD
              ,@V_PLAN_END_DATE   = @TO_YYMMDD   
          FROM M4S_I002030 T1
         WHERE T1.YYMMDD     = @FROM_YYMMDD
           AND T1.PROJECT_CD = @V_PROJECT_CD;
   
       -- 버전 Seq. 생성
        SELECT @V_SEQ =  ( CASE WHEN S.TMP_SEQ = '00' OR S.TMP_SEQ IS NULL THEN '01'
                                ELSE  CONCAT( REPLICATE( '0' , 2 - LEN( CONVERT( numeric , S.TMP_SEQ ) + 1 ) ) , CONVERT( VARCHAR(2) , CONVERT( numeric , S.TMP_SEQ ) + 1))   
                                END  )  
          FROM (SELECT CASE WHEN MAX(A.DP_VRSN_ID) IS NULL THEN '00' ELSE REPLACE(MAX(A.DP_VRSN_ID), @V_TMP_VRSN_ID,'') END AS TMP_SEQ
                  FROM M4S_O201010 A
                 WHERE A.PROJECT_CD     = @V_PROJECT_CD
                   AND CHARINDEX(@V_TMP_VRSN_ID, A.DP_VRSN_ID) > 0 ) S; 
   
       -- 버전코드 생성
       SET @V_DP_VRSN_ID = CONCAT(@V_TMP_VRSN_ID , @V_SEQ );
   
       -- 직전버전 종료처리
       UPDATE M4S_O201010 
          SET PRGS_STA_CD = 'P00'
        WHERE PRGS_STA_CD = 'P01'
          AND PROJECT_CD = @V_PROJECT_CD
       ;      
   
       -- 판매계획 버전 생성
       INSERT INTO M4S_O201010 (PROJECT_CD
                               ,DP_VRSN_ID
                               ,YYMMDD
                               ,WEEK
                               ,PART_WEEK
                               ,YYMM
                               ,YY
                               ,CORPO_CD                      
                               ,PRGS_STA_CD
                               ,PLAN_FROM_YYMMDD
                               ,PLAN_TO_YYMMDD
                               ,DP_COPY_VRSN_ID                
                               ,SALES_MGMT_VRSN_ID
                               ,DF_DIVISION_CD
                               ,USE_YN
                               ,DESCR
                               ,CREATE_USER_CD
                               ,CREATE_DATE)
        SELECT PROJECT_CD
              ,@V_DP_VRSN_ID
              ,YYMMDD
              ,WEEK
              ,PART_WEEK
              ,YYMM
              ,YY
              ,@V_CORPO_CD        
              ,'P01'    
              ,@V_PLAN_START_DATE
              ,@V_PLAN_END_DATE
              ,@V_DP_COPY_VRSN_ID
              ,@V_SALES_MGMT_VRSN_ID
              ,@V_DEMAND_FCST_CD     
              ,'Y'
              ,@V_DESCR
              ,@V_USER_CD
              ,GETDATE()
          FROM M4S_I002030
         WHERE YYMMDD   = @V_PLAN_START_DATE
           AND PROJECT_CD = @V_PROJECT_CD;
        
        exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1)M4S_O201010 판매계획 버전관리 테이블 INSERT', '01.END' ;
        exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2)M4S_O201001 판매계획 데이터 테이블 INSERT', '02.START';    
    
        -- 판매계획 Data 생성
        INSERT INTO M4S_O201001( PROJECT_CD
                                ,DP_VRSN_ID
                                ,SALES_MGMT_CD
                                ,ITEM_CD
                                ,USER_CD
                                ,PLAN_YYMMDD
                                ,PLAN_WEEK
                                ,PLAN_PART_WEEK
                                ,PLAN_YYMM
                                ,PLAN_YY
                                ,DP_QTY
                                ,CREATE_USER_CD
                                ,CREATE_DATE )
        SELECT @V_PROJECT_CD
               ,T2.DP_VRSN_ID
               ,T1.SALES_MGMT_CD
               ,T1.ITEM_CD
               ,T1.USER_CD
               ,T2.START_PART_WEEK_DAY AS PLAN_YYMMDD
               ,T2.WEEK                AS PLAN_WEEK
               ,T2.PART_WEEK           AS PLAN_PART_WEEK
               ,T2.YYMM                AS PLAN_YYMM
               ,T2.YY                  AS PLAN_YY
               ,ISNULL(T3.DP_QTY,0)    AS DP_QTY
               ,@V_USER_CD
               ,GETDATE()
           FROM M4S_I204050 T1
                INNER JOIN (SELECT T1.SALES_MGMT_VRSN_ID
                                  ,T1.DP_VRSN_ID
                                  ,T1.DP_COPY_VRSN_ID
                                  ,T2.START_WEEK_DAY
                                  ,T2.START_PART_WEEK_DAY
                                  ,T2.WEEK
                                  ,T2.PART_WEEK
                                  ,T2.YYMM
                                  ,T2.YY
                              FROM M4S_O201010 T1
                                  ,M4S_I002030 T2
                             WHERE T1.PROJECT_CD = T2.PROJECT_CD
                               AND T2.YYMMDD BETWEEN T1.PLAN_FROM_YYMMDD AND T1.PLAN_TO_YYMMDD
                               AND T1.PRGS_STA_CD = 'P01'
                             GROUP BY T1.SALES_MGMT_VRSN_ID
                                     ,T1.DP_VRSN_ID
                                     ,T1.DP_COPY_VRSN_ID
                                     ,T2.START_WEEK_DAY
                                     ,T2.START_PART_WEEK_DAY
                                     ,T2.WEEK
                                     ,T2.PART_WEEK
                                     ,T2.YYMM
                                     ,T2.YY ) T2
                 ON  T1.SALES_MGMT_VRSN_ID = T2.SALES_MGMT_VRSN_ID
                 LEFT JOIN M4S_O201001 T3
                 ON  T2.DP_COPY_VRSN_ID     = T3.DP_VRSN_ID
                 AND T2.START_PART_WEEK_DAY = T3.PLAN_YYMMDD
                 AND T1.SALES_MGMT_CD       = T3.SALES_MGMT_CD
                 AND T1.ITEM_CD             = T3.ITEM_CD
                 AND T1.USER_CD             = T3.USER_CD ;

        exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2)M4S_O201001 판매계획 데이터 테이블 INSERT', '02.END';

        COMMIT TRAN;
        --SELECT '1' AS RESULT;
        Set @RESULT = (SELECT '1' AS RESULT);
        exec  dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_DP_VERSION_CREATION 프로시저', 'ALL END';

    END TRY
    BEGIN CATCH

        ROLLBACK TRAN;
        --SELECT '1' AS RESULT;
        Set @RESULT = (SELECT '0' AS RESULT);
        SET @ERR = 'Error : ' + ERROR_MESSAGE();
        exec  dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, @ERR, 'ERROR';

    END CATCH
    
END ;
go

