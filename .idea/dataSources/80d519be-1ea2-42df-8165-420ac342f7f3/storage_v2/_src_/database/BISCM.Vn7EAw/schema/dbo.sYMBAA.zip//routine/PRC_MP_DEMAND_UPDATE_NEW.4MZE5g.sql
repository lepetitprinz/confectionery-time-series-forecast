create PROCEDURE [dbo].[PRC_MP_DEMAND_UPDATE_NEW]  -- 프로시저 이름
(

    -- 출력 매개변수
    @O INT OUTPUT, -- SYS_REFCURSOR,
    
    @V_PROJECT_CD    VARCHAR(4000),
    @V_MP_VRSN_ID    VARCHAR(4000),
    @V_SEQ           VARCHAR(4000),
    @V_IF_VRSN_ID    VARCHAR(4000),
    @V_ENG_TYPE_CD   VARCHAR(4000)

)
AS
BEGIN -- 변수 선언



/**********************************************************************************/
/* Project       : M4Plan Suites                                                 */
/* Module        : 공급계획                                                        */
/* Program Name  : PRC_MP_DEMAND_UPDATE_NEW                                       */
/* Description   : 생산계획 DEMAND UPDATE                                          */
/* Referenced by :                                                                */
/* Program History                                                                */
/**********************************************************************************/
/* Date             In Charge         Description                                 */
/**********************************************************************************/
/* 2021-03-23       M.S.KIM          Initial Release                              */
/* 2021-05-10       M.S.KIM          계획 타입별 DEMAND 수정                         */
/**********************************************************************************/


DECLARE @V_PROC_NM                VARCHAR(50); -- 프로시저이름

SET NOCOUNT ON; -- 동작
    -- 프로시저 이름
    SET @V_PROC_NM = 'PRC_MP_DEMAND_UPDATE_NEW';

    -- MTX_SCM_PROC_LOG: 프로시저 로그를 저장하는 프로시저 => M4S_I001030(로그 관리)에 저장
    -- @V_PROJECT_CD, @V_PROC_NM, @V_PROC_DESC, @V_PROC_STATE
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_MP_DEMAND_UPDATE_NEW 프로시저', 'ALL START';
    
    --01.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) START', '01.START'; 
    
    
/******************************************************************************
    DEMAND UPDATE 
******************************************************************************/     

    --02.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2) DELETE START', '02.START';     
    
    DELETE M4S_I305020   
    WHERE PROJECT_CD = @V_PROJECT_CD
      AND IF_VRSN_ID = @V_IF_VRSN_ID
      AND SUBSTRING(MP_KEY,1,2) = 'FP'
    ;

    --02.END--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(2) DELETE END', '02.END'; 
 
/******************************************************************************
    DEMAND UPDATE 
******************************************************************************/    
    

    IF @V_ENG_TYPE_CD = 'MP' BEGIN 
    
        INSERT INTO M4S_I305020 --공급계획 DEMAND 
        (
            PROJECT_CD
           ,IF_VRSN_ID
           ,MP_KEY
           ,DP_KEY
           ,ITEM_CD
           ,PLANT_CD
           ,REQ_MP_YYMMDD
           ,REQ_MP_QTY
           ,AHEAD_LIMIT_VAL
           ,LATE_LIMIT_VAL
           ,SHIP_AHEAD_LIMIT_VAL
           ,SHIP_LATE_LIMIT_VAL      
        )     
        SELECT T1.PROJECT_CD
              ,T1.IF_VRSN_ID
              ,'FP' + RIGHT(REPLICATE(0, 7) + LEFT(ROW_NUMBER() OVER (ORDER BY (SELECT 1)), 7), 7) AS MP_KEY
              ,'DP' + RIGHT(REPLICATE(0, 7) + LEFT(ROW_NUMBER() OVER (ORDER BY (SELECT 1)), 7), 7) AS DP_KEY
              ,T1.ITEM_CD
              ,T1.PLANT_CD
              ,T1.START_YYMMDD
              ,T1.ITEM_OUT_QTY 
              ,0                        AS AHEAD_LIMIT_VAL
              ,0                        AS LATE_LIMIT_VAL
              ,0                        AS SHIP_AHEAD_LIMIT_VAL
              ,0                        AS SHIP_LATE_LIMIT_VAL          
         FROM 
         (
             SELECT T1.PROJECT_CD
                  ,T6.IF_VRSN_ID
                  ,T2.ITEM_CD
                  ,T2.PLANT_CD
                  ,T4.START_YYMMDD
                  ,SUM(T1.ITEM_OUT_QTY) AS ITEM_OUT_QTY 
            FROM 
            (
                SELECT *
                  FROM M4E_O302030  T1                      -- 투입
                WHERE T1.PROJECT_CD         = @V_PROJECT_CD
                   AND T1.MP_VRSN_ID        = @V_MP_VRSN_ID
                   AND T1.MP_VRSN_SEQ       = @V_SEQ
                   AND T1.ENG_TIME_INDEX > 0 
            ) T1
            INNER JOIN M4E_I301080 T2                       -- 엔진 제품 마스터
            ON T1.PROJECT_CD    = T2.PROJECT_CD
            AND T1.MP_VRSN_ID   = T2.MP_VRSN_ID
            AND T1.MP_VRSN_SEQ  = T2.MP_VRSN_SEQ
            AND T1.OUT_ITEM_CD  = T2.ENG_ITEM_CD
            INNER JOIN M4S_I002040 T3                       --제품 마스터
            ON T1.PROJECT_CD    = T3.PROJECT_CD
            AND T2.ITEM_CD      = T3.ITEM_CD
            AND T3.ITEM_TYPE_CD = 'FG'   
            INNER JOIN M4E_I301050 T4                       -- 달력
            ON T1.PROJECT_CD = T4.PROJECT_CD
            AND T1.MP_VRSN_ID = T4.MP_VRSN_ID
            AND T1.MP_VRSN_SEQ = T4.MP_VRSN_SEQ
            AND T1.ENG_TIME_INDEX = T4.TIME_INDEX
            INNER JOIN M4S_I002080 T5                       --사이트 관리 
            ON T1.PROJECT_CD    = T5.PROJECT_CD
            AND T2.PLANT_CD     = T5.SITE_CD
            AND T5.SITE_TYPE_CD = 'PLANT'
            INNER JOIN M4E_I301010 T6
            ON T1.PROJECT_CD = T6.PROJECT_CD
            AND T1.MP_VRSN_ID = T6.MP_VRSN_ID
            AND T1.MP_VRSN_SEQ = T6.MP_VRSN_SEQ
            GROUP BY  T1.PROJECT_CD
                     ,T6.IF_VRSN_ID
                     ,T2.ITEM_CD
                     ,T2.PLANT_CD
                     ,T4.START_YYMMDD
        ) T1;
    END
    ELSE BEGIN
    
        INSERT INTO M4S_I305020 --공급계획 DEMAND 
        (
            PROJECT_CD
           ,IF_VRSN_ID
           ,MP_KEY
           ,DP_KEY
           ,ITEM_CD
           ,PLANT_CD
           ,REQ_MP_YYMMDD
           ,REQ_MP_QTY
           ,AHEAD_LIMIT_VAL
           ,LATE_LIMIT_VAL
           ,SHIP_AHEAD_LIMIT_VAL
           ,SHIP_LATE_LIMIT_VAL      
        )         
        SELECT T1.PROJECT_CD
              ,T1.IF_VRSN_ID
              ,'FP' + RIGHT(REPLICATE(0, 7) + LEFT(ROW_NUMBER() OVER (ORDER BY (SELECT 1)), 7), 7) AS MP_KEY
              ,'DP' + RIGHT(REPLICATE(0, 7) + LEFT(ROW_NUMBER() OVER (ORDER BY (SELECT 1)), 7), 7) AS DP_KEY
              ,T1.ITEM_CD
              ,T1.PLANT_CD
              ,T1.END_YYMMDD               AS REQ_MP_YYMMDD
              ,T1.ITEM_OUT_QTY             AS REQ_MP_QTY
              ,0                        AS AHEAD_LIMIT_VAL
              ,0                        AS LATE_LIMIT_VAL
              ,0                        AS SHIP_AHEAD_LIMIT_VAL
              ,0                        AS SHIP_LATE_LIMIT_VAL      
        FROM 
        (        
            SELECT T1.PROJECT_CD
                  ,T3.IF_VRSN_ID
                  ,T2.ITEM_CD
                  ,T2.PLANT_CD
                  ,T4.END_YYMMDD
                  ,SUM(T1.ITEM_OUT_QTY) AS ITEM_OUT_QTY 
              FROM M4E_O302030  T1  -- 생산
             INNER JOIN  M4E_I301080 T2
             ON T1.PROJECT_CD = T2.PROJECT_CD
            AND T1.MP_VRSN_ID = T2.MP_VRSN_ID
            AND T1.MP_VRSN_SEQ = T2.MP_VRSN_SEQ
            AND T1.OUT_ITEM_CD = T2.ENG_ITEM_CD
            AND T2.ITEM_TYPE_CD = 'RM'
            INNER JOIN 
            (
                SELECT  MP_VRSN_ID,MP_VRSN_SEQ,IF_VRSN_ID 
                FROM M4E_I301010
                WHERE PROJECT_CD    = @V_PROJECT_CD
                AND MP_VRSN_ID      = @V_MP_VRSN_ID
                AND MP_VRSN_SEQ     = @V_SEQ   
            ) T3
            ON T1.MP_VRSN_SEQ = T3.MP_VRSN_SEQ        
            AND T1.MP_VRSN_ID = T3.MP_VRSN_ID
            INNER JOIN M4E_I301050 T4   --달력
            ON T1.PROJECT_CD    = T4.PROJECT_CD
            AND T1.MP_VRSN_ID   = T4.MP_VRSN_ID
            AND T1.MP_VRSN_SEQ  = T4.MP_VRSN_SEQ
            AND T1.TIME_INDEX   = T4.TIME_INDEX
            WHERE T1.PROJECT_CD    = @V_PROJECT_CD
            AND T1.MP_VRSN_ID      = @V_MP_VRSN_ID
            AND T1.MP_VRSN_SEQ     = @V_SEQ             
            GROUP BY  T1.PROJECT_CD
                  ,T3.IF_VRSN_ID    
                  ,T2.ITEM_CD
                  ,T2.PLANT_CD
                  ,T4.END_YYMMDD
        ) T1    
        ;    
    
    END




    --01.END--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) END', '01.END';     
    
    
    DECLARE @result INT
	
	SET @result = 0 -- 0:성공
	
	IF @@ERROR != 0 SET @result = @@ERROR
	
	IF(@result <> 0)
		RETURN(1); -- SELECT @O = 1 ;
	else
		RETURN(2); --SELECT @O = 2;
        
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,SQLERRM, 'ALL END';

END
go

