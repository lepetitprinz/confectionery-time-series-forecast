create PROCEDURE [dbo].[PRC_MP_CONF_DELETE] -- 프로시저 이름
(

    -- 출력 매개변수
    @O INT OUTPUT, -- SYS_REFCURSOR,

    -- 입력 매개변수
    @V_PROJECT_CD        VARCHAR(4000)


)
AS
BEGIN -- 변수 선언

/**********************************************************************************/
/* Project       : M4Plan Suites                                                  */
/* Module        : 공급계획                                                         */
/* Program Name  : PRC_MP_CONF_DELETE                                             */
/* Description   : 확정오더 TABLE DELETE                                            */
/* Referenced by :                                                                */
/* Program History                                                                */
/**********************************************************************************/
/* Date             In Charge         Description                                 */
/**********************************************************************************/
/* 2021-03-23       M.S.KIM          Initial Release                              */
/**********************************************************************************/



DECLARE @V_PROC_NM                VARCHAR(50); -- 프로시저이름

 
SET NOCOUNT ON; -- 동작
    -- 프로시저 이름
    SET @V_PROC_NM = 'PRC_MP_CONF_DELETE';


    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, 'PRC_MP_CONF_DELETE 프로시저', 'ALL START';
    
    --01.START--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) START', '01.START'; 
    
    
/******************************************************************************
    CONF DATA DELETE 
******************************************************************************/    
    
    DELETE M4S_I305180  
    WHERE 1=1
      AND PROJECT_CD    =    @V_PROJECT_CD
    ;
    
    
    --01.END--
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM, '(1) END', '01.END';         
    
    
    DECLARE @result INT
	
	SET @result = 0 -- 0:성공
	
	IF @@ERROR != 0 SET @result = @@ERROR
	 
	--SELECT @result
	
	IF(@result <> 0)
		--RETURN(1); -- 
		SELECT @O = 1 ;
	else
		--RETURN(2); --
		SELECT @O = 2;
        
    exec dbo.MTX_SCM_PROC_LOG @V_PROJECT_CD, @V_PROC_NM,SQLERRM, 'ALL END';

END
go

