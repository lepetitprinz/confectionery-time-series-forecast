Create PROCEDURE [dbo].[MTX_SCM_PROC_LOG] (
	@V_PROJECT_CD VARCHAR(400)
	, @V_PROC_NM VARCHAR(400)
	, @V_PROC_DESC VARCHAR(400)
	, @V_PROC_STATE VARCHAR(400) )
	AS
 
 
 BEGIN 
/* *** ***********************************************************
   PURPOSE: 프로시저 로그를 저장하는 프로시저.   
******************************************************************************/
--V_RETURN INT;
DECLARE @V_IF_VRSN_ID    VARCHAR(20);
 
SET NOCOUNT ON;
    
    SET @V_IF_VRSN_ID = '-';
    
    INSERT INTO M4S_I001030
    (PROJECT_CD, IF_VRSN_ID, PROC_NM, EXCUTE_DATE, PROC_DESC, PROC_STATE)
    VALUES
    (@V_PROJECT_CD, @V_IF_VRSN_ID, @V_PROC_NM, GETDATE(),  @V_PROC_DESC, @V_PROC_STATE) 
    ;
    
END;
go

